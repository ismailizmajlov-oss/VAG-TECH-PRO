
CREATE TABLE app_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
) STRICT;
CREATE TABLE schema_migrations (
  version INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  checksum TEXT NOT NULL CHECK(length(checksum)=64),
  applied_at TEXT NOT NULL
) STRICT;
CREATE TABLE sources (
  source_id TEXT PRIMARY KEY,
  publisher TEXT NOT NULL,
  title TEXT NOT NULL,
  source_type TEXT NOT NULL,
  source_url TEXT,
  revision TEXT NOT NULL,
  license_id TEXT,
  license_url TEXT,
  license_sha256 TEXT CHECK(license_sha256 IS NULL OR (length(license_sha256)=64 AND license_sha256 NOT GLOB '*[^0-9a-f]*')),
  rights_status TEXT NOT NULL CHECK(rights_status IN ('permission_required','restricted','approved_by_published_license','approved_by_written_permission')),
  commercial_use_allowed INTEGER NOT NULL DEFAULT 0 CHECK(commercial_use_allowed IN (0,1)),
  display_allowed INTEGER NOT NULL DEFAULT 0 CHECK(display_allowed IN (0,1)),
  offline_cache_allowed INTEGER NOT NULL DEFAULT 0 CHECK(offline_cache_allowed IN (0,1)),
  bulk_reuse_allowed INTEGER NOT NULL DEFAULT 0 CHECK(bulk_reuse_allowed IN (0,1)),
  redistribution_allowed INTEGER NOT NULL DEFAULT 0 CHECK(redistribution_allowed IN (0,1)),
  share_alike_required INTEGER NOT NULL DEFAULT 0 CHECK(share_alike_required IN (0,1)),
  attribution_required INTEGER NOT NULL DEFAULT 1 CHECK(attribution_required IN (0,1)),
  attribution_text TEXT,
  market_scope TEXT NOT NULL,
  source_snapshot_sha256 TEXT CHECK(source_snapshot_sha256 IS NULL OR (length(source_snapshot_sha256)=64 AND source_snapshot_sha256 NOT GLOB '*[^0-9a-f]*')),
  rights_evidence_sha256 TEXT CHECK(rights_evidence_sha256 IS NULL OR (length(rights_evidence_sha256)=64 AND rights_evidence_sha256 NOT GLOB '*[^0-9a-f]*')),
  status TEXT NOT NULL DEFAULT 'candidate' CHECK(status IN ('candidate','approved','blocked','superseded')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(rights_status NOT IN ('approved_by_published_license','approved_by_written_permission') OR
    (commercial_use_allowed=1 AND display_allowed=1 AND offline_cache_allowed=1 AND bulk_reuse_allowed=1 AND redistribution_allowed=1 AND license_id IS NOT NULL AND license_url IS NOT NULL AND license_sha256 IS NOT NULL))
) STRICT;
CREATE TABLE source_snapshots (
  id INTEGER PRIMARY KEY,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  revision TEXT NOT NULL,
  retrieved_at TEXT NOT NULL,
  market_scope TEXT NOT NULL,
  snapshot_sha256 TEXT NOT NULL CHECK(length(snapshot_sha256)=64 AND snapshot_sha256 NOT GLOB '*[^0-9a-f]*'),
  license_id TEXT,
  license_url TEXT,
  license_sha256 TEXT CHECK(license_sha256 IS NULL OR (length(license_sha256)=64 AND license_sha256 NOT GLOB '*[^0-9a-f]*')),
  rights_evidence_sha256 TEXT CHECK(rights_evidence_sha256 IS NULL OR (length(rights_evidence_sha256)=64 AND rights_evidence_sha256 NOT GLOB '*[^0-9a-f]*')),
  rights_status TEXT NOT NULL CHECK(rights_status IN ('permission_required','restricted','approved_by_published_license','approved_by_written_permission')),
  commercial_use_allowed INTEGER NOT NULL DEFAULT 0 CHECK(commercial_use_allowed IN (0,1)),
  display_allowed INTEGER NOT NULL DEFAULT 0 CHECK(display_allowed IN (0,1)),
  offline_cache_allowed INTEGER NOT NULL DEFAULT 0 CHECK(offline_cache_allowed IN (0,1)),
  bulk_reuse_allowed INTEGER NOT NULL DEFAULT 0 CHECK(bulk_reuse_allowed IN (0,1)),
  redistribution_allowed INTEGER NOT NULL DEFAULT 0 CHECK(redistribution_allowed IN (0,1)),
  share_alike_required INTEGER NOT NULL DEFAULT 0 CHECK(share_alike_required IN (0,1)),
  attribution_required INTEGER NOT NULL DEFAULT 1 CHECK(attribution_required IN (0,1)),
  attribution_text TEXT,
  manifest_json TEXT NOT NULL CHECK(json_valid(manifest_json)),
  UNIQUE(source_id,revision,snapshot_sha256),
  CHECK(rights_status NOT IN ('approved_by_published_license','approved_by_written_permission') OR
    (commercial_use_allowed=1 AND display_allowed=1 AND offline_cache_allowed=1 AND bulk_reuse_allowed=1 AND redistribution_allowed=1 AND license_id IS NOT NULL AND license_url IS NOT NULL AND license_sha256 IS NOT NULL AND rights_evidence_sha256 IS NOT NULL))
) STRICT;
CREATE TABLE brands (
  id INTEGER PRIMARY KEY,
  brand_key TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  group_name TEXT NOT NULL DEFAULT 'Volkswagen Group',
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  source_snapshot_sha256 TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  review_status TEXT NOT NULL DEFAULT 'candidate' CHECK(review_status IN ('candidate','needs_review','verified','rejected','superseded')),
  FOREIGN KEY(source_id,source_revision,source_snapshot_sha256) REFERENCES source_snapshots(source_id,revision,snapshot_sha256) ON DELETE RESTRICT
) STRICT;
CREATE TABLE vehicle_models (
  id INTEGER PRIMARY KEY,
  brand_id INTEGER NOT NULL REFERENCES brands(id) ON DELETE RESTRICT,
  model_key TEXT NOT NULL,
  display_name TEXT NOT NULL,
  market_scope TEXT NOT NULL,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  source_snapshot_sha256 TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  applicability_precision TEXT NOT NULL,
  review_status TEXT NOT NULL DEFAULT 'candidate' CHECK(review_status IN ('candidate','needs_review','verified','rejected','superseded')),
  UNIQUE(brand_id,model_key,source_id,source_revision,source_record_key),
  FOREIGN KEY(source_id,source_revision,source_snapshot_sha256) REFERENCES source_snapshots(source_id,revision,snapshot_sha256) ON DELETE RESTRICT
) STRICT;
CREATE TABLE vehicle_generations (
  id INTEGER PRIMARY KEY,
  model_id INTEGER NOT NULL REFERENCES vehicle_models(id) ON DELETE RESTRICT,
  generation_key TEXT NOT NULL,
  display_name TEXT NOT NULL,
  platform_code TEXT,
  model_year_start INTEGER,
  model_year_end INTEGER,
  production_start TEXT,
  production_end TEXT,
  market_scope TEXT NOT NULL,
  applicability_precision TEXT NOT NULL,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  source_snapshot_sha256 TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  review_status TEXT NOT NULL DEFAULT 'candidate' CHECK(review_status IN ('candidate','needs_review','verified','rejected','superseded')),
  UNIQUE(model_id,generation_key,source_id,source_revision,source_record_key),
  CHECK(model_year_start IS NULL OR model_year_end IS NULL OR model_year_start<=model_year_end),
  FOREIGN KEY(source_id,source_revision,source_snapshot_sha256) REFERENCES source_snapshots(source_id,revision,snapshot_sha256) ON DELETE RESTRICT
) STRICT;
CREATE TABLE engines (
  id INTEGER PRIMARY KEY,
  engine_code TEXT NOT NULL,
  engine_family TEXT,
  fuel_type TEXT,
  displacement_cc INTEGER,
  power_kw REAL,
  market_scope TEXT NOT NULL,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  source_snapshot_sha256 TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  applicability_precision TEXT NOT NULL,
  review_status TEXT NOT NULL DEFAULT 'candidate' CHECK(review_status IN ('candidate','needs_review','verified','rejected','superseded')),
  UNIQUE(engine_code,source_id,source_revision,source_record_key),
  CHECK(displacement_cc IS NULL OR displacement_cc>0),
  FOREIGN KEY(source_id,source_revision,source_snapshot_sha256) REFERENCES source_snapshots(source_id,revision,snapshot_sha256) ON DELETE RESTRICT
) STRICT;
CREATE TABLE transmissions (
  id INTEGER PRIMARY KEY,
  transmission_code TEXT NOT NULL,
  transmission_type TEXT,
  gears INTEGER,
  drive_type TEXT,
  market_scope TEXT NOT NULL,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  source_snapshot_sha256 TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  applicability_precision TEXT NOT NULL,
  review_status TEXT NOT NULL DEFAULT 'candidate' CHECK(review_status IN ('candidate','needs_review','verified','rejected','superseded')),
  UNIQUE(transmission_code,source_id,source_revision,source_record_key),
  CHECK(gears IS NULL OR gears>0),
  FOREIGN KEY(source_id,source_revision,source_snapshot_sha256) REFERENCES source_snapshots(source_id,revision,snapshot_sha256) ON DELETE RESTRICT
) STRICT;
CREATE TABLE engine_transmission_pairs (
  id INTEGER PRIMARY KEY,
  engine_id INTEGER NOT NULL REFERENCES engines(id) ON DELETE RESTRICT,
  transmission_id INTEGER NOT NULL REFERENCES transmissions(id) ON DELETE RESTRICT,
  generation_id INTEGER REFERENCES vehicle_generations(id) ON DELETE RESTRICT,
  market_scope TEXT NOT NULL,
  applicability_precision TEXT NOT NULL,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  source_snapshot_sha256 TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  review_status TEXT NOT NULL DEFAULT 'candidate' CHECK(review_status IN ('candidate','needs_review','verified','rejected','superseded')),
  UNIQUE(engine_id,transmission_id,generation_id,source_id,source_revision,source_record_key),
  FOREIGN KEY(source_id,source_revision,source_snapshot_sha256) REFERENCES source_snapshots(source_id,revision,snapshot_sha256) ON DELETE RESTRICT
) STRICT;
CREATE TABLE ecu_units (
  id INTEGER PRIMARY KEY,
  manufacturer TEXT,
  ecu_family TEXT NOT NULL,
  hardware_number TEXT,
  software_number TEXT,
  ecu_address TEXT,
  market_scope TEXT NOT NULL,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  source_snapshot_sha256 TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  applicability_precision TEXT NOT NULL,
  review_status TEXT NOT NULL DEFAULT 'candidate' CHECK(review_status IN ('candidate','needs_review','verified','rejected','superseded')),
  UNIQUE(ecu_family,hardware_number,software_number,source_id,source_revision,source_record_key),
  FOREIGN KEY(source_id,source_revision,source_snapshot_sha256) REFERENCES source_snapshots(source_id,revision,snapshot_sha256) ON DELETE RESTRICT
) STRICT;
CREATE TABLE vehicle_configurations (
  id INTEGER PRIMARY KEY,
  generation_id INTEGER NOT NULL REFERENCES vehicle_generations(id) ON DELETE RESTRICT,
  engine_id INTEGER REFERENCES engines(id) ON DELETE RESTRICT,
  transmission_id INTEGER REFERENCES transmissions(id) ON DELETE RESTRICT,
  ecu_id INTEGER REFERENCES ecu_units(id) ON DELETE RESTRICT,
  market_scope TEXT NOT NULL,
  model_year INTEGER,
  production_date TEXT,
  body_code TEXT,
  drive_type TEXT,
  pr_codes_json TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(pr_codes_json)),
  applicability_precision TEXT NOT NULL,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  source_snapshot_sha256 TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  review_status TEXT NOT NULL DEFAULT 'candidate' CHECK(review_status IN ('candidate','needs_review','verified','rejected','superseded')),
  UNIQUE(generation_id,engine_id,transmission_id,ecu_id,market_scope,model_year,source_id,source_revision,source_record_key)
  FOREIGN KEY(source_id,source_revision,source_snapshot_sha256) REFERENCES source_snapshots(source_id,revision,snapshot_sha256) ON DELETE RESTRICT
) STRICT;
CREATE TABLE technical_records (
  id INTEGER PRIMARY KEY,
  record_type TEXT NOT NULL CHECK(record_type IN ('vehicle_generation','engine','transmission','engine_transmission_pair','ecu_reference','vehicle_configuration','dtc_generic','dtc_vag_specific','diagnostic_test_plan','repair_procedure','wiring_diagram','pinout','torque_specification','adaptation','service_interval','oem_part','oem_supersession')),
  namespace TEXT,
  natural_key TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT,
  market_scope TEXT NOT NULL,
  applicability_precision TEXT NOT NULL,
  configuration_id INTEGER REFERENCES vehicle_configurations(id) ON DELETE RESTRICT,
  ecu_id INTEGER REFERENCES ecu_units(id) ON DELETE RESTRICT,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  source_snapshot_sha256 TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
  review_status TEXT NOT NULL DEFAULT 'needs_review' CHECK(review_status IN ('candidate','needs_review','verified','rejected','superseded')),
  supersedes_id INTEGER REFERENCES technical_records(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL,
  UNIQUE(source_id,source_record_key,source_revision),
  FOREIGN KEY(source_id,source_revision,source_snapshot_sha256) REFERENCES source_snapshots(source_id,revision,snapshot_sha256) ON DELETE RESTRICT,
  CHECK(record_type!='dtc_generic' OR (namespace='generic_sae_iso_obd2' AND configuration_id IS NULL AND ecu_id IS NULL AND applicability_precision='generic_standard')),
  CHECK(record_type!='dtc_vag_specific' OR (namespace='vag_oem_specific' AND configuration_id IS NOT NULL AND ecu_id IS NOT NULL AND applicability_precision IN ('exact_configuration','exact_ecu')))
) STRICT;
CREATE TABLE local_user_vehicles (
  id INTEGER PRIMARY KEY,
  nickname TEXT NOT NULL,
  brand_name TEXT NOT NULL,
  model_name TEXT NOT NULL,
  generation_name TEXT,
  market_scope TEXT NOT NULL DEFAULT 'UNKNOWN',
  model_year INTEGER,
  engine_code_declared TEXT,
  transmission_code_declared TEXT,
  ecu_declared TEXT,
  pr_codes_json TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(pr_codes_json)),
  configuration_id INTEGER REFERENCES vehicle_configurations(id) ON DELETE RESTRICT,
  identity_status TEXT NOT NULL DEFAULT 'user_declared_unverified' CHECK(identity_status IN ('user_declared_unverified','exact_configuration_verified')),
  notes TEXT,
  is_default INTEGER NOT NULL DEFAULT 0 CHECK(is_default IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(identity_status!='exact_configuration_verified' OR configuration_id IS NOT NULL)
) STRICT;
CREATE UNIQUE INDEX local_user_vehicles_one_default ON local_user_vehicles(is_default) WHERE is_default=1;
CREATE TABLE local_bookmarks (
  id INTEGER PRIMARY KEY,
  target_type TEXT NOT NULL CHECK(target_type IN ('technical_record','research_record','vehicle_candidate')),
  target_key TEXT NOT NULL,
  label TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(target_type,target_key)
) STRICT;
CREATE TABLE local_query_history (
  id INTEGER PRIMARY KEY,
  query_text TEXT NOT NULL,
  module_code TEXT NOT NULL CHECK(module_code IN ('MECHANIC','ELECTRICIAN','DIAGNOSTIC','CATALOG')),
  configuration_id INTEGER REFERENCES vehicle_configurations(id) ON DELETE RESTRICT,
  result_count INTEGER NOT NULL DEFAULT 0 CHECK(result_count>=0),
  created_at TEXT NOT NULL
) STRICT;
CREATE TABLE import_batches (
  id INTEGER PRIMARY KEY,
  package_id TEXT NOT NULL,
  source_id TEXT NOT NULL REFERENCES sources(source_id) ON DELETE RESTRICT,
  source_revision TEXT NOT NULL,
  market_scope TEXT NOT NULL,
  package_sha256 TEXT NOT NULL CHECK(length(package_sha256)=64),
  status TEXT NOT NULL CHECK(status IN ('validated','applied','rejected')),
  records_seen INTEGER NOT NULL DEFAULT 0,
  records_inserted INTEGER NOT NULL DEFAULT 0,
  records_unchanged INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  completed_at TEXT,
  UNIQUE(package_id,package_sha256)
) STRICT;
CREATE TABLE import_items (
  id INTEGER PRIMARY KEY,
  batch_id INTEGER NOT NULL REFERENCES import_batches(id) ON DELETE CASCADE,
  record_type TEXT NOT NULL,
  natural_key TEXT NOT NULL,
  source_record_key TEXT NOT NULL,
  record_sha256 TEXT NOT NULL CHECK(length(record_sha256)=64),
  status TEXT NOT NULL CHECK(status IN ('inserted','unchanged','rejected')),
  error TEXT,
  UNIQUE(batch_id,record_type,natural_key,source_record_key)
) STRICT;
CREATE TABLE audit_events (
  id INTEGER PRIMARY KEY,
  event_type TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_key TEXT NOT NULL,
  details_json TEXT NOT NULL CHECK(json_valid(details_json)),
  created_at TEXT NOT NULL
) STRICT;
CREATE INDEX idx_vehicle_models_brand ON vehicle_models(brand_id,display_name);
CREATE INDEX idx_vehicle_generations_model ON vehicle_generations(model_id,model_year_start,model_year_end);
CREATE INDEX idx_engine_pairs_engine ON engine_transmission_pairs(engine_id,transmission_id);
CREATE INDEX idx_vehicle_config_generation ON vehicle_configurations(generation_id,market_scope,model_year);
CREATE INDEX idx_technical_type_status ON technical_records(record_type,review_status,market_scope);
CREATE INDEX idx_technical_config_type ON technical_records(configuration_id,record_type,review_status);
CREATE INDEX idx_technical_ecu_type ON technical_records(ecu_id,record_type,review_status);
CREATE INDEX idx_import_batches_source ON import_batches(source_id,created_at);
CREATE INDEX idx_history_created ON local_query_history(created_at DESC);
CREATE TRIGGER trg_verified_source_insert BEFORE INSERT ON technical_records
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified technical records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_verified_source_update BEFORE UPDATE OF review_status ON technical_records
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified technical records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_verified_fitment_insert BEFORE INSERT ON technical_records
WHEN NEW.review_status='verified' AND NEW.record_type IN ('dtc_vag_specific','diagnostic_test_plan','repair_procedure','wiring_diagram','pinout','torque_specification','adaptation','service_interval','oem_part','oem_supersession')
 AND (NEW.configuration_id IS NULL OR NEW.applicability_precision NOT IN ('exact_configuration','exact_ecu'))
BEGIN SELECT RAISE(ABORT,'verified technical records require exact configuration applicability'); END;
CREATE TRIGGER trg_verified_fitment_update BEFORE UPDATE OF review_status,configuration_id,applicability_precision ON technical_records
WHEN NEW.review_status='verified' AND NEW.record_type IN ('dtc_vag_specific','diagnostic_test_plan','repair_procedure','wiring_diagram','pinout','torque_specification','adaptation','service_interval','oem_part','oem_supersession')
 AND (NEW.configuration_id IS NULL OR NEW.applicability_precision NOT IN ('exact_configuration','exact_ecu'))
BEGIN SELECT RAISE(ABORT,'verified technical records require exact configuration applicability'); END;
CREATE TRIGGER trg_verified_ecu_reference_insert BEFORE INSERT ON technical_records
WHEN NEW.review_status='verified' AND NEW.record_type='ecu_reference' AND (NEW.ecu_id IS NULL OR NEW.applicability_precision!='exact_ecu')
BEGIN SELECT RAISE(ABORT,'verified ECU references require an exact ECU identity'); END;
CREATE TRIGGER trg_verified_ecu_reference_update BEFORE UPDATE OF review_status,ecu_id,applicability_precision ON technical_records
WHEN NEW.review_status='verified' AND NEW.record_type='ecu_reference' AND (NEW.ecu_id IS NULL OR NEW.applicability_precision!='exact_ecu')
BEGIN SELECT RAISE(ABORT,'verified ECU references require an exact ECU identity'); END;
CREATE TRIGGER trg_brands_verified_source_insert BEFORE INSERT ON brands
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_brands_verified_source_update BEFORE UPDATE OF review_status ON brands
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_vehicle_models_verified_source_insert BEFORE INSERT ON vehicle_models
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_vehicle_models_verified_source_update BEFORE UPDATE OF review_status ON vehicle_models
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_vehicle_generations_verified_source_insert BEFORE INSERT ON vehicle_generations
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_vehicle_generations_verified_source_update BEFORE UPDATE OF review_status ON vehicle_generations
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_engines_verified_source_insert BEFORE INSERT ON engines
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_engines_verified_source_update BEFORE UPDATE OF review_status ON engines
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_transmissions_verified_source_insert BEFORE INSERT ON transmissions
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_transmissions_verified_source_update BEFORE UPDATE OF review_status ON transmissions
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_engine_transmission_pairs_verified_source_insert BEFORE INSERT ON engine_transmission_pairs
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_engine_transmission_pairs_verified_source_update BEFORE UPDATE OF review_status ON engine_transmission_pairs
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_ecu_units_verified_source_insert BEFORE INSERT ON ecu_units
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_ecu_units_verified_source_update BEFORE UPDATE OF review_status ON ecu_units
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_vehicle_configurations_verified_source_insert BEFORE INSERT ON vehicle_configurations
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_vehicle_configurations_verified_source_update BEFORE UPDATE OF review_status ON vehicle_configurations
WHEN NEW.review_status='verified' AND NOT EXISTS (
  SELECT 1 FROM sources s WHERE s.source_id=NEW.source_id AND s.status='approved'
    AND s.rights_status IN ('approved_by_published_license','approved_by_written_permission')
    AND s.commercial_use_allowed=1 AND s.display_allowed=1 AND s.offline_cache_allowed=1
    AND s.bulk_reuse_allowed=1 AND s.redistribution_allowed=1
)
BEGIN SELECT RAISE(ABORT,'verified catalog records require an approved rights-cleared source'); END;
CREATE TRIGGER trg_verified_configuration_exact_insert BEFORE INSERT ON vehicle_configurations
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_configuration' OR NEW.engine_id IS NULL OR NEW.transmission_id IS NULL OR NEW.market_scope='UNKNOWN' OR (NEW.model_year IS NULL AND NEW.production_date IS NULL))
BEGIN SELECT RAISE(ABORT,'verified configurations require exact engine, transmission, market and production scope'); END;
CREATE TRIGGER trg_verified_configuration_exact_update BEFORE UPDATE OF review_status,applicability_precision,engine_id,transmission_id,market_scope,model_year,production_date ON vehicle_configurations
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_configuration' OR NEW.engine_id IS NULL OR NEW.transmission_id IS NULL OR NEW.market_scope='UNKNOWN' OR (NEW.model_year IS NULL AND NEW.production_date IS NULL))
BEGIN SELECT RAISE(ABORT,'verified configurations require exact engine, transmission, market and production scope'); END;
CREATE TRIGGER trg_verified_pair_exact_insert BEFORE INSERT ON engine_transmission_pairs
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_pairing' OR NEW.generation_id IS NULL OR NEW.market_scope='UNKNOWN')
BEGIN SELECT RAISE(ABORT,'verified engine/transmission pairs require exact generation and market scope'); END;
CREATE TRIGGER trg_verified_pair_exact_update BEFORE UPDATE OF review_status,applicability_precision,generation_id,market_scope ON engine_transmission_pairs
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_pairing' OR NEW.generation_id IS NULL OR NEW.market_scope='UNKNOWN')
BEGIN SELECT RAISE(ABORT,'verified engine/transmission pairs require exact generation and market scope'); END;
CREATE TRIGGER trg_verified_model_exact_insert BEFORE INSERT ON vehicle_models
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_model' OR NEW.market_scope='UNKNOWN')
BEGIN SELECT RAISE(ABORT,'verified model records require exact model and market scope'); END;
CREATE TRIGGER trg_verified_model_exact_update BEFORE UPDATE OF review_status,applicability_precision,market_scope ON vehicle_models
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_model' OR NEW.market_scope='UNKNOWN')
BEGIN SELECT RAISE(ABORT,'verified model records require exact model and market scope'); END;
CREATE TRIGGER trg_verified_generation_exact_insert BEFORE INSERT ON vehicle_generations
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_generation' OR NEW.market_scope='UNKNOWN' OR (NEW.model_year_start IS NULL AND NEW.production_start IS NULL))
BEGIN SELECT RAISE(ABORT,'verified generations require market and production-year scope'); END;
CREATE TRIGGER trg_verified_generation_exact_update BEFORE UPDATE OF review_status,applicability_precision,market_scope,model_year_start,production_start ON vehicle_generations
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_generation' OR NEW.market_scope='UNKNOWN' OR (NEW.model_year_start IS NULL AND NEW.production_start IS NULL))
BEGIN SELECT RAISE(ABORT,'verified generations require market and production-year scope'); END;
CREATE TRIGGER trg_verified_engine_exact_insert BEFORE INSERT ON engines
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_engine' OR NEW.market_scope='UNKNOWN' OR trim(NEW.engine_code)='')
BEGIN SELECT RAISE(ABORT,'verified engines require an exact factory code and market scope'); END;
CREATE TRIGGER trg_verified_engine_exact_update BEFORE UPDATE OF review_status,applicability_precision,market_scope,engine_code ON engines
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_engine' OR NEW.market_scope='UNKNOWN' OR trim(NEW.engine_code)='')
BEGIN SELECT RAISE(ABORT,'verified engines require an exact factory code and market scope'); END;
CREATE TRIGGER trg_verified_transmission_exact_insert BEFORE INSERT ON transmissions
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_transmission' OR NEW.market_scope='UNKNOWN' OR trim(NEW.transmission_code)='')
BEGIN SELECT RAISE(ABORT,'verified transmissions require an exact factory code and market scope'); END;
CREATE TRIGGER trg_verified_transmission_exact_update BEFORE UPDATE OF review_status,applicability_precision,market_scope,transmission_code ON transmissions
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_transmission' OR NEW.market_scope='UNKNOWN' OR trim(NEW.transmission_code)='')
BEGIN SELECT RAISE(ABORT,'verified transmissions require an exact factory code and market scope'); END;
CREATE TRIGGER trg_verified_ecu_exact_insert BEFORE INSERT ON ecu_units
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_ecu' OR NEW.market_scope='UNKNOWN' OR trim(NEW.ecu_family)='' OR (NEW.hardware_number IS NULL AND NEW.software_number IS NULL))
BEGIN SELECT RAISE(ABORT,'verified ECU records require an exact ECU identity and market scope'); END;
CREATE TRIGGER trg_verified_ecu_exact_update BEFORE UPDATE OF review_status,applicability_precision,market_scope,ecu_family,hardware_number,software_number ON ecu_units
WHEN NEW.review_status='verified' AND (NEW.applicability_precision!='exact_ecu' OR NEW.market_scope='UNKNOWN' OR trim(NEW.ecu_family)='' OR (NEW.hardware_number IS NULL AND NEW.software_number IS NULL))
BEGIN SELECT RAISE(ABORT,'verified ECU records require an exact ECU identity and market scope'); END;
