# OBDb VAG signal research pack

This folder contains a separate, read-only SQLite adaptation of six OBDb community signal-set repositories.

License: CC BY-SA 4.0. Commercial use is allowed under that license, subject to attribution and ShareAlike. The adapted database is distributed under CC BY-SA 4.0. Do not apply DRM or additional restrictions to copies of this database.

The SQLite file preserves pinned upstream commits, source file SHA-256 values, license copies, model labels, generation candidates, ECU headers, UDS 0x22 identifiers, signal formats, and the original filter/debug-filter JSON.

This is not factory service information. Market is UNKNOWN; exact generation, engine, gearbox, PR-code, ECU hardware, and VIN applicability are not established. All signal records are unverified community candidates. Filter fields are not interpreted. No command is executed by this pack.

The pack contains no DTC definitions, repair procedures, wiring diagrams, pinouts, torque specifications, adaptations, or service schedules. Always verify a signal definition on the actual vehicle with suitable equipment before relying on it.
