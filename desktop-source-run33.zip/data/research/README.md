# VAG TECH PRO — offline research data packs

Five separately licensed, read-only SQLite packs are shipped for offline research. The local search API opens fixed database paths in SQLite read-only/query-only mode and verifies database/provenance SHA-256 values. These packs are not production fitment tables and are not modified by imports or updates.

| Pack | License | Contents | Boundary |
|---|---|---|---|
| OBDex | CC0-1.0 | 9,533 generic SAE/ISO DTC; 132 PIDs | Generic only; never VAG-specific or vehicle-fitment evidence |
| VAG identity taxonomy | ODbL-1.0 | 5 makes; 233 models; 823 generation labels; 5,081 descriptive engine variants | Market UNKNOWN; no factory engine/gearbox codes or exact pairings; share-alike applies |
| OBDb UDS | CC BY-SA 4.0 | 6 repositories; 32 generation candidates; 15 ECU headers; 2,315 service-0x22 commands; 2,480 signals | Unverified candidates only; execution disabled; not factory test plans |
| VehiclesDB | CC BY 4.0 | 260 model names; 1,524 market-presence evidence rows across 14 non-RU countries | No RU evidence, generation/year, engine, gearbox, ECU or exact fitment; visible attribution and upstream notices required |
| MechanicDB Audi/VW DTC sample | ODbL-1.0; upstream DTC code spine MIT | 2 make-labelled candidate rows (1 Audi, 1 Volkswagen) | Separate SQLite; hidden pending technical review; market UNKNOWN; no exact vehicle/ECU fitment, test plans, repairs or OEM parts; attribution/share-alike required |

## Critical limits

- Russian/EAEU OTTS records are not included in distributable packs. Public access does not establish commercial reuse/cache/redistribution rights. OTTS transcriptions remain permission-blocked staging data.
- Generic OBDex DTC/PIDs are kept separate from manufacturer-controlled DTC candidates and VAG-specific ECU mappings.
- The MechanicDB sample is not an OEM-confirmed VAG DTC corpus. Its two make-labelled rows are not shown in diagnostic search and cannot be used for a test plan or repair recommendation.
- ODbL and CC BY-SA databases remain separate files; their share-alike obligations must be preserved.
- VehiclesDB is only a foreign-market identity aid; it cannot establish Russian or EAEU applicability.
- OBDb UDS community candidates are never executed by the desktop.

## Verification and integration

Run `npm run verify:local-research` to validate license/provenance hashes, SQLite integrity, foreign keys, exact row counts and candidate-only invariants.

The MechanicDB artifact is integrated with `npm run integrate:mechanicdb-candidate -- --input <extracted-artifact-directory>`. The importer validates the complete artifact and pinned source lines before staging, copies into a new pack directory, then atomically replaces the root manifest. It is idempotent for the same database/manifest hashes and refuses to overwrite a different pack. `--dry-run` validates without writing.

See `docs/RESEARCH_DATA_PACKS.md` for the full source and rights record.
