"use strict";
const fs = require("node:fs");
const path = require("node:path");
const net = require("node:net");
const http = require("node:http");

function reserveLoopbackPort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      server.close((error) => error ? reject(error) : resolve(port));
    });
  });
}
function resolveRuntimeDirectory({ isPackaged, resourcesPath, appPath }) {
  return isPackaged ? path.join(resourcesPath, "app-runtime") : path.resolve(appPath, ".next", "standalone");
}
function probeHttp(url, timeoutMs = 1500) {
  return new Promise((resolve) => {
    const request = http.get(url, (response) => { response.resume(); resolve(response.statusCode >= 200 && response.statusCode < 500); });
    request.setTimeout(timeoutMs, () => request.destroy());
    request.once("error", () => resolve(false));
  });
}
async function waitForServer(url, child, timeoutMs = 45000, isAlive = () => child.exitCode === null) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (!isAlive()) throw new Error("Local application server exited before becoming ready");
    if (await probeHttp(url)) return true;
    await new Promise((resolve) => setTimeout(resolve, 300));
  }
  throw new Error("Local application server did not become ready within 45 seconds");
}
function createLogWriter(logPath) {
  fs.mkdirSync(path.dirname(logPath), { recursive: true });
  return (line) => fs.appendFileSync(logPath, `${new Date().toISOString()} ${line}\n`, "utf8");
}
let mainWindow;
async function bootstrap() {
  const { app, BrowserWindow, dialog, shell, utilityProcess } = require("electron");
  if (!app.requestSingleInstanceLock()) {
    app.quit();
    return;
  }
  app.on("second-instance", () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
  });
  app.on("window-all-closed", () => app.quit());
  const appDataRoot = path.join(app.getPath("appData"), "VAG TECH PRO");
  fs.mkdirSync(appDataRoot, { recursive: true });
  app.setPath("userData", appDataRoot);
  const log = createLogWriter(path.join(appDataRoot, "logs", "desktop.log"));
  const dataRoot = path.join(appDataRoot, "data");
  fs.mkdirSync(dataRoot, { recursive: true });
  const researchRoot = app.isPackaged
    ? path.join(process.resourcesPath, "research-data")
    : path.join(app.getAppPath(), "data", "research");
  process.env.VAG_TECH_PRO_DATA_DIR = dataRoot;
  process.env.VAG_TECH_PRO_DB_PATH = path.join(dataRoot, "vag-tech-pro.sqlite");
  process.env.VAG_TECH_PRO_RESEARCH_DIR = researchRoot;
  log(fs.existsSync(path.join(researchRoot, "manifest.json"))
    ? `research-data-ready ${researchRoot}`
    : `research-data-missing ${researchRoot}`);
  let serverProcess;
  let serverExited = false;
  let shuttingDown = false;
  const stopServer = () => { if (serverProcess && !serverExited) serverProcess.kill(); };
  app.on("before-quit", () => { shuttingDown = true; stopServer(); });
  await app.whenReady();
  try {
    const runtimeDirectory = resolveRuntimeDirectory({ isPackaged: app.isPackaged, resourcesPath: process.resourcesPath, appPath: app.getAppPath() });
    const serverEntry = path.join(runtimeDirectory, "server.js");
    if (!fs.existsSync(serverEntry)) throw new Error(`Missing standalone server: ${serverEntry}`);
    const port = await reserveLoopbackPort();
    serverProcess = utilityProcess.fork(serverEntry, [], {
      cwd: runtimeDirectory,
      env: { ...process.env, PORT: String(port), HOSTNAME: "127.0.0.1", NODE_ENV: "production", VAG_TECH_PRO_DATA_DIR: dataRoot, VAG_TECH_PRO_DB_PATH: process.env.VAG_TECH_PRO_DB_PATH, VAG_TECH_PRO_RESEARCH_DIR: researchRoot },
      serviceName: "VAG TECH PRO local server",
      stdio: "pipe"
    });
    serverProcess.stdout?.on("data", (chunk) => log(`server stdout: ${String(chunk).trim()}`));
    serverProcess.stderr?.on("data", (chunk) => log(`server stderr: ${String(chunk).trim()}`));
    serverProcess.once("error", (error) => log(`server utility error: ${error.message || JSON.stringify(error)}`));
    serverProcess.once("exit", (code) => { serverExited = true; log(`server exit: code=${code}`); if (!shuttingDown) app.quit(); });
    const url = `http://127.0.0.1:${port}`;
    await waitForServer(url, serverProcess, 45000, () => !serverExited);
    log(`server-ready ${url}`);
    mainWindow = new BrowserWindow({
      width: 1440, height: 920, minWidth: 1024, minHeight: 680, show: false, autoHideMenuBar: true, backgroundColor: "#0b0f14",
      webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true }
    });
    mainWindow.webContents.setWindowOpenHandler(({ url: target }) => { if (target.startsWith("https://")) shell.openExternal(target); return { action: "deny" }; });
    const localOrigin = new URL(url).origin;
    mainWindow.webContents.on("will-navigate", (event, target) => {
      try { if (new URL(target).origin !== localOrigin) event.preventDefault(); }
      catch { event.preventDefault(); }
    });
    mainWindow.once("ready-to-show", () => mainWindow.show());
    await mainWindow.loadURL(url);
  } catch (error) {
    log(`fatal startup error: ${error.stack || error.message}`);
    dialog.showErrorBox("VAG TECH PRO", `Не удалось запустить локальное приложение.\n\n${error.message}`);
    app.quit();
  }
}
module.exports = { reserveLoopbackPort, resolveRuntimeDirectory, probeHttp, waitForServer };
if (process.versions.electron) bootstrap().catch((error) => {
  try { require("electron").dialog.showErrorBox("VAG TECH PRO", error.message); } catch {}
  process.exitCode = 1;
});
