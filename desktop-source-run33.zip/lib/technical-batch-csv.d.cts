export type CsvBatchItem = {
  record_type: string;
  natural_key: string | null;
  payload: Record<string, unknown>;
};
export function parseCsvRows(text: string): string[][];
export function parseCsvBatch(text: string): { items: CsvBatchItem[] };
