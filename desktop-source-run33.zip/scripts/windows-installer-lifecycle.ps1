param(
  [Parameter(Mandatory = $true)][string]$InstallerPath,
  [Parameter(Mandatory = $true)][string]$UpgradeInstallerPath
)
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

if ($env:CI -ne "true") { throw "This destructive install/uninstall test is restricted to an isolated CI runner." }
foreach ($candidate in @($InstallerPath, $UpgradeInstallerPath)) {
  if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { throw "Installer not found: $candidate" }
}
$firstVersion = [version](Get-Item -LiteralPath $InstallerPath).VersionInfo.ProductVersion
$upgradeVersion = [version](Get-Item -LiteralPath $UpgradeInstallerPath).VersionInfo.ProductVersion
if ($upgradeVersion -le $firstVersion) { throw "Upgrade installer version ($upgradeVersion) must be newer than initial installer ($firstVersion)." }

$installDir = Join-Path $env:RUNNER_TEMP "VAG TECH PRO Lifecycle"
$appData = Join-Path $env:APPDATA "VAG TECH PRO"
$dataDir = Join-Path $appData "data"
$dbPath = Join-Path $dataDir "vag-tech-pro.sqlite"
$logPath = Join-Path $appData "logs\desktop.log"
$backupPath = Join-Path $env:RUNNER_TEMP "vag-tech-pro-lifecycle.sqlite"
$appExe = Join-Path $installDir "VAG TECH PRO.exe"

if (Test-Path -LiteralPath $appData) { throw "CI profile is not clean; refusing to overwrite existing user data: $appData" }
if (Test-Path -LiteralPath $installDir) { Remove-Item -LiteralPath $installDir -Recurse -Force }
if (Test-Path -LiteralPath $backupPath) { Remove-Item -LiteralPath $backupPath -Force }

function Install-NSIS([string]$Path) {
  $process = Start-Process -FilePath $Path -ArgumentList @("/S", "/D=$installDir") -Wait -PassThru
  if ($process.ExitCode -ne 0) { throw "NSIS installer failed with exit code $($process.ExitCode): $Path" }
  if (-not (Test-Path -LiteralPath $appExe)) { throw "Installed application executable is missing: $appExe" }
}

function Start-DesktopAndWait {
  if (Test-Path -LiteralPath $logPath) { Remove-Item -LiteralPath $logPath -Force }
  $process = Start-Process -FilePath $appExe -PassThru
  $deadline = (Get-Date).AddSeconds(60)
  $baseUrl = $null
  while ((Get-Date) -lt $deadline) {
    Start-Sleep -Seconds 2
    if (Test-Path -LiteralPath $logPath) {
      $match = Select-String -Path $logPath -Pattern "server-ready (http://127\.0\.0\.1:\d+)" | Select-Object -Last 1
      if ($match -and $match.Matches.Count -gt 0) { $baseUrl = $match.Matches[0].Groups[1].Value; break }
    }
    if ($process.HasExited) { throw "Desktop process exited before local server readiness." }
  }
  if (-not $baseUrl) { throw "Local Next.js server did not report readiness within 60 seconds; see $logPath" }
  $page = Invoke-WebRequest -Uri $baseUrl -TimeoutSec 20
  if ($page.StatusCode -ne 200 -or $page.Content -notmatch "Офлайн-режим") { throw "The application did not open its offline workspace." }
  $summary = Invoke-RestMethod -Uri "$baseUrl/api/local-core?action=admin-summary" -TimeoutSec 20
  if ($summary.mode -ne "offline_local_sqlite_admin") { throw "The local SQLite API did not initialize in offline mode." }
  if (-not (Test-Path -LiteralPath $dbPath)) { throw "The per-user SQLite database was not created: $dbPath" }
  return @{ Process = $process; BaseUrl = $baseUrl }
}

function Stop-Desktop($session) {
  if ($session -and $session.Process -and -not $session.Process.HasExited) {
    $closed = $session.Process.CloseMainWindow()
    if (-not $closed -or -not $session.Process.WaitForExit(15000)) {
      Stop-Process -Id $session.Process.Id -Force -ErrorAction SilentlyContinue
      $session.Process.WaitForExit(10000) | Out-Null
    }
  }
  Start-Sleep -Seconds 2
}

function Invoke-LocalJsonPost([string]$BaseUrl, [hashtable]$Body) {
  return Invoke-RestMethod -Uri "$BaseUrl/api/local-core" -Method Post -Headers @{ Origin = $BaseUrl } -ContentType "application/json" -Body ($Body | ConvertTo-Json -Depth 10) -TimeoutSec 30
}

function Invoke-BackupRestore([string]$BaseUrl, [string]$Path) {
  $client = [System.Net.Http.HttpClient]::new()
  try {
    $multipart = [System.Net.Http.MultipartFormDataContent]::new()
    $action = [System.Net.Http.StringContent]::new("backup.restore")
    $multipart.Add($action, "action")
    $fileBytes = [System.IO.File]::ReadAllBytes($Path)
    $fileContent = [System.Net.Http.ByteArrayContent]::new($fileBytes)
    $fileContent.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse("application/vnd.sqlite3")
    $multipart.Add($fileContent, "file", [System.IO.Path]::GetFileName($Path))
    $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Post, "$BaseUrl/api/local-core")
    $request.Headers.Add("Origin", $BaseUrl)
    $request.Content = $multipart
    $response = $client.SendAsync($request).GetAwaiter().GetResult()
    $responseText = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
    if (-not $response.IsSuccessStatusCode) { throw "SQLite restore failed: HTTP $([int]$response.StatusCode) $responseText" }
    return ($responseText | ConvertFrom-Json)
  } finally { $client.Dispose() }
}

function Get-VehicleRows([string]$BaseUrl) {
  $response = Invoke-RestMethod -Uri "$BaseUrl/api/local-core?action=vehicles" -TimeoutSec 20
  return @($response.rows)
}

function Assert-Database([string]$ExpectedNickname) {
  if (-not (Test-Path -LiteralPath $dbPath)) { throw "User database is missing: $dbPath" }
  $code = @'
const { DatabaseSync } = require('node:sqlite');
const db = new DatabaseSync(process.argv[1], { readOnly: true });
const integrity = db.prepare('PRAGMA integrity_check').get().integrity_check;
const foreignKeyViolations = db.prepare('PRAGMA foreign_key_check').all();
const rows = db.prepare('SELECT nickname FROM local_user_vehicles ORDER BY id').all();
db.close();
console.log(JSON.stringify({ integrity, foreignKeyViolations, rows }));
'@
  $result = (& node --experimental-sqlite -e $code $dbPath | ConvertFrom-Json)
  if ($result.integrity -ne "ok") { throw "SQLite integrity check failed after install lifecycle: $($result.integrity)" }
  if (@($result.foreignKeyViolations).Count -ne 0) { throw "SQLite foreign-key check failed after install lifecycle." }
  if (@($result.rows).Count -ne 1 -or $result.rows[0].nickname -ne $ExpectedNickname) { throw "User vehicle data was not preserved. Found: $($result.rows | ConvertTo-Json -Compress)" }
}

# 1. Clean install and first offline launch.
Install-NSIS $InstallerPath
$session = Start-DesktopAndWait
$origin = $session.BaseUrl

# 2. Create real user data and a validated backup.
$null = Invoke-LocalJsonPost $origin @{ action = "vehicle.save"; vehicle = @{ brand_name = "Audi"; model_name = "A4"; nickname = "Lifecycle vehicle"; market_scope = "UNKNOWN"; is_default = $true } }
$backupClient = [System.Net.Http.HttpClient]::new()
try {
  $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Post, "$origin/api/local-core")
  $request.Headers.Add("Origin", $origin)
  $request.Content = [System.Net.Http.StringContent]::new('{"action":"backup.create"}', [System.Text.Encoding]::UTF8, "application/json")
  $response = $backupClient.SendAsync($request).GetAwaiter().GetResult()
  if (-not $response.IsSuccessStatusCode) { throw "Backup export failed: HTTP $([int]$response.StatusCode)" }
  $bytes = $response.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()
  [System.IO.File]::WriteAllBytes($backupPath, $bytes)
  $expectedHash = ($response.Headers.GetValues("X-Backup-SHA256") | Select-Object -First 1).ToLowerInvariant()
  $actualHash = (Get-FileHash -LiteralPath $backupPath -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actualHash -ne $expectedHash) { throw "Backup SHA-256 mismatch." }
} finally { $backupClient.Dispose() }

# 3. Change the database, then restore and prove the extra row disappears.
$null = Invoke-LocalJsonPost $origin @{ action = "vehicle.save"; vehicle = @{ brand_name = "Volkswagen"; model_name = "Golf"; nickname = "Must disappear after restore"; market_scope = "UNKNOWN" } }
$restoreResult = Invoke-BackupRestore $origin $backupPath
$vehicles = Get-VehicleRows $origin
if ($vehicles.Count -ne 1 -or $vehicles[0].nickname -ne "Lifecycle vehicle") { throw "Backup restore did not restore the expected user data." }
if (-not $restoreResult.restore.safetyBackup) { throw "Restore did not report the safety backup of the previous database." }
if (-not (Test-Path -LiteralPath $restoreResult.restore.safetyBackup)) { throw "Restore safety backup file is missing." }
Stop-Desktop $session

# 4. Upgrade over the previous version and verify the SQLite user data survives.
Install-NSIS $UpgradeInstallerPath
$session = Start-DesktopAndWait
$vehicles = Get-VehicleRows $session.BaseUrl
if ($vehicles.Count -ne 1 -or $vehicles[0].nickname -ne "Lifecycle vehicle") { throw "User database changed during the NSIS upgrade." }
Stop-Desktop $session

# 5. Uninstall the application; the per-user SQLite database must remain intact.
$uninstaller = Get-ChildItem -LiteralPath $installDir -Filter "*Uninstall*.exe" | Select-Object -First 1
if (-not $uninstaller) { throw "NSIS uninstaller was not found." }
$uninstall = Start-Process -FilePath $uninstaller.FullName -ArgumentList "/S" -Wait -PassThru
if ($uninstall.ExitCode -ne 0) { throw "NSIS uninstall failed with exit code $($uninstall.ExitCode)" }
if (Test-Path -LiteralPath $appExe) { throw "Application executable remains after uninstall." }
Assert-Database "Lifecycle vehicle"
Write-Output "Windows x64 clean install, offline launch, SQLite backup/restore, in-place upgrade, integrity and uninstall-preservation checks passed."
