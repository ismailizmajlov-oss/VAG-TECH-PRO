param(
  [Parameter(Mandatory = $true)][string]$InstallerPath
)
$ErrorActionPreference = "Stop"
$installDir = Join-Path $env:RUNNER_TEMP "VAG TECH PRO Smoke"
$appData = Join-Path $env:APPDATA "VAG TECH PRO"
$marker = Join-Path $appData "data\preserve-on-uninstall.marker"

if (-not (Test-Path $InstallerPath)) { throw "Installer not found: $InstallerPath" }
if (Test-Path $installDir) { Remove-Item $installDir -Recurse -Force }
New-Item -ItemType Directory -Path (Split-Path $marker) -Force | Out-Null

$install = Start-Process -FilePath $InstallerPath -ArgumentList @("/S", "/D=$installDir") -Wait -PassThru
if ($install.ExitCode -ne 0) { throw "NSIS installation failed with exit code $($install.ExitCode)" }

$appExe = Join-Path $installDir "VAG TECH PRO.exe"
if (-not (Test-Path $appExe)) { throw "Installed application executable is missing" }
$logPath = Join-Path $appData "logs\desktop.log"
if (Test-Path $logPath) { Remove-Item $logPath -Force }
$app = Start-Process -FilePath $appExe -PassThru
$deadline = (Get-Date).AddSeconds(60)
$ready = $false
while ((Get-Date) -lt $deadline) {
  Start-Sleep -Seconds 2
  if (Test-Path $logPath) {
    $contents = Get-Content $logPath -Raw
    if ($contents -match "server-ready http://127\.0\.0\.1:\d+") { $ready = $true; break }
  }
  if ($app.HasExited) { throw "Desktop process exited before the local server became ready" }
}
if (-not $ready) { throw "Local Next.js server did not report readiness; see $logPath" }
if ($app.HasExited) { throw "Desktop process exited after server startup" }
Stop-Process -Id $app.Id -Force -ErrorAction SilentlyContinue

Set-Content -Path $marker -Value "keep" -NoNewline
$uninstaller = Get-ChildItem $installDir -Filter "*Uninstall*.exe" | Select-Object -First 1
if (-not $uninstaller) { throw "NSIS uninstaller was not found" }
$uninstall = Start-Process -FilePath $uninstaller.FullName -ArgumentList "/S" -Wait -PassThru
if ($uninstall.ExitCode -ne 0) { throw "NSIS uninstall failed with exit code $($uninstall.ExitCode)" }
if (-not (Test-Path $marker)) { throw "User data was removed during uninstall" }
Write-Output "Windows install, launch, server health and uninstall-preserves-user-data checks passed."
