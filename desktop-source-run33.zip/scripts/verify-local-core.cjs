"use strict";
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const core = require("../lib/local-core-db.cjs");

const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), "vag-tech-pro-core-verify-"));
try {
  const dbPath = path.join(tempRoot, "vag-tech-pro.sqlite");
  const migrationPath = path.resolve(__dirname, "../data/sql/local-core-v1.sql");
  const migrationSha256 = core.sha256(fs.readFileSync(migrationPath));
  if (migrationSha256 !== core.sha256(core.MIGRATION_1)) throw new Error("Versioned SQL migration does not match the runtime migration checksum");
  const initialized = core.initializeDatabase(dbPath);
  const db = core.openDatabase(dbPath);
  let tables;
  try { tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map((row) => row.name); }
  finally { db.close(); }
  const result = {
    status: "passed",
    appId: core.APP_ID,
    schemaVersion: initialized.schemaVersion,
    migrationSha256,
    integrity: initialized.integrity,
    foreignKeyViolations: initialized.foreignKeyViolations,
    tables: tables.length,
    userDataTables: ["local_user_vehicles","local_bookmarks","local_query_history"].every((name) => tables.includes(name)),
    technicalTables: ["vehicle_configurations","technical_records","sources","source_snapshots","import_batches","import_items"].every((name) => tables.includes(name)),
    temporaryDatabaseOnly: true,
  };
  if (!result.userDataTables || !result.technicalTables) throw new Error("Local core schema is missing required tables");
  process.stdout.write(`${JSON.stringify(result,null,2)}\n`);
} finally { fs.rmSync(tempRoot,{recursive:true,force:true}); }
