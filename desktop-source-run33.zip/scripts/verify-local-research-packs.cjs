#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");

const ROOT = path.resolve(__dirname, "..");
const RESEARCH = path.join(ROOT, "data", "research");
const manifestPath = path.join(RESEARCH, "manifest.json");
const sha256 = (bytes) => crypto.createHash("sha256").update(bytes).digest("hex");
const fail = (message) => { throw new Error(message); };

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); }
  catch (error) { fail(`Invalid JSON ${path.relative(ROOT, file)}: ${error.message}`); }
}
function safeFile(relativePath, expectedHash) {
  if (typeof relativePath !== "string" || !relativePath || !/^[a-f0-9]{64}$/.test(expectedHash || "")) fail(`Invalid file/hash manifest entry: ${relativePath}`);
  const base = fs.realpathSync(RESEARCH);
  const candidate = path.resolve(base, relativePath);
  const relative = path.relative(base, candidate);
  if (relative.startsWith(`..${path.sep}`) || relative === ".." || path.isAbsolute(relative)) fail(`Path escapes research root: ${relativePath}`);
  const realFile = fs.realpathSync(candidate);
  const realRelative = path.relative(base, realFile);
  if (realRelative.startsWith(`..${path.sep}`) || realRelative === ".." || path.isAbsolute(realRelative)) fail(`Symlink escapes research root: ${relativePath}`);
  const stat = fs.statSync(realFile);
  if (!stat.isFile()) fail(`Not a regular file: ${relativePath}`);
  const actual = sha256(fs.readFileSync(realFile));
  if (actual !== expectedHash) fail(`SHA-256 mismatch for ${relativePath}: ${actual}`);
  return realFile;
}
function openReadOnly(file) {
  const db = new DatabaseSync(file, { readOnly: true });
  db.exec("PRAGMA query_only=ON; PRAGMA trusted_schema=OFF;");
  const integrity = db.prepare("PRAGMA integrity_check").get().integrity_check;
  if (integrity !== "ok") fail(`${path.basename(file)} integrity_check: ${integrity}`);
  const fk = db.prepare("PRAGMA foreign_key_check").all();
  if (fk.length) fail(`${path.basename(file)} has ${fk.length} foreign-key violations`);
  return db;
}
function count(db, sql) { return Number(db.prepare(sql).get().n); }
function assert(condition, message) { if (!condition) fail(message); }
function physicalLines(bytes) {
  const lines = [];
  let start = 0;
  for (let index = 0; index < bytes.length; index += 1) {
    if (bytes[index] === 0x0a) { lines.push(bytes.subarray(start, index + 1)); start = index + 1; }
  }
  if (start < bytes.length) lines.push(bytes.subarray(start));
  return lines;
}

function run() {
  const manifest = readJson(manifestPath);
  assert(manifest.schema_version === 1 && Array.isArray(manifest.packs) && manifest.packs.length === 5, "Expected five separately licensed research packs");
  const byId = Object.fromEntries(manifest.packs.map((pack) => [pack.id, pack]));
  const ob = byId["obdex-generic-cc0"];
  const vag = byId["vag-identity-odbl"];
  const obdb = byId["obdb-vag-signals-cc-by-sa"];
  const vehiclesdb = byId["vehiclesdb-vag-identity"];
  const mechanicdb = byId["mechanicdb-vag-dtc-candidates-odbl"];
  assert(ob && vag && obdb && vehiclesdb && mechanicdb, "All five research packs must be registered");
  const manifestHash = sha256(fs.readFileSync(manifestPath));

  for (const pack of [ob, vag, obdb, vehiclesdb, mechanicdb]) safeFile(pack.database, pack.database_sha256);
  for (const pack of [ob, vag, obdb, vehiclesdb, mechanicdb]) safeFile(pack.license_file, pack.license_file_sha256);
  for (const pack of [ob, vag, obdb, vehiclesdb, mechanicdb]) safeFile(pack.source_manifest_file, pack.source_manifest_sha256);
  safeFile(ob.acquisition_report_file, ob.acquisition_report_sha256);
  safeFile(obdb.attribution_file, obdb.attribution_sha256);
  safeFile(vehiclesdb.upstream_manifest_file, vehiclesdb.upstream_manifest_sha256);
  safeFile(vehiclesdb.attribution_file, vehiclesdb.attribution_sha256);
  safeFile(mechanicdb.upstream_license_file, mechanicdb.upstream_license_file_sha256);
  safeFile(mechanicdb.attribution_file, mechanicdb.attribution_sha256);
  safeFile(mechanicdb.source_file, mechanicdb.source_file_sha256);
  safeFile(mechanicdb.sources_file, mechanicdb.sources_file_sha256);
  safeFile(mechanicdb.data_dictionary_file, mechanicdb.data_dictionary_sha256);
  safeFile(mechanicdb.sha256sums_file, mechanicdb.sha256sums_sha256);

  // OBDex: only generic SAE/ISO OBD-II; the source commit and CC0 data license are pinned.
  const obLicense = fs.readFileSync(path.join(RESEARCH, ob.license_file), "utf8");
  assert(/CC0\s*1\.0 Universal/i.test(obLicense) && /data files/i.test(obLicense), "OBDex CC0 data license is not explicit");
  const obSnapshot = readJson(path.join(RESEARCH, ob.source_manifest_file));
  const obReport = readJson(path.join(RESEARCH, ob.acquisition_report_file));
  assert(obSnapshot.source_id === "obdex-generic-cc0" && obSnapshot.data_license === "CC0-1.0", "OBDex source manifest identity/license mismatch");
  assert(obSnapshot.commit_sha === ob.upstream_revision && obSnapshot.license_sha256 === ob.license_file_sha256, "OBDex revision/license hash mismatch");
  assert(obSnapshot.scope?.dtc_namespace === "generic_sae_iso_obd2" && obSnapshot.scope?.manufacturer_specific_codes_included === false && obSnapshot.scope?.exact_vag_fitment === false, "OBDex scope incorrectly claims manufacturer-specific or VAG fitment");
  assert(obSnapshot.source_reference_policy?.external_fetch === false && obSnapshot.source_reference_policy?.display_policy === "external_reference_link_only", "OBDex external reference policy is not restrictive");
  assert(obSnapshot.expected_counts?.generic_dtcs === 9533 && obSnapshot.expected_counts?.pids_total === 132, "OBDex expected counts mismatch");
  assert(obReport.database_sha256 === ob.database_sha256 && obReport.integrity_check === "ok" && obReport.vag_specific_dtc_rows === 0 && obReport.fitment_claims === 0 && obReport.production_rows === 0, "OBDex SQLite report failed its safety gate");
  const obSnapshotByFile = new Map((obSnapshot.source_files || []).map((item) => [item.path, item.sha256]));
  for (const [file, hash] of Object.entries(ob.source_file_sha256)) assert(obSnapshotByFile.get(file) === hash, `OBDex source manifest mismatch for ${file}`);

  // ODbL taxonomy: retained separately and strictly candidate-only pending provenance review.
  const vagLicense = fs.readFileSync(path.join(RESEARCH, vag.license_file), "utf8");
  assert(/Open Database License\s*\(ODbL\)\s*v1\.0/i.test(vagLicense) && /Share-Alike/i.test(vagLicense), "VAG identity ODbL share-alike terms are not explicit");
  const vagSnapshot = readJson(path.join(RESEARCH, vag.source_manifest_file));
  assert(vagSnapshot.revision === vag.upstream_revision && vagSnapshot.license === vag.license, "VAG identity upstream revision/license mismatch");
  assert(vagSnapshot.rights_review_status === "research_only_upstream_provenance_not_independently_verified", "VAG identity provenance must remain research-only");
  assert(JSON.stringify(vagSnapshot.counts) === JSON.stringify(vag.counts), "VAG identity source manifest counts mismatch");
  for (const [brand, hash] of Object.entries(vag.source_file_sha256)) assert(vagSnapshot.source_sha256?.[brand] === hash, `VAG identity source hash mismatch for ${brand}`);

  // OBDb: community UDS signals are read-only candidates; all per-repository notices are pinned.
  const obdbLicense = fs.readFileSync(path.join(RESEARCH, obdb.license_file), "utf8");
  assert(/Attribution-ShareAlike 4\.0 International/i.test(obdbLicense), "OBDb CC BY-SA 4.0 license text is missing");
  assert(obdb.license === "CC-BY-SA-4.0" && obdb.share_alike_required === true && obdb.attribution_required === true &&
    obdb.commercial_use_allowed === true && obdb.display_allowed === true && obdb.cache_allowed === true && obdb.redistribution_allowed === true && obdb.execution_allowed === false,
    "OBDb rights/non-execution manifest is not explicit");
  const obdbSnapshot = readJson(path.join(RESEARCH, obdb.source_manifest_file));
  assert(obdbSnapshot.dataset_id === "obdb-vag-signalsets-cc-by-sa" && obdbSnapshot.license_id === obdb.license && obdbSnapshot.database_sha256 === obdb.database_sha256, "OBDb source manifest identity/hash mismatch");
  assert(obdbSnapshot.share_alike_required === true && obdbSnapshot.attribution_required === true && obdbSnapshot.commercial_use_allowed === true && obdbSnapshot.display_allowed === true && obdbSnapshot.cache_allowed === true && obdbSnapshot.redistribution_allowed === true, "OBDb source manifest rights are incomplete");
  assert(JSON.stringify(obdbSnapshot.counts) === JSON.stringify(obdb.counts), "OBDb source manifest counts mismatch");
  const obdbAttribution = fs.readFileSync(path.join(RESEARCH, obdb.attribution_file), "utf8");
  assert(/OBDb community contributors/i.test(obdbAttribution) && /CC BY-SA 4\.0/i.test(obdbAttribution), "OBDb attribution/share-alike notice is missing");
  for (const source of obdbSnapshot.sources || []) {
    assert(/^[a-f0-9]{40}$/.test(source.commit_sha || "") && source.license_sha256 === obdb.license_file_sha256 && (source.license_id === undefined || source.license_id === obdb.license), `OBDb source identity/license mismatch for ${source.source_id}`);
    safeFile(`obdb-vag-signals-cc-by-sa/${source.license_copy}`, source.license_sha256);
    for (const file of Object.values(source.files || {})) safeFile(`obdb-vag-signals-cc-by-sa/${file.path}`, file.sha256);
  }
  assert((obdbSnapshot.sources || []).length === 6, "OBDb source registry does not contain six pinned repositories");

  // VehiclesDB: CC BY 4.0, visible credit and all upstream notices; no Russian evidence or fitment claim.
  const vehiclesDbLicense = fs.readFileSync(path.join(RESEARCH, vehiclesdb.license_file), "utf8");
  assert(/Creative Commons Attribution 4\.0 International/i.test(vehiclesDbLicense) && vehiclesdb.license === "CC-BY-4.0", "VehiclesDB CC BY 4.0 license text is missing");
  assert(vehiclesdb.attribution_required === true && vehiclesdb.ru_evidence_present === false && vehiclesdb.fitment_claim === false, "VehiclesDB rights or market boundary is not explicit");
  const vehiclesDbSnapshot = readJson(path.join(RESEARCH, vehiclesdb.source_manifest_file));
  const vehiclesDbUpstream = readJson(path.join(RESEARCH, vehiclesdb.upstream_manifest_file));
  const vehiclesDbAttribution = fs.readFileSync(path.join(RESEARCH, vehiclesdb.attribution_file), "utf8");
  assert(vehiclesDbSnapshot.dataset_id === "vehiclesdb-vag-identity-cc-by-4.0" && vehiclesDbSnapshot.dataset_license === vehiclesdb.license, "VehiclesDB dataset manifest identity/license mismatch");
  assert(vehiclesDbSnapshot.database_sha256 === vehiclesdb.database_sha256 && vehiclesDbSnapshot.ru_evidence_present === false && vehiclesDbSnapshot.fitment_claim === false, "VehiclesDB database hash or no-RU/no-fitment gate failed");
  assert(vehiclesDbSnapshot.attribution?.required === true && /Vehicle data by VehiclesDB/i.test(vehiclesDbAttribution) && /UNCONDITIONAL/i.test(vehiclesDbAttribution), "VehiclesDB attribution and upstream notices are incomplete");
  assert(vehiclesDbUpstream.version === vehiclesDbSnapshot.dataset_version && vehiclesDbUpstream.license === vehiclesdb.license, "VehiclesDB upstream manifest revision/license mismatch");
  assert(JSON.stringify(vehiclesDbSnapshot.counts) === JSON.stringify(vehiclesdb.counts), "VehiclesDB source manifest counts mismatch");
  assert(JSON.stringify(vehiclesDbSnapshot.market_scope_countries) === JSON.stringify(vehiclesdb.market_scope), "VehiclesDB market scope mismatch");
  assert(!vehiclesDbSnapshot.market_scope_countries.includes("ru") && vehiclesDbSnapshot.applicability_precision === "make_model_name_only", "VehiclesDB must not claim Russian market or exact fitment");
  const obDb = openReadOnly(path.join(RESEARCH, ob.database));
  const vagDb = openReadOnly(path.join(RESEARCH, vag.database));
  const obdbDb = openReadOnly(path.join(RESEARCH, obdb.database));
  const vehiclesDb = openReadOnly(path.join(RESEARCH, vehiclesdb.database));
  const mechanicDb = openReadOnly(path.join(RESEARCH, mechanicdb.database));
  try {
    const obCounts = {
      dtcs: count(obDb, "SELECT count(*) AS n FROM generic_dtc_research WHERE namespace='generic_sae_iso_obd2' AND verification_status='source_imported_unreviewed' AND vehicle_fitment_claim=0"),
      pids: count(obDb, "SELECT count(*) AS n FROM generic_pid_research WHERE verification_status='source_imported_unreviewed' AND vehicle_fitment_claim=0"),
      sources: count(obDb, "SELECT count(*) AS n FROM source_registry WHERE license_id='CC0-1.0' AND verification_status='license_verified_research_only'"),
      invalidDtcRows: count(obDb, "SELECT count(*) AS n FROM generic_dtc_research WHERE namespace!='generic_sae_iso_obd2' OR verification_status!='source_imported_unreviewed' OR vehicle_fitment_claim!=0"),
      invalidPidRows: count(obDb, "SELECT count(*) AS n FROM generic_pid_research WHERE verification_status!='source_imported_unreviewed' OR vehicle_fitment_claim!=0"),
    };
    assert(obCounts.dtcs === 9533 && obCounts.pids === 132 && obCounts.sources === 1 && !obCounts.invalidDtcRows && !obCounts.invalidPidRows, `OBDex count/namespace gate failed: ${JSON.stringify(obCounts)}`);
    const obSourceRow = obDb.prepare("SELECT source_version, license_sha256, source_manifest_json FROM source_registry LIMIT 1").get();
    assert(obSourceRow.source_version === ob.upstream_revision && obSourceRow.license_sha256 === ob.license_file_sha256, "OBDex DB provenance revision/license mismatch");
    const obDbManifest = JSON.parse(obSourceRow.source_manifest_json);
    assert(obDbManifest.commit_sha === obSnapshot.commit_sha && obDbManifest.license_sha256 === obSnapshot.license_sha256, "OBDex DB embedded source manifest mismatch");
    const obCodes = obDb.prepare("SELECT code FROM generic_dtc_research").all().map((row) => row.code);
    const manufacturerSpecific = obCodes.filter((code) => /^(P1[0-9A-F]{3}|P3[0-3][0-9A-F]{2}|B[12][0-9A-F]{3}|C[12][0-9A-F]{3}|U[12][0-9A-F]{3})$/i.test(code));
    assert(manufacturerSpecific.length === 0, `OBDex contains ${manufacturerSpecific.length} manufacturer-controlled DTCs in generic namespace`);

    const vagCounts = {
      sources: count(vagDb, "SELECT count(*) AS n FROM research_sources WHERE license='ODbL-1.0' AND market_scope='UNKNOWN'"),
      makes: count(vagDb, "SELECT count(*) AS n FROM make_candidates"),
      models: count(vagDb, "SELECT count(*) AS n FROM model_candidates WHERE market_scope='UNKNOWN' AND review_status='candidate'"),
      generations: count(vagDb, "SELECT count(*) AS n FROM generation_candidates WHERE market_scope='UNKNOWN' AND review_status='candidate'"),
      engineVariants: count(vagDb, "SELECT count(*) AS n FROM engine_variant_candidates WHERE market_scope='UNKNOWN' AND review_status='candidate' AND engine_code IS NULL AND gearbox_code IS NULL AND code_extraction_status='not_provided'"),
      codedCandidates: count(vagDb, "SELECT count(*) AS n FROM engine_variant_candidates WHERE engine_code IS NOT NULL OR gearbox_code IS NOT NULL OR code_extraction_status!='not_provided'"),
      nonCandidateRows: count(vagDb, "SELECT count(*) AS n FROM model_candidates WHERE review_status!='candidate' OR market_scope!='UNKNOWN'") + count(vagDb, "SELECT count(*) AS n FROM generation_candidates WHERE review_status!='candidate' OR market_scope!='UNKNOWN'"),
    };
    assert(vagCounts.sources === 5 && vagCounts.makes === 5 && vagCounts.models === 233 && vagCounts.generations === 823 && vagCounts.engineVariants === 5081 && !vagCounts.codedCandidates && !vagCounts.nonCandidateRows, `VAG identity candidate-only gate failed: ${JSON.stringify(vagCounts)}`);
    const vagSourceRows = vagDb.prepare("SELECT source_id, source_sha256 FROM research_sources ORDER BY source_id").all();
    assert(Object.keys(vag.source_file_sha256).length === 5 && Object.values(vag.source_file_sha256).every((hash) => /^[a-f0-9]{64}$/.test(hash)), "VAG source hashes are incomplete");
    for (const row of vagSourceRows) {
      const brand = row.source_id.split("-")[1];
      assert(vag.source_file_sha256[brand] === row.source_sha256, `VAG source hash mismatch for ${brand}`);
    }

    const obdbCounts = {
      sources: count(obdbDb, "SELECT count(*) AS n FROM source_registry WHERE license_id='CC-BY-SA-4.0' AND market_scope='UNKNOWN' AND verification_status='unverified_community_candidate' AND execution_allowed=0"),
      generations: count(obdbDb, "SELECT count(*) AS n FROM generation_candidates WHERE market_scope='UNKNOWN' AND verification_status='unverified_community_candidate'"),
      ecus: count(obdbDb, "SELECT count(*) AS n FROM ecu_candidates WHERE market_scope='UNKNOWN' AND verification_status='unverified_community_candidate'"),
      commands: count(obdbDb, "SELECT count(*) AS n FROM command_candidates WHERE service_id='22' AND execution_allowed=0 AND market_scope='UNKNOWN' AND verification_status='unverified_community_candidate'"),
      signals: count(obdbDb, "SELECT count(*) AS n FROM signal_candidates WHERE market_scope='UNKNOWN' AND applicability_precision='vehicle_model_candidate' AND verification_status='unverified_community_candidate'"),
      unsafeCommands: count(obdbDb, "SELECT count(*) AS n FROM command_candidates WHERE execution_allowed!=0 OR service_id!='22'"),
      invalidSignals: count(obdbDb, "SELECT count(*) AS n FROM signal_candidates WHERE market_scope!='UNKNOWN' OR applicability_precision!='vehicle_model_candidate' OR verification_status!='unverified_community_candidate'"),
    };
    assert(obdbCounts.sources === 6 && obdbCounts.generations === 32 && obdbCounts.ecus === 15 && obdbCounts.commands === 2315 && obdbCounts.signals === 2480 && !obdbCounts.unsafeCommands && !obdbCounts.invalidSignals, `OBDb candidate/non-execution gate failed: ${JSON.stringify(obdbCounts)}`);
    const obdbSourceRows = obdbDb.prepare("SELECT source_id, commit_sha, license_sha256, signalset_sha256, generations_sha256, readme_sha256 FROM source_registry ORDER BY source_id").all();
    for (const row of obdbSourceRows) {
      const source = obdbSnapshot.sources.find((item) => item.source_id === row.source_id);
      assert(source && source.commit_sha === row.commit_sha && source.license_sha256 === row.license_sha256 && source.files["signalsets/v3/default.json"].sha256 === row.signalset_sha256 && source.files["generations.yaml"].sha256 === row.generations_sha256 && source.files["README.md"].sha256 === row.readme_sha256, `OBDb row provenance mismatch for ${row.source_id}`);
    }

    const vehiclesDbProvenance = vehiclesDb.prepare("SELECT dataset_id, publisher, repository_url, upstream_tag, dataset_version, dataset_license, attribution_required, attribution_text, attribution_url, catalog_sqlite_sha256, upstream_manifest_sha256, license_sha256, attribution_sha256, ru_evidence_present, fitment_claim FROM dataset_provenance WHERE provenance_id=1").get();
    const vehiclesDbCounts = {
      sources: count(vehiclesDb, "SELECT count(*) AS n FROM source_registry WHERE rights_status='approved_by_published_license' AND country_code!='ru'"),
      models: count(vehiclesDb, "SELECT count(*) AS n FROM model_candidates WHERE applicability_precision='make_model_name_only' AND verification_status='identity_candidate' AND fitment_status='not_established' AND year_start IS NULL AND year_end IS NULL"),
      marketEvidence: count(vehiclesDb, "SELECT count(*) AS n FROM model_market_evidence WHERE country_code!='ru' AND applicability_precision='market_presence_only' AND verification_status='source_published_presence_evidence'"),
      russianEvidence: count(vehiclesDb, "SELECT count(*) AS n FROM model_market_evidence WHERE country_code='ru'"),
    };
    assert(vehiclesDbProvenance && vehiclesDbProvenance.dataset_license === "CC-BY-4.0" && vehiclesDbProvenance.attribution_required === 1 && vehiclesDbProvenance.ru_evidence_present === 0 && vehiclesDbProvenance.fitment_claim === 0, "VehiclesDB embedded provenance failed");
    assert(vehiclesDbProvenance.catalog_sqlite_sha256 === vehiclesDbSnapshot.source_snapshot_sha256["catalog.sqlite"] && vehiclesDbProvenance.upstream_manifest_sha256 === vehiclesdb.upstream_manifest_sha256 && vehiclesDbProvenance.license_sha256 === vehiclesdb.license_file_sha256 && vehiclesDbProvenance.attribution_sha256 === vehiclesdb.attribution_sha256, "VehiclesDB embedded source hashes mismatch");
    assert(vehiclesDbCounts.sources === 14 && vehiclesDbCounts.models === 260 && vehiclesDbCounts.marketEvidence === 1524 && vehiclesDbCounts.russianEvidence === 0, `VehiclesDB foreign-market-only count gate failed: ${JSON.stringify(vehiclesDbCounts)}`);
    const marketRows = vehiclesDb.prepare("SELECT DISTINCT country_code FROM model_market_evidence ORDER BY country_code").all().map((row) => row.country_code);
    assert(JSON.stringify(marketRows) === JSON.stringify(vehiclesdb.market_scope) && !marketRows.includes("ru"), "VehiclesDB market scope has changed or includes RU");
    const sourceArtifacts = vehiclesDb.prepare("SELECT relative_path, sha256 FROM source_file_artifacts ORDER BY relative_path").all();
    for (const artifact of sourceArtifacts) {
      const expected = vehiclesDbSnapshot.source_snapshot_sha256[artifact.relative_path === "catalog.sqlite" ? "catalog.sqlite" : artifact.relative_path === "manifest.json" ? "manifest.json" : artifact.relative_path === "LICENSE" ? "LICENSE" : "ATTRIBUTION.md"];
      assert(expected === artifact.sha256, `VehiclesDB source artifact hash mismatch for ${artifact.relative_path}`);
    }

    // MechanicDB: a separately licensed, make-labelled candidate sample; never a verified VAG DTC catalogue.
    const mechanicLicense = fs.readFileSync(path.join(RESEARCH, mechanicdb.license_file), "utf8");
    const mechanicUpstreamLicense = fs.readFileSync(path.join(RESEARCH, mechanicdb.upstream_license_file), "utf8");
    const mechanicAttribution = fs.readFileSync(path.join(RESEARCH, mechanicdb.attribution_file), "utf8");
    const mechanicSnapshot = readJson(path.join(RESEARCH, mechanicdb.source_manifest_file));
    assert(mechanicdb.license === "ODbL-1.0" && /Open Database License\s*\(ODbL\)\s*v1\.0/i.test(mechanicLicense) && /Share-Alike/i.test(mechanicLicense), "MechanicDB ODbL v1.0/share-alike license is missing");
    assert(mechanicdb.upstream_license === "MIT" && /MIT License/i.test(mechanicUpstreamLicense) && /Wal33D \(Waleed Judah\)/i.test(mechanicUpstreamLicense), "MechanicDB upstream MIT notice is missing");
    assert(/MechanicDB/i.test(mechanicAttribution) && /ODbL/i.test(mechanicAttribution) && /Wal33D/i.test(mechanicAttribution), "MechanicDB attribution is incomplete");
    assert(mechanicSnapshot.pack_id === mechanicdb.id && mechanicSnapshot.source_revision === mechanicdb.upstream_revision && mechanicSnapshot.data_license === "ODbL-1.0", "MechanicDB source manifest identity/revision/license mismatch");
    assert(mechanicSnapshot.rights_status === "approved_by_published_license" && mechanicSnapshot.commercial_use_allowed_under_odbl === true && mechanicSnapshot.display_allowed === true && mechanicSnapshot.offline_cache_allowed === true && mechanicSnapshot.redistribution_allowed_under_odbl === true && mechanicSnapshot.share_alike_required === true && mechanicSnapshot.attribution_required === true, "MechanicDB published license rights are incomplete");
    assert(mechanicSnapshot.database_sha256 === mechanicdb.database_sha256 && mechanicSnapshot.source_snapshot_sha256 === mechanicdb.source_snapshot_sha256 && mechanicSnapshot.display_status === "hidden_pending_technical_review", "MechanicDB pack hash or hidden review status mismatch");
    assert(mechanicSnapshot.market_scope === "UNKNOWN" && mechanicSnapshot.applicability_precision === "manufacturer_make_candidate" && mechanicSnapshot.verification_status === "community_reference_unverified" && mechanicSnapshot.exact_vehicle_fitment === false && mechanicSnapshot.ecu_fitment === false && mechanicSnapshot.pr_code_fitment === false && mechanicSnapshot.diagnostic_execution_allowed === false && mechanicSnapshot.repair_procedures_included === false && mechanicSnapshot.oem_part_numbers_included === false, "MechanicDB applicability/execution boundary changed");
    assert(JSON.stringify(mechanicSnapshot.counts) === JSON.stringify(mechanicdb.counts), "MechanicDB source manifest counts mismatch");
    for (const [relative, metadata] of Object.entries(mechanicSnapshot.pack_files || {})) safeFile(`${mechanicdb.id}/${relative}`, metadata.sha256);
    assert(mechanicdb.source_artifact_zip_sha256 === "f294bf4ebe6384b2ad6a586244ba0c49011fb441c691006c460d8a070744a5d6", "MechanicDB GitHub Actions artifact digest mismatch");
    assert(mechanicdb.source_workflow?.run_id === 41622526550 && mechanicdb.source_workflow?.artifact_id === 13223942420 && mechanicdb.source_workflow?.commit === "05a58d9e800dc9d725f3cc254857f68c32cf59c6", "MechanicDB acquisition workflow provenance mismatch");

    const mechanicSource = mechanicDb.prepare("SELECT * FROM source_registry WHERE source_id='mechanicdb-vag-dtc-sample-odbl'").get();
    assert(mechanicSource && mechanicSource.data_license === "ODbL-1.0" && mechanicSource.rights_status === "approved_by_published_license" && mechanicSource.commercial_use_allowed === 1 && mechanicSource.display_allowed === 1 && mechanicSource.offline_cache_allowed === 1 && mechanicSource.redistribution_allowed === 1 && mechanicSource.share_alike_required === 1 && mechanicSource.attribution_required === 1 && mechanicSource.market_scope === "UNKNOWN" && mechanicSource.applicability_precision === "manufacturer_make_candidate" && mechanicSource.technical_review_status === "community_reference_unverified" && mechanicSource.source_revision === mechanicdb.upstream_revision && mechanicSource.source_snapshot_sha256 === mechanicdb.source_snapshot_sha256, "MechanicDB SQLite source registry failed its rights/provenance gate");
    const mechanicCounts = {
      sources: count(mechanicDb, "SELECT count(*) AS n FROM source_registry"),
      manufacturerCandidates: count(mechanicDb, "SELECT count(*) AS n FROM dtc_candidates WHERE namespace='manufacturer_controlled_candidate' AND verification_status='community_reference_unverified' AND market_scope='UNKNOWN' AND applicability_precision='manufacturer_make_candidate'"),
      audiCandidates: count(mechanicDb, "SELECT count(*) AS n FROM dtc_candidates WHERE oem_make='Audi'"),
      volkswagenCandidates: count(mechanicDb, "SELECT count(*) AS n FROM dtc_candidates WHERE oem_make='Volkswagen'"),
      genericDtcRows: count(mechanicDb, "SELECT count(*) AS n FROM dtc_candidates WHERE namespace!='manufacturer_controlled_candidate'"),
      unsafeRows: count(mechanicDb, "SELECT count(*) AS n FROM dtc_candidates WHERE vehicle_fitment_claim!=0 OR ecu_fitment_claim!=0 OR pr_code_claim!=0 OR diagnostic_execution_allowed!=0 OR repair_procedure_included!=0 OR oem_part_number_included!=0"),
    };
    assert(mechanicCounts.sources === 1 && mechanicCounts.manufacturerCandidates === 2 && mechanicCounts.audiCandidates === 1 && mechanicCounts.volkswagenCandidates === 1 && !mechanicCounts.genericDtcRows && !mechanicCounts.unsafeRows, `MechanicDB candidate-only gate failed: ${JSON.stringify(mechanicCounts)}`);
    const mechanicRows = mechanicDb.prepare("SELECT oem_make, dtc_code, source_line_no, source_line_sha256, source_file_sha256, source_revision FROM dtc_candidates ORDER BY oem_make").all();
    const sourceBytes = fs.readFileSync(path.join(RESEARCH, mechanicdb.source_file));
    const sourceLines = physicalLines(sourceBytes);
    assert(sourceBytes.length === mechanicSnapshot.source_files["upstream/dtc_codes.csv"].byte_size && sha256(sourceBytes) === mechanicdb.source_file_sha256, "MechanicDB source CSV size/hash mismatch");
    for (const row of mechanicRows) {
      const evidence = mechanicSnapshot.source_line_evidence.find((item) => item.oem_make === row.oem_make && item.dtc_code === row.dtc_code);
      assert(evidence && evidence.source_line_no === row.source_line_no && evidence.source_line_sha256 === row.source_line_sha256 && row.source_file_sha256 === mechanicdb.source_file_sha256 && row.source_revision === mechanicdb.upstream_revision, `MechanicDB row provenance mismatch for ${row.oem_make} ${row.dtc_code}`);
      assert(sourceLines[row.source_line_no - 1] && sha256(sourceLines[row.source_line_no - 1]) === row.source_line_sha256, `MechanicDB source line hash mismatch for ${row.oem_make} ${row.dtc_code}`);
    }

    return {
      status: "verified",
      manifest_sha256: manifestHash,
      obdex: obCounts,
      vag_identity: vagCounts,
      obdb_vag_signals: obdbCounts,
      vehiclesdb_identity: vehiclesDbCounts,
      mechanicdb_vag_dtc_candidates: mechanicCounts,
      production_fitment_rows_added: 0,
      russian_eaeu_otts_rows_added: 0,
      sqlite_integrity: "ok",
      foreign_key_violations: 0,
    };
  } finally {
    obDb.close();
    vagDb.close();
    obdbDb.close();
    vehiclesDb.close();
    mechanicDb.close();
  }
}

if (require.main === module) {
  try { console.log(JSON.stringify(run(), null, 2)); }
  catch (error) { console.error(`Local research pack verification failed: ${error.message}`); process.exitCode = 1; }
}
module.exports = { run, verifyFile: safeFile, openReadOnly };
