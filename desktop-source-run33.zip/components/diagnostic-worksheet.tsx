"use client";

import { useMemo, useState } from "react";

type Measurement = {
  id: number;
  parameter: string;
  observed: string;
  unit: string;
  condition: string;
  reference: string;
  source: string;
};

const csvCell = (value: string) => `"${value.replaceAll('"', '""')}"`;

export default function DiagnosticWorksheet({ mode }: { mode: "DIAGNOSTIC" | "ELECTRICIAN" }) {
  const [dtc, setDtc] = useState("");
  const [ecu, setEcu] = useState("");
  const [freezeFrame, setFreezeFrame] = useState("");
  const [parameter, setParameter] = useState("");
  const [observed, setObserved] = useState("");
  const [unit, setUnit] = useState("");
  const [condition, setCondition] = useState("");
  const [reference, setReference] = useState("");
  const [source, setSource] = useState("");
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [notice, setNotice] = useState("");
  const nextId = useMemo(() => measurements.reduce((max, row) => Math.max(max, row.id), 0) + 1, [measurements]);

  function addMeasurement() {
    if (!parameter.trim() || !observed.trim()) {
      setNotice("Укажите параметр и фактически измеренное значение.");
      return;
    }
    setMeasurements((rows) => [...rows, { id: nextId, parameter: parameter.trim(), observed: observed.trim(), unit: unit.trim(), condition: condition.trim(), reference: reference.trim(), source: source.trim() }]);
    setParameter(""); setObserved(""); setUnit(""); setCondition(""); setReference(""); setSource("");
    setNotice("Измерение добавлено в текущий лист диагностики.");
  }

  function exportCsv() {
    const header = ["DTC", "ECU", "Freeze frame", "Параметр", "Измерено", "Единица", "Условия", "Справочное значение", "Источник нормы"];
    const rows = measurements.map((row) => [dtc, ecu, freezeFrame, row.parameter, row.observed, row.unit, row.condition, row.reference, row.source]);
    const csv = [header, ...rows].map((row) => row.map((cell) => csvCell(cell)).join(";")).join("\r\n");
    const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "vag-tech-pro-diagnostic-sheet.csv";
    anchor.click();
    URL.revokeObjectURL(url);
    setNotice("Лист измерений экспортирован в CSV.");
  }

  const title = mode === "ELECTRICIAN" ? "Лист измерений автоэлектрика" : "Рабочий лист диагностики";
  return <section className="diagnostic-sheet" aria-labelledby="diagnostic-sheet-title">
    <div className="diagnostic-sheet-head"><div><h2 id="diagnostic-sheet-title">{title}</h2><p>Фиксируйте фактические результаты и условия проверки. Нормы вводятся только из проверенного источника.</p></div><span className="diagnostic-count">{measurements.length} измер.</span></div>
    <div className="diagnostic-context">
      <label>Код неисправности / DTC<input value={dtc} onChange={(event) => setDtc(event.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 16))} placeholder="Например, Pxxxx" /></label>
      <label>Блок / ECU<input value={ecu} onChange={(event) => setEcu(event.target.value.slice(0, 100))} placeholder="Идентификатор блока" /></label>
      <label className="diagnostic-wide">Freeze frame / условия возникновения<textarea value={freezeFrame} onChange={(event) => setFreezeFrame(event.target.value.slice(0, 3000))} rows={2} placeholder="Обороты, температура, нагрузка, напряжение, статус ошибки…" /></label>
    </div>
    <div className="diagnostic-entry">
      <label>Параметр<input value={parameter} onChange={(event) => setParameter(event.target.value)} placeholder="Например, напряжение питания" /></label>
      <label>Фактическое значение<input value={observed} onChange={(event) => setObserved(event.target.value)} placeholder="Измерено" /></label>
      <label>Единица<input value={unit} onChange={(event) => setUnit(event.target.value)} placeholder="В, Ом, кПа…" /></label>
      <label>Условия измерения<input value={condition} onChange={(event) => setCondition(event.target.value)} placeholder="Зажигание, нагрузка, температура" /></label>
      <label>Справочное значение<input value={reference} onChange={(event) => setReference(event.target.value)} placeholder="Только из документа" /></label>
      <label>Источник нормы<input value={source} onChange={(event) => setSource(event.target.value)} placeholder="Документ, ревизия, страница" /></label>
      <button type="button" onClick={addMeasurement}>＋ Добавить измерение</button>
    </div>
    {measurements.length > 0 ? <div className="diagnostic-table-wrap"><table className="diagnostic-table"><thead><tr><th>Параметр</th><th>Факт</th><th>Условия</th><th>Справка / источник</th><th></th></tr></thead><tbody>{measurements.map((row) => <tr key={row.id}><td>{row.parameter}</td><td>{row.observed} {row.unit}</td><td>{row.condition || "—"}</td><td>{row.reference || "Не указано"}<small>{row.source || "Источник не указан"}</small></td><td><button type="button" aria-label={`Удалить измерение ${row.parameter}`} onClick={() => setMeasurements((items) => items.filter((item) => item.id !== row.id))}>×</button></td></tr>)}</tbody></table></div> : <div className="diagnostic-empty">Пока нет измерений. Добавьте первое после проверки автомобиля.</div>}
    <div className="diagnostic-sheet-footer"><span>Черновик хранится только в этой вкладке. Экспорт не отправляет данные на сервер.</span><button type="button" className="diagnostic-export" disabled={!measurements.length} onClick={exportCsv}>Экспорт измерений CSV</button></div>
    {notice && <p className="diagnostic-notice" role="status">{notice}</p>}
    <details className="diagnostic-freeze"><summary>Показать контекст текущей проверки для записи в заказ-наряд</summary><dl><dt>DTC</dt><dd>{dtc || "Не указан"}</dd><dt>ECU</dt><dd>{ecu || "Не указан"}</dd><dt>Freeze frame</dt><dd>{freezeFrame || "Не заполнен"}</dd></dl></details>
  </section>;
}
