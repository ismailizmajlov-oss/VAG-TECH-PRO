"use client";

import { useEffect, useRef, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";

type Dataset = "vehicles" | "vehiclesdb" | "dtc" | "pids" | "uds";
type SummaryPack = { id: string; license: string; counts: Record<string, number>; source: string; sourceUrl: string; note: string; marketScope?: string | string[]; upstreamRevision?: string; snapshotGeneratedAt?: string; sourceManifestSha256?: string; sourceSnapshotSha256?: string; upstreamManifestSha256?: string; attributionSha256?: string; attributionText?: string; attributionUrl?: string | null; databaseSha256?: string; ruEvidencePresent?: false; displayStatus?: string; reviewStatus?: string; applicabilityPrecision?: string; shareAlikeRequired?: boolean; attributionRequired?: boolean };
type ResearchRow = Record<string, any>;

const tabs: Array<{ id: Dataset; label: string; hint: string }> = [
  { id: "vehicles", label: "VAG · поколения и варианты", hint: "ODbL · рынок UNKNOWN · кандидаты" },
  { id: "vehiclesdb", label: "Модели · рыночные данные", hint: "VehiclesDB · зарубежные рынки only" },
  { id: "dtc", label: "Общие DTC", hint: "CC0 · SAE/ISO, не VAG-specific" },
  { id: "pids", label: "OBD-II PID", hint: "CC0 · стандартные параметры" },
  { id: "uds", label: "UDS · сигналы сообщества", hint: "CC BY-SA · кандидаты, без выполнения" },
];

const countryLabels: Record<string, string> = {
  ar: "Аргентина", au: "Австралия", ca: "Канада", de: "Германия", es: "Испания",
  fi: "Финляндия", gb: "Великобритания", ie: "Ирландия", lu: "Люксембург",
  my: "Малайзия", nl: "Нидерланды", nz: "Новая Зеландия", ua: "Украина", us: "США",
};

function formatNumber(value: number | undefined) {
  return typeof value === "number" ? new Intl.NumberFormat("ru-RU").format(value) : "—";
}

export default function LocalResearchCatalog() {
  const [dataset, setDataset] = useState<Dataset>("vehicles");
  const [query, setQuery] = useState("");
  const [summary, setSummary] = useState<SummaryPack[]>([]);
  const [rows, setRows] = useState<ResearchRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("Введите не менее двух символов для поиска в локальном SQLite.");
  const controller = useRef<AbortController | null>(null);

  useEffect(() => {
    const current = new AbortController();
    fetch("/api/local-research?dataset=summary", { signal: current.signal, cache: "no-store" })
      .then(async (response) => {
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || "Локальные справочники недоступны.");
        setSummary(payload.packs || []);
      })
      .catch((reason) => {
        if (reason?.name !== "AbortError") setError(reason?.message || "Не удалось открыть локальные справочники.");
      });
    return () => {
      current.abort();
      controller.current?.abort();
    };
  }, []);

  function changeDataset(next: Dataset) {
    controller.current?.abort();
    setDataset(next);
    setRows([]);
    setError("");
    setNotice("Введите не менее двух символов для поиска в локальном SQLite.");
  }

  async function search(event: FormEvent) {
    event.preventDefault();
    const value = query.trim();
    if (value.length < 2) {
      setError("Для поиска нужно минимум два символа.");
      setRows([]);
      return;
    }
    controller.current?.abort();
    const nextController = new AbortController();
    controller.current = nextController;
    setLoading(true);
    setError("");
    setNotice("Поиск выполняется локально, без обращения к внешнему API.");
    try {
      const response = await fetch(`/api/local-research?dataset=${dataset}&q=${encodeURIComponent(value)}&limit=30`, {
        signal: nextController.signal,
        cache: "no-store",
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Поиск не выполнен.");
      setRows(payload.rows || []);
      setNotice(`Найдено записей: ${payload.count || 0}. Источник и ограничения показаны в каждой карточке.`);
    } catch (reason: any) {
      if (reason?.name !== "AbortError") {
        setRows([]);
        setError(reason?.message || "Локальный поиск недоступен.");
      }
    } finally {
      if (controller.current === nextController) setLoading(false);
    }
  }

  const obdex = summary.find((pack) => pack.id === "obdex-generic-cc0");
  const vag = summary.find((pack) => pack.id === "vag-identity-odbl");
  const obdb = summary.find((pack) => pack.id === "obdb-vag-signals-cc-by-sa");
  const vehiclesDb = summary.find((pack) => pack.id === "vehiclesdb-vag-identity");
  const mechanicDb = summary.find((pack) => pack.id === "mechanicdb-vag-dtc-candidates-odbl");

  return <section className="content list-view local-research-view">
    <div className="head">
      <div><h1>Локальные справочники</h1><div className="research-subtitle">SQLite · автономное чтение · источники с сохранённой лицензией</div></div>
      <span className="research-mode">OFFLINE DATA</span>
    </div>

    <div className="research-stats">
      <article className="research-stat"><small>Общие DTC</small><strong>{formatNumber(obdex?.counts?.dtcs)}</strong><span>CC0 · SAE/ISO</span></article>
      <article className="research-stat"><small>Стандартные PID</small><strong>{formatNumber(obdex?.counts?.pids)}</strong><span>CC0 · OBD-II</span></article>
      <article className="research-stat"><small>Модели VAG-группы</small><strong>{formatNumber(vag?.counts?.models)}</strong><span>ODbL · research-only</span></article>
      <article className="research-stat"><small>Поколения-кандидаты</small><strong>{formatNumber(vag?.counts?.generations)}</strong><span>{formatNumber(vag?.counts?.engineVariants)} описаний двигателей · коды не предоставлены</span></article>
      <article className="research-stat"><small>UDS сигналы-кандидаты</small><strong>{formatNumber(obdb?.counts?.signals)}</strong><span>CC BY-SA · без выполнения</span></article>
      <article className="research-stat"><small>Модели VehiclesDB</small><strong>{formatNumber(vehiclesDb?.counts?.models)}</strong><span>{formatNumber(vehiclesDb?.counts?.marketEvidence)} зарубежных свидетельств · RU отсутствует</span></article>
    </div>

    <div className="research-boundary">
      <b>Важно: справочные кандидаты не являются подтверждённой применимостью.</b>
      <p>Эта локальная библиотека не подтверждает комплектацию конкретного автомобиля, код двигателя или КПП, ЭБУ, PR-коды, OEM-детали и ремонтную процедуру. ODbL-таксономия и VehiclesDB — кандидаты, а рыночные свидетельства VehiclesDB не относятся к России/ЕАЭС. UDS-сигналы — непроверенные community-кандидаты; команды не отправляются автомобилю. Для технических рекомендаций нужны отдельные первичные документы с точной применимостью.</p>
      {mechanicDb && <p>Отдельно хранится {formatNumber(mechanicDb.counts.manufacturerCandidates)} make-labelled DTC-кандидата MechanicDB в самостоятельной базе ODbL-1.0. Записи скрыты до независимой технической проверки; рынок UNKNOWN, точная применимость к модели, поколению, двигателю, КПП и ECU отсутствует. Эти записи не входят в поиск общих DTC и не являются подтверждёнными VAG-specific кодами.</p>}
    </div>

    <div className="research-tabs" role="tablist" aria-label="Локальные наборы данных">
      {tabs.map((tab) => <button key={tab.id} type="button" role="tab" aria-selected={dataset === tab.id} className={dataset === tab.id ? "research-tab active" : "research-tab"} onClick={() => changeDataset(tab.id)}>
        <b>{tab.label}</b><small>{tab.hint}</small>
      </button>)}
    </div>

    <form className="research-search" onSubmit={search}>
      <input aria-label="Поиск по локальному справочнику" value={query} onChange={(event: ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)} placeholder={dataset === "vehicles" ? "Модель, поколение или описание двигателя…" : dataset === "vehiclesdb" ? "Марка или модель… например Golf" : dataset === "dtc" ? "Код DTC или описание… например P0300" : dataset === "pids" ? "PID, режим или название параметра…" : "Марка, модель, ECU header, DID или сигнал…"} />
      <button type="submit" disabled={loading}>{loading ? "Поиск…" : "Найти"}</button>
    </form>
    <div className="research-status" role="status" aria-live="polite">{error || notice}</div>

    {rows.length > 0 && <div className="research-results">
      {dataset === "vehicles" && rows.map((row, index) => <article className="research-result" key={`${row.brandKey}-${row.model}-${row.generation}-${row.engineLabel}-${index}`}>
        <div className="research-result-top"><div><small>{row.brand}</small><h3>{row.model} · {row.generation}</h3></div><span className="research-candidate">КАНДИДАТ</span></div>
        <div className="research-data-grid">
          <div><small>Годы в источнике</small><b>{row.yearStart || "—"}–{row.yearEnd || "—"}</b></div>
          <div><small>Описание двигателя</small><b>{row.engineLabel || "Не указано"}</b></div>
          <div><small>Объём / мощность</small><b>{row.displacementCc ? `${row.displacementCc} см³` : "—"} · {row.powerHp ? `${row.powerHp} hp` : "—"}</b></div>
          <div><small>Крутящий момент</small><b>{row.torqueNm ? `${row.torqueNm} Н·м` : "—"}</b></div>
          <div><small>Описание трансмиссии</small><b>{row.transmissionDescription || "—"}</b></div>
          <div><small>Привод / топливо</small><b>{[row.drivetrain, row.fuelType].filter(Boolean).join(" · ") || "—"}</b></div>
        </div>
        <div className="research-warning-line">Заводской код двигателя: отсутствует · код КПП: отсутствует · точная применимость: не подтверждена · рынок: UNKNOWN</div>
        <div className="research-source"><span>Источник: {row.sourceLicense} · ревизия {row.sourceRevision} · SHA источника {String(row.sourceSha256).slice(0, 12)}… · SHA манифеста {String(row.sourceManifestSha256).slice(0, 12)}…</span>{row.sourceUrl && <a href={row.sourceUrl} target="_blank" rel="noopener noreferrer">Открыть источник</a>}</div>
      </article>)}

      {dataset === "vehiclesdb" && rows.map((row) => <article className="research-result" key={row.sourceModelId}>
        <div className="research-result-top"><div><small>{row.brand} · VehiclesDB · {row.vehicleKind === "van" ? "коммерческий автомобиль" : "легковой автомобиль"}</small><h3>{row.model}</h3></div><span className="research-candidate">IDENTITY CANDIDATE</span></div>
        <div className="research-data-grid">
          <div><small>Тип кузова из источника</small><b>{row.bodyTypes?.join(" · ") || "Не указан"}</b></div>
          <div><small>Регионы из источника</small><b>{row.regions?.join(" · ") || "Не указаны"}</b></div>
          <div><small>Рынки с опубликованным свидетельством</small><b>{row.marketScope?.map((code: string) => countryLabels[code] || code.toUpperCase()).join(", ") || "Нет свидетельств"}</b></div>
          <div><small>Поколение / годы</small><b>Не предоставлены</b></div>
          <div><small>Код двигателя / КПП</small><b>Не предоставлены</b></div>
          <div><small>ECU / PR-коды / VIN</small><b>Применимость не установлена</b></div>
          <div><small>РФ / ЕАЭС</small><b>{row.ruEvidencePresent ? "Есть свидетельства" : "Данных нет"}</b></div>
          <div><small>Точная применимость</small><b>{row.exactFitment ? "Подтверждена" : "Не подтверждена"}</b></div>
        </div>
        <div className="research-warning-line">{row.warning} Точность: {row.applicabilityPrecision}; статус: {row.reviewStatus}; точная применимость: не подтверждена.</div>
        <details className="research-details"><summary>Первичные рыночные свидетельства ({formatNumber(row.marketEvidenceCount)})</summary><ul>{row.marketEvidence?.map((item: any, index: number) => <li key={`${item.sourceId}-${item.countryCode}-${index}`}>{countryLabels[item.countryCode] || item.countryCode.toUpperCase()} · {item.evidenceType} · {item.sourceName} · {item.sourceLicense}{item.sourceUrl ? <> · <a href={item.sourceUrl} target="_blank" rel="noopener noreferrer">источник</a></> : null}{item.sourceLicenseUrl ? <> · <a href={item.sourceLicenseUrl} target="_blank" rel="noopener noreferrer">лицензия</a></> : null}</li>)}</ul></details>
        <div className="research-source"><span>{row.attribution} · CC BY 4.0 · ревизия {row.sourceRevision} · SHA записи {String(row.sourceSha256).slice(0, 12)}… · SHA БД {String(row.databaseSha256).slice(0, 12)}… · SHA манифеста {String(row.sourceManifestSha256).slice(0, 12)}…</span><a href={row.attributionUrl || row.sourceUrl} target="_blank" rel="noopener noreferrer">Открыть VehiclesDB</a></div>
      </article>)}

      {dataset === "dtc" && rows.map((row) => <article className="research-result" key={row.code}>
        <div className="research-result-top"><div><small>GENERIC SAE/ISO OBD-II · {row.category || "без категории"}</small><h3 className="research-code">{row.code} · {row.title}</h3></div><span className="research-candidate">RESEARCH ONLY</span></div>
        <p className="research-description">{row.description}</p>
        {row.affectedComponents?.length > 0 && <div className="research-tags">{row.affectedComponents.map((item: string) => <span key={item}>{item.replaceAll("_", " ")}</span>)}</div>}
        {row.commonCauses?.length > 0 && <details className="research-details"><summary>Общие возможные причины из набора</summary><ul>{row.commonCauses.map((cause: any, index: number) => <li key={`${cause.component}-${index}`}>{cause.label}{cause.likelihood ? ` · ${cause.likelihood}` : ""}</li>)}</ul></details>}
        <div className="research-warning-line">Не VAG-specific · не привязан к модели, двигателю, КПП или ECU · не является тест-планом или указанием на замену детали</div>
        <div className="research-source"><span>Источник: OBDex · CC0-1.0 · snapshot {row.snapshotGeneratedAt} · SHA источника {String(row.sourceSha256).slice(0, 12)}… · SHA манифеста {String(row.sourceManifestSha256).slice(0, 12)}…</span><a href="https://github.com/foerbsnavi/OBDex" target="_blank" rel="noopener noreferrer">Открыть источник</a></div>
      </article>)}

      {dataset === "pids" && rows.map((row) => <article className="research-result" key={`${row.mode}-${row.pid}`}>
        <div className="research-result-top"><div><small>GENERIC OBD-II · MODE {row.mode}</small><h3 className="research-code">PID {row.pid} · {row.name}</h3></div><span className="research-candidate">RESEARCH ONLY</span></div>
        <div className="research-data-grid"><div><small>Единица</small><b>{row.unit || "—"}</b></div><div><small>Размер</small><b>{row.bytes ?? "—"} байт</b></div></div>
        {row.description && <p className="research-description">{row.description}</p>}
        <div className="research-warning-line">Стандартный OBD-II PID; доступность и поддержка конкретным ECU не подтверждены</div>
        <div className="research-source"><span>Источник: OBDex · CC0-1.0 · snapshot {row.snapshotGeneratedAt} · SHA источника {String(row.sourceSha256).slice(0, 12)}… · SHA манифеста {String(row.sourceManifestSha256).slice(0, 12)}…</span><a href="https://github.com/foerbsnavi/OBDex" target="_blank" rel="noopener noreferrer">Открыть источник</a></div>
      </article>)}

      {dataset === "uds" && rows.map((row) => <article className="research-result" key={`${row.sourceId}-${row.ecuHeader}-${row.did}-${row.signalKey}`}>
        <div className="research-result-top"><div><small>{row.make} · {row.model} · COMMUNITY UDS 0x22</small><h3>{row.name} <span className="research-code">({row.signalKey})</span></h3></div><span className="research-candidate">НЕ ПРОВЕРЕНО</span></div>
        {row.description && <p className="research-description">{row.description}</p>}
        <div className="research-data-grid">
          <div><small>ECU header-кандидат</small><b>{row.ecuHeader}</b></div>
          <div><small>Сервис / DID</small><b>0x{row.serviceId} / 0x{row.did}</b></div>
          <div><small>Путь сигнала</small><b>{row.path || "—"}</b></div>
          <div><small>Единица из источника</small><b>{row.unit || "—"}</b></div>
          <div className="research-format"><small>Формат декодирования из источника</small><code>{JSON.stringify(row.format) || "—"}</code></div>
        </div>
        <div className="research-warning-line">Непроверенный community-кандидат · рынок UNKNOWN · точная генерация, двигатель, КПП, аппаратная/программная версия ECU и VIN не подтверждены. Команда UDS не выполняется и не должна использоваться как тест-план.</div>
        <div className="research-source"><span>Источник: {row.sourceRepository} · CC BY-SA 4.0 · commit {String(row.sourceRevision).slice(0, 12)}… · SHA записи {String(row.sourceSha256).slice(0, 12)}… · SHA манифеста {String(row.sourceManifestSha256).slice(0, 12)}…</span>{row.sourceUrl && <a href={row.sourceUrl} target="_blank" rel="noopener noreferrer">Открыть источник</a>}</div>
      </article>)}
    </div>}

    {!rows.length && !loading && !error && <div className="research-empty">Результаты появятся здесь. Поиск выполняется по локальным SQLite-файлам; интернет для чтения этих наборов не требуется.</div>}

    <div className="research-credits">
      <b>Лицензии и атрибуция</b>
      <p>OBDex — CC0-1.0: <a href="https://github.com/foerbsnavi/OBDex" target="_blank" rel="noopener noreferrer">foerbsnavi/OBDex</a>. Данные общие SAE/ISO OBD-II.</p>
      <p>VAG identity — ODbL-1.0: <a href="https://github.com/gor3a/vehicle-makes-models" target="_blank" rel="noopener noreferrer">gor3a/vehicle-makes-models</a>; upstream source, как заявлено издателем, — autoevolution.com. При публичном распространении адаптированной базы действует share-alike по ODbL-1.0.</p>
      <p>OBDb community signalsets — CC BY-SA 4.0: <a href="https://github.com/OBDb" target="_blank" rel="noopener noreferrer">OBDb</a>. Адаптированная SQLite-база распространяется под CC BY-SA 4.0 с атрибуцией; команды UDS 0x22 остаются только справочными кандидатами и не выполняются.</p>
      <p><a href="https://vehiclesdb.com" target="_blank" rel="noopener noreferrer">Vehicle data by VehiclesDB (vehiclesdb.com)</a> — обязательная атрибуция CC BY 4.0. Сведения о лицензиях и обязательных уведомлениях всех исходных реестров сохранены в наборе.</p>
      {mechanicDb && <><p><a href="https://github.com/MechanicDB/MechanicDB-public" target="_blank" rel="noopener noreferrer">MechanicDB / MechanicDB-public</a> — бесплатный sample под ODbL-1.0: коммерческое использование, показ и офлайн-кэширование разрешены по опубликованным условиям с обязательной атрибуцией и share-alike. В отдельной базе сохранён MIT notice для upstream DTC code spine Wal33D / Waleed Judah. Два make-labelled кандидата остаются скрыты до технической проверки; нет точной применимости, test-plan, ремонта или OEM-деталей.</p><details className="research-details"><summary>Атрибуция и provenance MechanicDB</summary><pre className="research-attribution">{mechanicDb.attributionText}</pre><p>Ревизия {mechanicDb.upstreamRevision} · SHA-256 БД {mechanicDb.databaseSha256} · SHA-256 манифеста {mechanicDb.sourceManifestSha256} · SHA-256 исходного снимка {mechanicDb.sourceSnapshotSha256} · статус {mechanicDb.displayStatus}</p></details></>}
      {vehiclesDb?.attributionText && <details className="research-details"><summary>Полные уведомления VehiclesDB и исходных реестров</summary><pre className="research-attribution">{vehiclesDb.attributionText}</pre></details>}
      <p>SQLite SHA-256 · OBDex: {obdex?.databaseSha256 || "недоступен"}</p>
      <p>SQLite SHA-256 · VAG identity: {vag?.databaseSha256 || "недоступен"}</p>
      <p>SQLite SHA-256 · OBDb signals: {obdb?.databaseSha256 || "недоступен"}</p>
      <p>SQLite SHA-256 · VehiclesDB identity: {vehiclesDb?.databaseSha256 || "недоступен"} · upstream manifest SHA-256: {vehiclesDb?.upstreamManifestSha256 || "недоступен"} · attribution SHA-256: {vehiclesDb?.attributionSha256 || "недоступен"}</p>
    </div>
  </section>;
}
