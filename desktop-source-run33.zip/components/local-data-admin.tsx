"use client";

import { ChangeEvent, FormEvent, useCallback, useEffect, useState } from "react";

type SourceRow = {
  source_id: string; publisher: string; title: string; source_type: string; source_url: string | null; revision: string;
  license_id: string | null; license_url: string | null; rights_status: string; commercial_use_allowed: number;
  display_allowed: number; offline_cache_allowed: number; bulk_reuse_allowed: number; redistribution_allowed: number;
  share_alike_required: number; attribution_required: number; attribution_text: string | null; market_scope: string;
  status: string; snapshot_count: number; record_count: number; verified_record_count: number; updated_at: string;
};
type ImportBatch = {
  id: number; package_id: string; source_id: string; publisher: string; source_title: string; source_revision: string;
  market_scope: string; package_sha256: string; status: string; records_seen: number; records_inserted: number;
  records_unchanged: number; rejected_items: number; created_at: string; completed_at: string | null;
};

type Props = { onMessage: (message: string) => void };

async function readJson(response: Response) {
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof body.error === "string" ? body.error : `HTTP ${response.status}`);
  return body;
}
function dateLabel(value: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString("ru-RU");
}
function rightsLabel(value: number) { return value === 1 ? "Да" : "Нет"; }
function safeHttpsUrl(value: string | null) {
  if (!value) return null;
  try { const url = new URL(value); return url.protocol === "https:" ? url.toString() : null; }
  catch { return null; }
}
function statusLabel(value: string) {
  const labels: Record<string, string> = {
    approved: "Права подтверждены",
    candidate: "Кандидат · требуется проверка",
    blocked: "Заблокирован",
    superseded: "Заменён",
    applied: "Импорт выполнен",
    validated: "Проверен · ожидает применения",
    rejected: "Отклонён",
  };
  return labels[value] || value;
}

export default function LocalDataAdmin({ onMessage }: Props) {
  const [sources, setSources] = useState<SourceRow[]>([]);
  const [batches, setBatches] = useState<ImportBatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<"import" | "backup" | "restore" | "source" | null>(null);
  const [candidateSource, setCandidateSource] = useState({ source_id: "", publisher: "", title: "", source_type: "public_registry", source_url: "", revision: "", market_scope: "RU/EAEU", license_id: "", license_url: "", attribution_text: "" });
  const [packageFile, setPackageFile] = useState<File | null>(null);
  const [backupFile, setBackupFile] = useState<File | null>(null);
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/local-core?action=admin-summary", { cache: "no-store" });
      const body = await readJson(response);
      setSources(Array.isArray(body.sources) ? body.sources : []);
      setBatches(Array.isArray(body.importBatches) ? body.importBatches : []);
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Не удалось прочитать локальный реестр";
      setError(message);
      onMessage(`Локальное администрирование недоступно: ${message}`);
    } finally { setLoading(false); }
  }, [onMessage]);

  useEffect(() => { void refresh(); }, [refresh]);

  function onPackageChange(event: ChangeEvent<HTMLInputElement>) {
    setPackageFile(event.target.files?.[0] || null);
  }
  function onBackupChange(event: ChangeEvent<HTMLInputElement>) {
    setBackupFile(event.target.files?.[0] || null);
  }

  function updateCandidate<K extends keyof typeof candidateSource>(key: K, value: string) {
    setCandidateSource((current) => ({ ...current, [key]: value }));
  }

  async function registerCandidate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy("source");
    try {
      const response = await fetch("/api/local-core", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "source.register-candidate", source: candidateSource }), cache: "no-store",
      });
      const body = await readJson(response);
      setCandidateSource({ source_id: "", publisher: "", title: "", source_type: "public_registry", source_url: "", revision: "", market_scope: "RU/EAEU", license_id: "", license_url: "", attribution_text: "" });
      await refresh();
      onMessage(`Источник ${body.source?.source_id || ""} добавлен как кандидат. Все права остаются неподтверждёнными.`);
    } catch (cause) {
      onMessage(cause instanceof Error ? cause.message : "Не удалось добавить источник-кандидат.");
    } finally { setBusy(null); }
  }

  async function importPackage() {
    if (!packageFile) { onMessage("Выберите JSON-пакет импорта."); return; }
    if (packageFile.size > 32 * 1024 * 1024) { onMessage("JSON-пакет превышает 32 MiB."); return; }
    setBusy("import");
    try {
      const form = new FormData();
      form.append("action", "package.import");
      form.append("file", packageFile, packageFile.name);
      const response = await fetch("/api/local-core", { method: "POST", body: form, cache: "no-store" });
      const body = await readJson(response);
      setPackageFile(null);
      const input = document.getElementById("local-package-file") as HTMLInputElement | null;
      if (input) input.value = "";
      await refresh();
      onMessage(`Пакет ${body.import?.status || "обработан"}: добавлено ${body.import?.inserted ?? 0}, без изменений ${body.import?.unchanged ?? 0}.`);
    } catch (cause) {
      onMessage(cause instanceof Error ? cause.message : "Импорт пакета не выполнен.");
    } finally { setBusy(null); }
  }

  async function createBackup() {
    setBusy("backup");
    try {
      const response = await fetch("/api/local-core", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "backup.create" }), cache: "no-store",
      });
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(typeof body.error === "string" ? body.error : `HTTP ${response.status}`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      const disposition = response.headers.get("content-disposition") || "";
      const filename = disposition.match(/filename="([^"]+)"/i)?.[1] || "vag-tech-pro-backup.sqlite";
      anchor.href = url;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      onMessage(`Резервная копия создана. SHA-256: ${response.headers.get("x-backup-sha256") || "не получен"}.`);
    } catch (cause) {
      onMessage(cause instanceof Error ? cause.message : "Не удалось создать резервную копию.");
    } finally { setBusy(null); }
  }

  async function restoreBackup() {
    if (!backupFile) { onMessage("Выберите SQLite-файл резервной копии."); return; }
    if (backupFile.size > 256 * 1024 * 1024) { onMessage("Файл резервной копии превышает 256 MiB."); return; }
    if (!window.confirm("Восстановить выбранную резервную копию? Текущая база будет заменена только после проверки целостности; перед заменой приложение создаст страховочную копию текущей базы.")) return;
    setBusy("restore");
    try {
      const form = new FormData();
      form.append("action", "backup.restore");
      form.append("file", backupFile, backupFile.name);
      const response = await fetch("/api/local-core", { method: "POST", body: form, cache: "no-store" });
      const body = await readJson(response);
      setBackupFile(null);
      const input = document.getElementById("local-backup-file") as HTMLInputElement | null;
      if (input) input.value = "";
      await refresh();
      onMessage(`База восстановлена. Страховочная копия текущих данных: ${body.restore?.safetyBackup || "создана"}.`);
    } catch (cause) {
      onMessage(cause instanceof Error ? cause.message : "Восстановление не выполнено; текущая база сохранена.");
    } finally { setBusy(null); }
  }

  return <section className="content list-view local-offline-view local-data-admin">
    <div className="crumb">Офлайн-режим　›　Локальная база　›　Источники и резервные копии</div>
    <div className="head"><h1>Локальная база и источники</h1><span>SQLite · офлайн · Windows</span></div>
    <div className="admin-notice">
      <b>Защита технических данных</b>
      <p>Пакет импортируется только при совпадении SHA-256, ревизии, прав источника и применимости. Импортированные технические записи остаются кандидатами до отдельной модерации. Этот экран не позволяет самостоятельно объявить источник лицензированным или запись проверенной.</p>
    </div>

    <div className="admin-section-head"><h2>Резервное копирование</h2><span>Пользовательская SQLite не хранится внутри каталога установки</span></div>
    <div className="admin-tools-grid">
      <article className="admin-tool-card">
        <h3>Создать резервную копию</h3>
        <p>Создаёт согласованный SQLite-снимок после проверки целостности. Файл можно сохранить отдельно от приложения.</p>
        <button type="button" onClick={() => void createBackup()} disabled={busy !== null || loading}>{busy === "backup" ? "Создание…" : "Скачать резервную копию"}</button>
      </article>
      <article className="admin-tool-card">
        <h3>Восстановить из копии</h3>
        <p>Перед заменой текущей базы проверяется целостность файла и создаётся страховочная копия действующей базы.</p>
        <label className="admin-file-label" htmlFor="local-backup-file">SQLite-файл резервной копии</label>
        <input id="local-backup-file" type="file" accept=".sqlite,.db,application/vnd.sqlite3,application/octet-stream" onChange={onBackupChange} disabled={busy !== null} />
        <button type="button" className="secondary" onClick={() => void restoreBackup()} disabled={busy !== null || !backupFile}>{busy === "restore" ? "Проверка и восстановление…" : "Проверить и восстановить"}</button>
      </article>
    </div>

    <div className="admin-section-head"><h2>Импорт технических пакетов</h2><span>Только пакет с проверяемым манифестом</span></div>
    <article className="admin-tool-card admin-import-card">
      <p>Выберите JSON-пакет. Перед записью проверяются канонический хэш пакета, хэши снимка и лицензии, зарегистрированные права источника, ревизия, market scope и тип каждой записи. Пакет не может самостоятельно перевести данные в статус «проверено».</p>
      <label className="admin-file-label" htmlFor="local-package-file">JSON-пакет импорта</label>
      <input id="local-package-file" type="file" accept=".json,application/json" onChange={onPackageChange} disabled={busy !== null} />
      <div className="admin-import-actions"><span>{packageFile ? `${packageFile.name} · ${(packageFile.size / 1024 / 1024).toFixed(2)} MiB` : "Файл не выбран"}</span><button type="button" onClick={() => void importPackage()} disabled={busy !== null || !packageFile}>{busy === "import" ? "Проверка и импорт…" : "Проверить и импортировать"}</button></div>
    </article>

    <div className="admin-section-head"><h2>Реестр источников</h2><span>{sources.length} источников</span></div>
    <form className="admin-tool-card admin-source-form" onSubmit={registerCandidate}>
      <div><h3>Добавить источник-кандидат</h3><p>Новая запись всегда получает статус permission_required и нулевые права на коммерческое использование, показ, офлайн-кэш, массовое использование и распространение. Утвердить права из этого экрана нельзя.</p></div>
      <div className="admin-source-form-grid">
        <label>ID источника<input required maxLength={64} pattern="[a-z0-9][a-z0-9._-]{1,63}" value={candidateSource.source_id} onChange={(event: ChangeEvent<HTMLInputElement>) => updateCandidate("source_id", event.target.value.toLowerCase().replace(/[^a-z0-9._-]/g, "").slice(0,64))} placeholder="fgis-otts" /></label>
        <label>Издатель<input required maxLength={180} value={candidateSource.publisher} onChange={(event: ChangeEvent<HTMLInputElement>) => updateCandidate("publisher", event.target.value)} placeholder="Росстандарт" /></label>
        <label>Название набора<input required maxLength={180} value={candidateSource.title} onChange={(event: ChangeEvent<HTMLInputElement>) => updateCandidate("title", event.target.value)} placeholder="Реестр ОТТС" /></label>
        <label>Тип источника<input required maxLength={180} value={candidateSource.source_type} onChange={(event: ChangeEvent<HTMLInputElement>) => updateCandidate("source_type", event.target.value)} placeholder="public_registry" /></label>
        <label>Ревизия / дата снимка<input required maxLength={180} value={candidateSource.revision} onChange={(event: ChangeEvent<HTMLInputElement>) => updateCandidate("revision", event.target.value)} placeholder="2026-11-03" /></label>
        <label>Рынок<input required maxLength={180} value={candidateSource.market_scope} onChange={(event: ChangeEvent<HTMLInputElement>) => updateCandidate("market_scope", event.target.value)} placeholder="RU/EAEU" /></label>
        <label>URL источника<input type="url" value={candidateSource.source_url} onChange={(event: ChangeEvent<HTMLInputElement>) => updateCandidate("source_url", event.target.value)} placeholder="https://…" /></label>
        <label>Лицензия (заявленная)<input maxLength={100} value={candidateSource.license_id} onChange={(event: ChangeEvent<HTMLInputElement>) => updateCandidate("license_id", event.target.value)} placeholder="Пока не подтверждена" /></label>
        <label>URL лицензии<input type="url" value={candidateSource.license_url} onChange={(event: ChangeEvent<HTMLInputElement>) => updateCandidate("license_url", event.target.value)} placeholder="https://…" /></label>
        <label className="admin-source-form-wide">Примечание / атрибуция<textarea rows={2} maxLength={1000} value={candidateSource.attribution_text} onChange={(event: ChangeEvent<HTMLTextAreaElement>) => updateCandidate("attribution_text", event.target.value)} placeholder="Что известно о правах и происхождении" /></label>
      </div>
      <button type="submit" disabled={busy !== null || loading}>{busy === "source" ? "Добавление…" : "Добавить только как permission_required"}</button>
    </form>
    {loading ? <div className="empty">Загрузка локального реестра…</div> : error ? <div className="empty">{error}</div> : sources.length ? <div className="admin-source-list">{sources.map((source) => <article className="result admin-source" key={source.source_id}>
      <div className="admin-source-top"><div><small>{source.publisher} · {source.source_type} · {source.market_scope} · {source.rights_status}</small><h3>{source.title}</h3><p>{source.source_id} · ревизия {source.revision}</p></div><span className={`admin-status ${source.status}`}>{statusLabel(source.status)}</span></div>
      <div className="admin-source-grid"><span>Лицензия <b>{source.license_id || "Не указана"}</b></span><span>Коммерция <b>{rightsLabel(source.commercial_use_allowed)}</b></span><span>Показ <b>{rightsLabel(source.display_allowed)}</b></span><span>Офлайн-кэш <b>{rightsLabel(source.offline_cache_allowed)}</b></span><span>Массовое использование <b>{rightsLabel(source.bulk_reuse_allowed)}</b></span><span>Перераспространение <b>{rightsLabel(source.redistribution_allowed)}</b></span><span>Снимки <b>{source.snapshot_count}</b></span><span>Записи <b>{source.record_count} · проверено {source.verified_record_count}</b></span></div>
      <div className="admin-source-foot">{source.attribution_required ? "Требуется атрибуция" : "Атрибуция не требуется по реестру"}{source.share_alike_required ? " · Share-alike" : ""} · обновлён {dateLabel(source.updated_at)}</div>
      <div className="admin-source-links">{safeHttpsUrl(source.source_url) ? <a href={safeHttpsUrl(source.source_url)!} target="_blank" rel="noopener noreferrer">Источник</a> : null}{safeHttpsUrl(source.license_url) ? <a href={safeHttpsUrl(source.license_url)!} target="_blank" rel="noopener noreferrer">Лицензия</a> : null}</div>
    </article>)}</div> : <div className="empty">В пользовательской базе пока нет зарегистрированных источников. Исследовательские SQLite-наборы отображаются отдельно и не считаются подтверждёнными ремонтными данными.</div>}

    <div className="admin-section-head"><h2>Журнал импорта и версии</h2><span>{batches.length} последних пакетов</span></div>
    {batches.length ? <div className="admin-source-list">{batches.map((batch) => <article className="result admin-batch" key={batch.id}>
      <div className="admin-source-top"><div><small>{batch.publisher} · {batch.source_id}</small><h3>{batch.package_id}</h3><p>Ревизия {batch.source_revision} · {batch.market_scope}</p></div><span className={`admin-status ${batch.status}`}>{statusLabel(batch.status)}</span></div>
      <div className="admin-source-grid"><span>Записей в пакете <b>{batch.records_seen}</b></span><span>Добавлено <b>{batch.records_inserted}</b></span><span>Без изменений <b>{batch.records_unchanged}</b></span><span>Отклонено <b>{batch.rejected_items}</b></span></div>
      <div className="admin-source-foot">{dateLabel(batch.created_at)} · SHA-256 пакета {batch.package_sha256}</div>
    </article>)}</div> : <div className="empty">История импорта пуста. Никакие неподтверждённые данные не были записаны в пользовательскую базу.</div>}

    <div className="admin-bottom-actions"><button type="button" className="small secondary" onClick={() => void refresh()} disabled={loading || busy !== null}>Обновить реестр</button><span>Схема локальной базы: версия 1 · журналирование операций включено</span></div>
  </section>;
}
