import React from "react";

type Props = { mode: "MECHANIC" | "ELECTRICIAN" | "DIAGNOSTIC"; title: string };

const palette = { red: "#e43b46", cyan: "#4db6d5", green: "#7dc6a2", amber: "#e6b65c", line: "#738396", panel: "#172331", text: "#eaf0f6", muted: "#9eacbb" };

function Node({ x, y, w, h, title, sub, accent = palette.cyan }: {x:number;y:number;w:number;h:number;title:string;sub?:string;accent?:string}) {
  return <g>
    <rect x={x} y={y} width={w} height={h} rx="9" fill={palette.panel} stroke={accent} strokeWidth="1.5" />
    <rect x={x} y={y} width="4" height={h} rx="2" fill={accent} />
    <text x={x+14} y={y+23} fill={palette.text} fontSize="12" fontWeight="700">{title}</text>
    {sub && <text x={x+14} y={y+40} fill={palette.muted} fontSize="10">{sub}</text>}
  </g>;
}
function Wire({d, color=palette.line, dash=false}:{d:string;color?:string;dash?:boolean}) {
  return <path d={d} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" strokeDasharray={dash?"5 5":undefined}/>;
}

export default function SystemDiagram({mode,title}:Props) {
  if (mode === "ELECTRICIAN") return <div className="diagram-wrap">
    <div className="diagram-top"><span className="diagram-kicker">ЭЛЕКТРИЧЕСКАЯ АРХИТЕКТУРА</span><span className="diagram-chip">Обзорная схема</span></div>
    <svg viewBox="0 0 720 310" role="img" aria-label="Обзорная блок-схема автомобильной электрической системы">
      <defs><marker id="arrow-cyan" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="none" stroke={palette.cyan} strokeWidth="1.2"/></marker></defs>
      <Wire d="M150 82 H270 V150 H310" color={palette.amber}/><Wire d="M150 225 H270 V174 H310" color={palette.green}/>
      <Wire d="M410 160 H470 V82 H520" color={palette.cyan}/><Wire d="M410 160 H470 V225 H520" color={palette.cyan}/>
      <Wire d="M360 190 V260 H520" color={palette.line} dash/>
      <Node x={25} y={52} w={125} h={60} title="АКБ" sub="Питание 12 В" accent={palette.amber}/>
      <Node x={25} y={195} w={125} h={60} title="Масса кузова" sub="Точки соединения" accent={palette.green}/>
      <Node x={310} y={125} w={100} h={70} title="ECU" sub="Блок управления" accent={palette.red}/>
      <Node x={520} y={52} w={165} h={60} title="Датчики" sub="Входные сигналы"/>
      <Node x={520} y={195} w={165} h={60} title="Исполнители" sub="Выходные цепи"/>
      <Node x={520} y={260} w={165} h={38} title="Диагностический разъём" accent={palette.amber}/>
      <text x="180" y="70" fill={palette.amber} fontSize="10">Питание</text><text x="180" y="215" fill={palette.green} fontSize="10">Обратная цепь</text>
      <text x="440" y="145" fill={palette.cyan} fontSize="10">Сигналы / управление</text>
    </svg>
    <div className="diagram-legend"><span><i style={{background:palette.amber}}/>Питание</span><span><i style={{background:palette.green}}/>Масса</span><span><i style={{background:palette.cyan}}/>Сигнальные цепи</span><span><i style={{background:palette.red}}/>Блок управления</span></div>
    <p className="diagram-note">Функциональная схема для ориентации. Не является заводской электросхемой, не содержит назначений контактов и цветов проводов. Точная схема появится только после привязки к VIN, PR-кодам и ревизии документа.</p>
  </div>;

  if (mode === "DIAGNOSTIC") return <div className="diagram-wrap">
    <div className="diagram-top"><span className="diagram-kicker">ЛОГИКА ДИАГНОСТИКИ</span><span className="diagram-chip">Последовательность проверки</span></div>
    <svg viewBox="0 0 720 310" role="img" aria-label="Схема последовательности диагностической проверки">
      <defs><marker id="arrow-flow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="none" stroke={palette.line} strokeWidth="1.2"/></marker></defs>
      <Wire d="M165 155 H205 M335 155 H375 M505 155 H545"/>
      <Wire d="M440 190 V245 H270 V190" color={palette.amber} dash/>
      <Node x={25} y={120} w={140} h={70} title="Считать DTC" sub="Код + статус + freeze frame" accent={palette.red}/>
      <Node x={205} y={120} w={130} h={70} title="Проверить условия" sub="Напряжение, температура" accent={palette.amber}/>
      <Node x={375} y={120} w={130} h={70} title="Тест-план" sub="По точной конфигурации"/>
      <Node x={545} y={120} w={150} h={70} title="Подтвердить причину" sub="Измерение + повторный тест" accent={palette.green}/>
      <text x="285" y="265" fill={palette.amber} fontSize="11" textAnchor="middle">Если условия не соблюдены — вернуться к подготовке</text>
      <text x="360" y="70" fill={palette.muted} fontSize="11" textAnchor="middle">Не менять детали только по одному коду ошибки</text>
    </svg>
    <div className="diagram-legend"><span><i style={{background:palette.red}}/>Считывание</span><span><i style={{background:palette.amber}}/>Предварительные условия</span><span><i style={{background:palette.cyan}}/>Проверка</span><span><i style={{background:palette.green}}/>Подтверждение</span></div>
    <p className="diagram-note">Общий диагностический маршрут. Конкретные контрольные значения и тесты должны быть взяты из документа с подтверждённой применимостью к автомобилю.</p>
  </div>;

  return <div className="diagram-wrap">
    <div className="diagram-top"><span className="diagram-kicker">ТЕХНИЧЕСКАЯ КОМПОНОВКА УЗЛА</span><span className="diagram-chip">Схематический вид</span></div>
    <svg viewBox="0 0 720 310" role="img" aria-label="Схематическая компоновка силового агрегата">
      <rect x="35" y="35" width="650" height="240" rx="18" fill="#111b27" stroke="#344456" strokeWidth="1.5"/>
      <path d="M90 90 Q90 65 120 65 H350 Q380 65 380 95 V220 Q380 245 350 245 H120 Q90 245 90 220 Z" fill="#202e3c" stroke="#8c9bab" strokeWidth="2"/>
      <rect x="130" y="105" width="200" height="95" rx="12" fill="#293b4d" stroke={palette.cyan} strokeWidth="2"/>
      <path d="M150 125 H310 M150 145 H310 M150 165 H310 M150 185 H310" stroke="#61788d" strokeWidth="5" strokeLinecap="round"/>
      <circle cx="430" cy="150" r="58" fill="#202e3c" stroke={palette.amber} strokeWidth="3"/><circle cx="430" cy="150" r="32" fill="none" stroke="#8294a7" strokeWidth="5"/><circle cx="430" cy="150" r="9" fill={palette.amber}/>
      <rect x="515" y="85" width="115" height="54" rx="9" fill="#202e3c" stroke={palette.red} strokeWidth="2"/><rect x="515" y="164" width="115" height="54" rx="9" fill="#202e3c" stroke={palette.green} strokeWidth="2"/>
      <path d="M330 150 H372 M488 150 H515 M572 139 V164" stroke={palette.line} strokeWidth="3" fill="none"/>
      <text x="230" y="95" fill={palette.text} fontSize="12" textAnchor="middle">Корпус двигателя</text>
      <text x="230" y="220" fill={palette.muted} fontSize="10" textAnchor="middle">Блок / головка — условно</text>
      <text x="430" y="230" fill={palette.amber} fontSize="11" textAnchor="middle">Привод</text>
      <text x="572" y="117" fill={palette.text} fontSize="11" textAnchor="middle">Впуск</text><text x="572" y="196" fill={palette.text} fontSize="11" textAnchor="middle">Выпуск</text>
      <text x="360" y="292" fill={palette.muted} fontSize="10" textAnchor="middle">Условная компоновка, не чертёж конкретного двигателя</text>
    </svg>
    <div className="diagram-legend"><span><i style={{background:palette.cyan}}/>Основной узел</span><span><i style={{background:palette.amber}}/>Механический привод</span><span><i style={{background:palette.red}}/>Впускной тракт</span><span><i style={{background:palette.green}}/>Выпускной тракт</span></div>
    <p className="diagram-note">Графическая навигация по узлу «{title}». Геометрия и расположение элементов условные; точные размеры, метки, моменты затяжки и порядок разборки не подменяются этой иллюстрацией.</p>
  </div>;
}
