"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";

type Module = "MECHANIC" | "ELECTRICIAN" | "DIAGNOSTIC";
type View = "workspace" | "garage" | "bookmarks" | "history";
type Vehicle = {
  id: number; nickname: string; brand_name: string; model_name: string; generation_name: string | null; market_scope: string;
  model_year: number | null; engine_code_declared: string | null; transmission_code_declared: string | null; ecu_declared: string | null;
  pr_codes: string[]; configuration_id: number | null; identity_status: string; notes: string | null; is_default: number; created_at: string; updated_at: string;
};
type VerifiedConfiguration = {
  id: number; brand_name: string; model_name: string; generation_name: string; market_scope: string; model_year: number | null;
  engine_code: string; transmission_code: string; ecu_family: string | null; hardware_number: string | null; software_number: string | null; pr_codes: string[];
};
type Bookmark = { id: number; target_type: string; target_key: string; label: string; created_at: string };
type HistoryItem = { id: number; query_text: string; module_code: string; result_count: number; created_at: string };
type TechnicalRecord = {
  id: number; record_type: string; namespace: string | null; natural_key: string; title: string; summary: string | null;
  market_scope: string; applicability_precision: string; configuration_id: number | null; ecu_id: number | null;
  source_id: string; source_revision: string; source_record_key: string; record_sha256: string; payload: Record<string, unknown>;
  publisher: string; source_title: string; license_id: string; license_url: string | null; attribution_text: string | null;
};

type Props = {
  view: View;
  active: Module;
  selected: string;
  sections: string[];
  onSelect: (section: string) => void;
  onMessage: (message: string) => void;
  onViewResearch: () => void;
};

const moduleNames: Record<Module, string> = { MECHANIC: "Механика и ремонт", ELECTRICIAN: "Автоэлектрика", DIAGNOSTIC: "Диагностика" };

function recordTypesFor(active: Module, selected: string): string[] {
  if (active === "MECHANIC") {
    if (/сервис|обслуж/i.test(selected)) return ["service_interval", "repair_procedure"];
    if (/короб|сцеплен|трансмисс/i.test(selected)) return ["repair_procedure", "torque_specification", "oem_part"];
    return ["repair_procedure", "torque_specification", "oem_part", "oem_supersession"];
  }
  if (active === "ELECTRICIAN") {
    if (/ecu|блок/i.test(selected)) return ["ecu_reference", "pinout", "wiring_diagram"];
    return ["wiring_diagram", "pinout", "ecu_reference"];
  }
  if (/адапта|кодирован|базов|сервис/i.test(selected)) return ["adaptation", "diagnostic_test_plan"];
  if (/dtc|ошибк/i.test(selected)) return ["dtc_vag_specific", "diagnostic_test_plan"];
  return ["diagnostic_test_plan", "dtc_vag_specific", "adaptation"];
}

async function readJson(response: Response) {
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof body.error === "string" ? body.error : `HTTP ${response.status}`);
  return body;
}

export default function LocalOfflineWorkspace({ view, active, selected, sections, onSelect, onMessage, onViewResearch }: Props) {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [verifiedConfigurations, setVerifiedConfigurations] = useState<VerifiedConfiguration[]>([]);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [coverage, setCoverage] = useState<Array<{ record_type: string; verified_count: number }>>([]);
  const [selectedVehicleId, setSelectedVehicleId] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showVehicleForm, setShowVehicleForm] = useState(view === "garage");
  const [brand, setBrand] = useState("Volkswagen");
  const [model, setModel] = useState("");
  const [generation, setGeneration] = useState("");
  const [market, setMarket] = useState("RU");
  const [year, setYear] = useState("");
  const [engine, setEngine] = useState("");
  const [transmission, setTransmission] = useState("");
  const [ecu, setEcu] = useState("");
  const [prCodes, setPrCodes] = useState("");
  const [nickname, setNickname] = useState("");
  const [notes, setNotes] = useState("");
  const [savingVehicle, setSavingVehicle] = useState(false);
  const [query, setQuery] = useState("");
  const [records, setRecords] = useState<TechnicalRecord[]>([]);
  const [searching, setSearching] = useState(false);

  const selectedVehicle = useMemo(() => vehicles.find((item) => String(item.id) === selectedVehicleId) || null, [vehicles, selectedVehicleId]);
  const matchingConfigurations = useMemo(() => selectedVehicle ? verifiedConfigurations.filter((item) => item.brand_name.toLocaleLowerCase("ru") === selectedVehicle.brand_name.toLocaleLowerCase("ru") && item.model_name.toLocaleLowerCase("ru") === selectedVehicle.model_name.toLocaleLowerCase("ru")) : [], [verifiedConfigurations, selectedVehicle]);

  const loadSummary = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/local-core?action=summary", { cache: "no-store" });
      const body = await readJson(response);
      const nextVehicles = Array.isArray(body.vehicles) ? body.vehicles : [];
      setVehicles(nextVehicles);
      setVerifiedConfigurations(Array.isArray(body.verifiedConfigurations) ? body.verifiedConfigurations : []);
      setBookmarks(Array.isArray(body.bookmarks) ? body.bookmarks : []);
      setHistory(Array.isArray(body.history) ? body.history : []);
      setCoverage(Array.isArray(body.moduleCoverage) ? body.moduleCoverage : []);
      setSelectedVehicleId((current) => current && nextVehicles.some((item: Vehicle) => String(item.id) === current)
        ? current : String(nextVehicles.find((item: Vehicle) => item.is_default)?.id || nextVehicles[0]?.id || ""));
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Локальная база недоступна";
      setError(message);
      onMessage(`Локальная SQLite недоступна: ${message}`);
    } finally { setLoading(false); }
  }, [onMessage]);

  useEffect(() => { void loadSummary(); }, [loadSummary]);
  useEffect(() => { setShowVehicleForm(view === "garage"); }, [view]);
  useEffect(() => { setRecords([]); setQuery(""); }, [active, selected]);

  async function post(body: Record<string, unknown>) {
    const response = await fetch("/api/local-core", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), cache: "no-store" });
    return readJson(response);
  }

  async function saveVehicle(event: FormEvent) {
    event.preventDefault();
    if (!brand.trim() || !model.trim()) { onMessage("Укажите марку и модель автомобиля."); return; }
    setSavingVehicle(true);
    try {
      const body = await post({ action: "vehicle.save", vehicle: {
        brand_name: brand.trim(), model_name: model.trim(), generation_name: generation.trim() || null, market_scope: market,
        model_year: year ? Number(year) : null, engine_code_declared: engine.trim() || null, transmission_code_declared: transmission.trim() || null,
        ecu_declared: ecu.trim() || null, pr_codes: prCodes.split(/[\s,;]+/).map((item) => item.trim()).filter(Boolean),
        nickname: nickname.trim() || `${brand.trim()} ${model.trim()}`, notes: notes.trim() || null, is_default: vehicles.length === 0,
      } });
      await loadSummary();
      if (body.vehicle?.id) setSelectedVehicleId(String(body.vehicle.id));
      setModel(""); setGeneration(""); setYear(""); setEngine(""); setTransmission(""); setEcu(""); setPrCodes(""); setNickname(""); setNotes("");
      setShowVehicleForm(view === "garage");
      onMessage("Автомобиль сохранён локально. Введённые коды двигателя и КПП помечены как заявления пользователя, а не подтверждённая применимость.");
    } catch (cause) { onMessage(cause instanceof Error ? cause.message : "Не удалось сохранить автомобиль"); }
    finally { setSavingVehicle(false); }
  }

  async function linkConfiguration(configurationId: number) {
    if (!selectedVehicle) { onMessage("Сначала добавьте автомобиль в локальный гараж."); return; }
    try {
      await post({ action: "vehicle.link-config", vehicle_id: selectedVehicle.id, configuration_id: configurationId });
      await loadSummary();
      onMessage("Автомобиль связан с точной проверенной конфигурацией. Технический поиск теперь может использовать эту применимость.");
    } catch (cause) { onMessage(cause instanceof Error ? cause.message : "Не удалось связать конфигурацию"); }
  }

  async function removeVehicle(id: number) {
    try { await post({ action: "vehicle.delete", id }); await loadSummary(); onMessage("Автомобиль удалён из локального гаража."); }
    catch (cause) { onMessage(cause instanceof Error ? cause.message : "Не удалось удалить автомобиль"); }
  }
  async function makeDefault(id: number) {
    try { await post({ action: "vehicle.default", id }); await loadSummary(); onMessage("Основной автомобиль обновлён."); }
    catch (cause) { onMessage(cause instanceof Error ? cause.message : "Не удалось изменить основной автомобиль"); }
  }
  async function renameVehicle(item: Vehicle) {
    const value = window.prompt("Новое название автомобиля", item.nickname);
    if (value === null || !value.trim()) return;
    try { await post({ action: "vehicle.rename", id: item.id, nickname: value.trim() }); await loadSummary(); onMessage("Название автомобиля сохранено."); }
    catch (cause) { onMessage(cause instanceof Error ? cause.message : "Не удалось переименовать автомобиль"); }
  }

  async function search(event?: FormEvent) {
    event?.preventDefault();
    const q = query.trim().slice(0, 100);
    if (q.length < 2) { onMessage("Введите не менее двух символов для поиска."); return; }
    if (!selectedVehicle?.configuration_id) {
      setRecords([]);
      onMessage("Поиск технических данных остановлен: выбран автомобиль без подтверждённой конфигурации двигателя, КПП и рынка. Ручные значения сохранены как неподтверждённые и не используются для подбора ремонта.");
      return;
    }
    setSearching(true);
    try {
      const types = recordTypesFor(active, selected);
      const responses = await Promise.all(types.map(async (recordType) => {
        const params = new URLSearchParams({ action: "records", record_type: recordType, configuration_id: String(selectedVehicle.configuration_id), q, limit: "20" });
        const response = await fetch(`/api/local-core?${params.toString()}`, { cache: "no-store" });
        const body = await readJson(response);
        return Array.isArray(body.rows) ? body.rows as TechnicalRecord[] : [];
      }));
      const combined = responses.flat().sort((a, b) => a.title.localeCompare(b.title)).slice(0, 50);
      setRecords(combined);
      await post({ action: "history.add", entry: { query_text: q, module_code: active, configuration_id: selectedVehicle.configuration_id, result_count: combined.length } });
      await loadSummary();
      onMessage(combined.length ? `Найдено подтверждённых записей: ${combined.length}.` : "Для выбранной точной конфигурации подтверждённых совпадений нет. Кандидаты из исследовательских наборов не подставляются.");
    } catch (cause) { setRecords([]); onMessage(cause instanceof Error ? cause.message : "Локальный поиск не выполнен"); }
    finally { setSearching(false); }
  }

  async function addBookmark(record: TechnicalRecord) {
    try {
      await post({ action: "bookmark.save", bookmark: { target_type: "technical_record", target_key: String(record.id), label: record.title } });
      await loadSummary(); onMessage("Запись добавлена в локальные закладки.");
    } catch (cause) { onMessage(cause instanceof Error ? cause.message : "Не удалось добавить закладку"); }
  }
  async function removeBookmark(id: number) {
    try { await post({ action: "bookmark.delete", id }); await loadSummary(); onMessage("Закладка удалена."); }
    catch (cause) { onMessage(cause instanceof Error ? cause.message : "Не удалось удалить закладку"); }
  }

  if (loading && !vehicles.length && !error) return <section className="content"><div className="empty">Открываем локальную SQLite и загружаем личные данные…</div></section>;
  if (error) return <section className="content"><div className="empty"><b>Локальное хранилище недоступно</b><p>{error}</p><button className="small" onClick={() => void loadSummary()}>Повторить</button></div></section>;

  if (view === "garage") return <section className="content list-view local-offline-view">
    <div className="head"><h1>Локальный гараж</h1><span>{vehicles.length} автомобилей</span></div>
    <p className="local-note">VIN не обязателен и не сохраняется. Двигатель, КПП, ECU и PR-коды, введённые вручную, имеют статус «заявлено пользователем» и не подтверждают применимость ремонтных данных.</p>
    <button className="small" onClick={() => setShowVehicleForm((value) => !value)}>{showVehicleForm ? "Скрыть форму" : "Добавить автомобиль вручную"}</button>
    {showVehicleForm && <form className="local-vehicle-form" onSubmit={saveVehicle}>
      <div className="local-form-grid">
        <label>Марка<input value={brand} onChange={(e) => setBrand(e.target.value)} maxLength={80} required placeholder="Volkswagen / Audi / Škoda…" /></label>
        <label>Модель<input value={model} onChange={(e) => setModel(e.target.value)} maxLength={100} required placeholder="Golf, Passat, Octavia…" /></label>
        <label>Поколение / платформа<input value={generation} onChange={(e) => setGeneration(e.target.value)} maxLength={100} placeholder="Например, VII / MQB — без подтверждения" /></label>
        <label>Рынок<select value={market} onChange={(e) => setMarket(e.target.value)}><option value="RU">Россия</option><option value="EAEU">ЕАЭС</option><option value="EU">Европа</option><option value="UNKNOWN">Неизвестен</option></select></label>
        <label>Год выпуска<input value={year} onChange={(e) => setYear(e.target.value.replace(/[^0-9]/g, "").slice(0, 4))} inputMode="numeric" placeholder="2017" /></label>
        <label>Код двигателя<input value={engine} onChange={(e) => setEngine(e.target.value.toUpperCase().slice(0, 24))} placeholder="Заявленный код" /></label>
        <label>Код КПП<input value={transmission} onChange={(e) => setTransmission(e.target.value.toUpperCase().slice(0, 24))} placeholder="Заявленный код" /></label>
        <label>ECU / аппаратный номер<input value={ecu} onChange={(e) => setEcu(e.target.value.toUpperCase().slice(0, 80))} placeholder="Не подтверждено" /></label>
        <label>PR-коды<input value={prCodes} onChange={(e) => setPrCodes(e.target.value.toUpperCase().slice(0, 600))} placeholder="1AT, 7L6…" /></label>
        <label>Название в гараже<input value={nickname} onChange={(e) => setNickname(e.target.value)} maxLength={100} placeholder="Мой Golf" /></label>
      </div>
      <label>Заметки<textarea value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={2000} rows={3} placeholder="Комплектация, наблюдения, история работ…" /></label>
      <button type="submit" disabled={savingVehicle}>{savingVehicle ? "Сохранение…" : "Сохранить в локальный гараж"}</button>
    </form>}
    {vehicles.length ? vehicles.map((item) => <article className="result garage-item" key={item.id}><div><h3>{item.nickname} {item.is_default ? <span className="garage-default">Основной</span> : null}</h3><p>{[item.brand_name,item.model_name,item.generation_name,item.model_year?`MY ${item.model_year}`:null,item.market_scope,item.engine_code_declared?`ДВС ${item.engine_code_declared}`:null,item.transmission_code_declared?`КПП ${item.transmission_code_declared}`:null,item.ecu_declared?`ECU ${item.ecu_declared}`:null,item.pr_codes.length?`PR ${item.pr_codes.join("/")}`:null].filter(Boolean).join(" · ")}</p><small>{item.identity_status === "exact_configuration_verified" ? "Точная конфигурация подтверждена" : "Заявлено пользователем · точная применимость не подтверждена"}</small></div><div className="garage-actions"><button className="small" onClick={() => setSelectedVehicleId(String(item.id))}>Выбрать</button>{!item.is_default ? <button className="small" onClick={() => void makeDefault(item.id)}>Основной</button> : null}<button className="small" onClick={() => void renameVehicle(item)}>Переименовать</button><button className="small danger" onClick={() => void removeVehicle(item.id)}>Удалить</button></div></article>) : <div className="empty">Гараж пуст. Добавьте автомобиль вручную — VIN не нужен.</div>}
  </section>;

  if (view === "bookmarks") return <section className="content list-view local-offline-view"><div className="head"><h1>Мои закладки</h1><span>{bookmarks.length}</span></div>{bookmarks.length ? bookmarks.map((item) => <article className="result" key={item.id}><div><h3>{item.label}</h3><small>{item.target_type} · {new Date(item.created_at).toLocaleString()}</small></div><button className="small danger" onClick={() => void removeBookmark(item.id)}>Удалить</button></article>) : <div className="empty">Локальных закладок пока нет.</div>}</section>;

  if (view === "history") return <section className="content list-view local-offline-view"><div className="head"><h1>История запросов</h1><span>{history.length}</span></div>{history.length ? history.map((item) => <article className="result" key={item.id}><div><h3>{item.query_text}</h3><small>{item.module_code} · {item.result_count} результатов · {new Date(item.created_at).toLocaleString()}</small></div></article>) : <div className="empty">История локального поиска пока пуста.</div>}</section>;

  return <section className="content local-offline-view">
    <div className="crumb">Офлайн-режим　›　{moduleNames[active]}　›　{selected}</div>
    <div className="head"><h1>{moduleNames[active]}</h1><span>Локальная SQLite · без облачной зависимости</span></div>
    <div className="local-vehicle-strip">
      <label>Текущий автомобиль<select value={selectedVehicleId} onChange={(e) => setSelectedVehicleId(e.target.value)}><option value="">Не выбран</option>{vehicles.map((item) => <option key={item.id} value={item.id}>{item.nickname} · {item.brand_name} {item.model_name}</option>)}</select></label>
      <div className="local-vehicle-status">{selectedVehicle ? <><b>{selectedVehicle.identity_status === "exact_configuration_verified" ? "Проверенная конфигурация" : "Ручной выбор · не подтверждено"}</b><small>{[selectedVehicle.brand_name,selectedVehicle.model_name,selectedVehicle.generation_name,selectedVehicle.model_year?`MY ${selectedVehicle.model_year}`:null,selectedVehicle.engine_code_declared?`ДВС ${selectedVehicle.engine_code_declared}`:null,selectedVehicle.transmission_code_declared?`КПП ${selectedVehicle.transmission_code_declared}`:null].filter(Boolean).join(" · ")}</small></> : <><b>Автомобиль не выбран</b><small>Добавьте его в локальный гараж</small></>}</div>
      {selectedVehicle && matchingConfigurations.length > 0 ? <label className="local-config-select">Точная конфигурация<select value={selectedVehicle.configuration_id || ""} onChange={(e) => { if (e.target.value) void linkConfiguration(Number(e.target.value)); }}><option value="">Выберите подтверждённую конфигурацию</option>{matchingConfigurations.map((item) => <option key={item.id} value={item.id}>{[item.generation_name,item.market_scope,item.model_year?`MY ${item.model_year}`:null,item.engine_code,item.transmission_code,item.ecu_family,item.hardware_number,item.pr_codes.length?`PR ${item.pr_codes.join("/")}`:null].filter(Boolean).join(" · ")}</option>)}</select></label> : null}
      <button className="small" onClick={() => setShowVehicleForm((value) => !value)}>＋ Автомобиль</button>
    </div>
    {showVehicleForm && <form className="local-vehicle-form compact" onSubmit={saveVehicle}>
      <div className="local-form-grid"><label>Марка<input value={brand} onChange={(e) => setBrand(e.target.value)} required /></label><label>Модель<input value={model} onChange={(e) => setModel(e.target.value)} required /></label><label>Поколение<input value={generation} onChange={(e) => setGeneration(e.target.value)} /></label><label>Рынок<select value={market} onChange={(e) => setMarket(e.target.value)}><option value="RU">Россия</option><option value="EAEU">ЕАЭС</option><option value="EU">Европа</option><option value="UNKNOWN">Неизвестен</option></select></label><label>Год<input value={year} onChange={(e) => setYear(e.target.value.replace(/[^0-9]/g, "").slice(0,4))} /></label><label>Двигатель<input value={engine} onChange={(e) => setEngine(e.target.value.toUpperCase())} /></label><label>КПП<input value={transmission} onChange={(e) => setTransmission(e.target.value.toUpperCase())} /></label><label>ECU<input value={ecu} onChange={(e) => setEcu(e.target.value.toUpperCase())} /></label><label>PR-коды<input value={prCodes} onChange={(e) => setPrCodes(e.target.value.toUpperCase())} /></label><label>Название<input value={nickname} onChange={(e) => setNickname(e.target.value)} /></label></div>
      <button type="submit" disabled={savingVehicle}>{savingVehicle ? "Сохранение…" : "Сохранить автомобиль"}</button>
    </form>}
    <div className="local-module-layout">
      <aside className="local-section-list"><b>Разделы</b>{sections.map((item) => <button key={item} className={selected === item ? "active" : ""} onClick={() => onSelect(item)}>{item}</button>)}</aside>
      <div className="local-module-content">
        <div className="local-coverage"><span>Подтверждённых записей в базе: <b>{coverage.reduce((sum, item) => sum + item.verified_count, 0)}</b></span><span>Кандидаты не используются для ремонта</span></div>
        <form className="local-search" onSubmit={search}><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Поиск по проверенным техническим записям…" aria-label="Поиск по локальной технической базе" /><button type="submit" disabled={searching || !selectedVehicle?.configuration_id}>{searching ? "Поиск…" : "Найти"}</button></form>
        {!selectedVehicle ? <div className="empty">Сначала выберите автомобиль или добавьте его в локальный гараж. Ручной выбор не требует VIN.</div>
          : !selectedVehicle.configuration_id ? <div className="empty"><b>Точная конфигурация пока не подтверждена.</b><p>Сохранённые вручную двигатель и КПП не используются как доказательство применимости. После появления разрешённых источников и проверки связей приложение сможет привязать документы к точной конфигурации.</p><button className="small" onClick={() => onViewResearch()}>Открыть локальные исследовательские наборы</button></div>
          : records.length ? <div className="results">{records.map((record) => <article className="result" key={record.id}><div><small>{record.record_type} · {record.market_scope} · {record.applicability_precision}</small><h3>{record.title}</h3><p>{record.summary || (typeof record.payload?.description === "string" ? record.payload.description : "Проверенная техническая запись")}</p><details className="result-provenance"><summary>Источник, ревизия и точность</summary><dl><dt>Издатель</dt><dd>{record.publisher}</dd><dt>Источник</dt><dd>{record.source_title}</dd><dt>Ревизия</dt><dd>{record.source_revision}</dd><dt>Ключ записи</dt><dd>{record.source_record_key}</dd><dt>SHA-256 записи</dt><dd>{record.record_sha256}</dd><dt>Лицензия</dt><dd>{record.license_id}</dd><dt>Применимость</dt><dd>{record.applicability_precision} · {record.market_scope}</dd></dl>{record.license_url ? <a href={record.license_url} target="_blank" rel="noopener noreferrer">Текст лицензии</a> : null}{record.attribution_text ? <p>{record.attribution_text}</p> : null}<pre>{JSON.stringify(record.payload,null,2)}</pre></details></div><button className="small" onClick={() => void addBookmark(record)}>♧ В закладки</button></article>)}</div>
          : <div className="empty">В локальной базе пока нет подтверждённых записей для этой конфигурации. Кандидаты, универсальные DTC и community-сигналы доступны отдельно в исследовательских наборах и не выдаются за заводские данные.</div>}
        <div className="local-module-footer"><button className="small" onClick={() => onViewResearch()}>Локальные справочники и кандидаты</button><span>Схемы и изображения без заводского источника не подменяют оригинальную документацию.</span></div>
      </div>
    </div>
  </section>;
}
