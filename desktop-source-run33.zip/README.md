# VAG TECH PRO

Non-commercial technical knowledge base and repair-workflow project for Volkswagen Group vehicles, with an initial focus on the Russian market.

## Project principles

- Keep vehicle identity, homologation, diagnostic data, repair information and OEM parts applicability as separate evidence domains.
- Preserve source, revision, market, production scope and licensing status for every imported record.
- Never infer engine codes, gearbox codes, ECU identifiers, PR codes or part fitment from descriptive labels or model-year guesses.
- Keep incomplete ECU suffixes and ambiguous engine/gearbox relationships unresolved.
- Do not scrape or replicate restricted catalogues. Public access does not imply redistribution rights.
- Do not publish or import staging records until technical review and reuse rights are cleared.

## Main project areas

- `app/` — Next.js application and admin workflows.
- `lib/` — VIN decoding, OEM normalization and fitment evidence helpers.
- `data/source-manifests/` — source, rights and public-document acquisition registers.
- `data/import-staging/` — reviewed-but-not-imported datasets, homologation extractions, evidence graphs and provider contracts.
- `data/research/` — separate licensed, read-only offline SQLite packs with provenance and fitment boundaries.
- `scripts/` — validation, dataset preparation, source acquisition and graph-building scripts.
- `tests/` — automated tests for VIN handling, source provenance, fitment and data integrity.
- `docs/` — engineering log, source policy, ingestion workflow, schema and release status.

## Key validation commands

```bash
npm test
npm run validate:primary-otts
npm run validate:secondary-otts
npm run validate:visual-review
npm run validate:public-otts-pdfs
npm run build:vag-technical-graph
npm run validate:migrations
```

## Historical evidence status (2026-11-02)

- Primary homologation extraction remains staging-only; reuse rights are not verified.
- SEAT Leon 1P P3 original scan PDF is publicly indexed and its parsed table structure has been reviewed. Raster screenshot verification remains pending. Three additional engine/gearbox pairs were recovered from the printed page 8 table; seven gearbox identifiers remain unpaired.
- Audi Q7 P4 and Volkswagen Passat 3C source PDFs are linked publicly, but their bytes/page images could not be retrieved in the current runtime.
- The technical graph contains 26 explicit engine-to-transmission edges and 7 unpaired transmission identifiers across the current primary-document set.
- The per-VIN OEM verification workflow is defined, but no customer VIN or authorized OEM catalogue response has been supplied. No OEM parts fitment has been imported.
- At that checkpoint, automated test suites: VIN 7, integrity 155, OEM/VIN workflow and provider contracts 24; all passed (186 total).
- Supabase migrations are not applied automatically. Review `docs/MIGRATION_RECONCILIATION.md` before any migration work.

## Supplier API integration

- AvtoTO is staged as a downstream Russian supplier offer/availability provider, not as an OEM catalogue or VIN decoder.
- The read-only adapter scaffold is `lib/providers/avtoto-supplier.cjs`; configure `AVTOTO_USER_ID`, `AVTOTO_USER_LOGIN` and `AVTOTO_USER_PASSWORD` only in server-side secrets after a signed supply contract and IP allowlisting.
- Provider contract: `data/import-staging/avtoto-supplier-api-contract.json`. The official sample archive could not be downloaded in this runtime; only documented interface details were extracted.

## Local OTTS SQLite staging seed

A research-only SQLite database can be rebuilt with `npm run build:otts-staging-sqlite` (Node.js 22+). It preserves source-document provenance, page-level evidence, homologation-type candidates, engine/transmission candidates, explicit document-scoped pairings, ECU wildcard status and unresolved items. It is not the production catalogue: reuse rights remain unverified and every row remains staging-only. The builder uses a per-output manifest, an exclusive lock and no-overwrite atomic publication; choose a new versioned output path for each snapshot. See `docs/OTTS_STAGING_SQLITE.md`.

An optional **owner-authorized FGIS Annex 2 metadata importer** is available as `npm run prepare:authorized-fgis-otts`. It accepts only an export obtained lawfully by the owner plus an owner-reviewed license text or written permission document whose exact SHA-256 is pinned in the package manifest. It does not scrape FGIS or download PDFs. Public Annex 2 metadata is kept in a separate review-only SQLite staging database; engine, gearbox, ECU, VIN, PR-code and exact-configuration claims are rejected because they are not Annex 2 fields. All imported records remain `needs_review` and unpublished. See `docs/OTTS_AUTHORIZED_EXPORT_IMPORT.md`.

## Security and configuration

Copy `.env.local.example` to `.env.local` and supply credentials locally. Never commit `.env.local`, API keys, provider credentials or customer VINs. Customer VINs must be access-controlled, masked in logs and retained only for an authorized repair/order purpose.

The main SQLite schema can be generated from research staging with `npm run migrate:main-sqlite`. It preserves unapproved records in a research quarantine and does not promote them to production until reuse rights, import approval and publication approval are all verified. The isolated generic OBDex snapshot can be fetched with `npm run download:obdex` and normalized with `npm run prepare:open-obdex`; see `docs/MAIN_SQLITE_MIGRATION.md`.


## Offline research data packs

The Windows desktop packaging definition includes five separately licensed, read-only SQLite research packs: generic OBDex DTC/PIDs (CC0), VAG identity candidates (ODbL), community UDS signal candidates (CC BY-SA 4.0), VehiclesDB make/model candidates (CC BY 4.0) and a separate MechanicDB Audi/VW DTC sample (ODbL 1.0, with upstream MIT notice). They remain research-only; generic DTCs are not VAG-specific, identity candidates do not establish exact fitment, VehiclesDB contains no Russian-market evidence, and the two MechanicDB candidates are hidden pending technical review. See `docs/RESEARCH_DATA_PACKS.md` and run `npm run verify:local-research`. Russian/EAEU OTTS staging data is not shipped while reuse rights remain unconfirmed.


## Current checkpoint (2026-11-03)

- `npm test` passes 259/259 tests in the current source snapshot after the authorized FGIS importer and staging-publication safety tests.
- Five separate offline SQLite research packs pass the local verifier: CC0 generic OBDex, ODbL VAG identity candidates, CC BY-SA 4.0 community UDS candidates, CC BY 4.0 VehiclesDB identity candidates and the separate ODbL MechanicDB two-row candidate sample. The latter remains hidden and non-fitment. VehiclesDB is foreign-market-only and has zero RU evidence. See `docs/RESEARCH_DATA_PACKS.md`.
- The local Supabase migration ledger matches the live project: 62/62 normalized SQL bodies; former local variants are archived with SHA-256 records.
- The Supabase catalogue is not yet a professional repair database: 784 generations remain draft; engines, transmissions, ECU units, exact configurations and technical repair modules are empty.
- The local research API verifies all five packs and provenance/license/attribution hashes at runtime. The FGIS Annex 2 importer is owner-supplied, rights-gated, metadata-only and staging-only; no real FGIS export has been imported. The Windows NSIS installer has not been built or lifecycle-tested. Dependency installation/lockfile generation remains blocked by npm registry access in the current environment.

### Windows x64 offline data-pack CI

The rights-filtered Windows data-pack workflow passed run `41595547071` and produced a four-pack, separately licensed SQLite bundle. The bundle is stored in the project Library under `VAG_TECH_PRO/Research`; its SHA-256 is `d0db1cf77d7af1a04db5497a287d366eae8cd849e32debfab0d4fe0e8e8cc12b`. This is a data artifact, not the Windows desktop installer. The full Wal33D database remains excluded because its data-specific redistribution rights are not confirmed; the separately licensed MechanicDB free sample is a different, limited two-row ODbL pack and remains hidden pending technical review.


## Windows offline local core

The Windows desktop uses a separate per-user SQLite core database (`VAG_TECH_PRO_DB_PATH`, under Electron user data). It is distinct from the research staging databases. The v1 schema and migration checksum are stored in `data/sql/local-core-v1.sql` and `lib/local-core-db.cjs`.

Offline users can manually add vehicles without VIN, keep a local garage, bookmarks and query history, and open the mechanic/electrician/diagnostic workspaces. Manually entered engine/gearbox codes remain unverified until linked to a rights-cleared exact configuration. The technical search displays only verified records with source snapshot, license and applicability provenance. Generic SAE/ISO DTC research is kept separate from VAG-specific DTC. See [Local Core Database](docs/LOCAL_CORE_DATABASE.md).

The local package importer and backup/restore functions are implemented and tested, but the local admin source/import UI and backup/restore dialogs are not yet connected. The local repair catalogue still has no verified production vehicle configurations or repair records; research packs are not promoted automatically.
