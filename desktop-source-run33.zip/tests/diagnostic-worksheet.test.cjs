"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const component = fs.readFileSync(path.join(__dirname, "../components/diagnostic-worksheet.tsx"), "utf8");
const route = fs.readFileSync(path.join(__dirname, "../app/api/local-research/route.ts"), "utf8");

test("diagnostic worksheet queries the isolated generic SAE/ISO DTC research namespace", () => {
  assert.match(component, /api\/local-research\?dataset=dtc/);
  assert.match(component, /Общий справочник SAE\/ISO OBD-II/);
  assert.match(component, /GENERIC SAE\/ISO/);
  assert.match(component, /не VAG-specific/);
  assert.match(component, /generic_sae_iso_obd2/);
  assert.match(route, /dataset === "dtc".*searchGenericDtcs/s);
});

test("generic DTC results retain provenance and never claim vehicle or ECU fitment", () => {
  assert.match(component, /sourceRecordSha256/);
  assert.match(component, /sourceManifestSha256/);
  assert.match(component, /upstreamRevision/);
  assert.match(component, /snapshotGeneratedAt/);
  assert.match(component, /fitmentClaim/);
  assert.match(component, /Не подтверждает наличие неисправности в выбранном автомобиле/);
  assert.match(component, /Не является указанием на замену детали/);
});

test("generic DTC lookup does not query or promote the hidden manufacturer candidate pack", () => {
  assert.doesNotMatch(component, /dataset=dtc-candidates/);
  assert.doesNotMatch(component, /manufacturer_controlled_candidate/);
  assert.match(component, /В общем SAE\/ISO наборе совпадений нет/);
});
