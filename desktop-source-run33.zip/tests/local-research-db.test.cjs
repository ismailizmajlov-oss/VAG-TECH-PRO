"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const fs = require("node:fs");
const os = require("node:os");
const crypto = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");
const local = require("../lib/local-research-db.cjs");

const root = path.resolve(__dirname, "../data/research");

test("local research summary reports only the licensed read-only packs and exact candidate counts", () => {
  const summary = local.getResearchSummary(root);
  assert.equal(summary.mode, "offline_read_only");
  const obdex = summary.packs.find((x) => x.id === "obdex-generic-cc0");
  const vag = summary.packs.find((x) => x.id === "vag-identity-odbl");
  assert.deepEqual(obdex.counts, { dtcs: 9533, pids: 132 });
  assert.equal(obdex.license, "CC0-1.0");
  assert.equal(obdex.fitmentClaim, false);
  assert.deepEqual(vag.counts, { makes: 5, models: 233, generations: 823, engineVariants: 5081 });
  assert.equal(vag.marketScope, "UNKNOWN");
  assert.equal(vag.license, "ODbL-1.0");
  const obdb = summary.packs.find((x) => x.id === "obdb-vag-signals-cc-by-sa");
  assert.deepEqual(obdb.counts, { sources: 6, generations: 32, ecus: 15, commands: 2315, signals: 2480 });
  assert.equal(obdb.license, "CC-BY-SA-4.0");
  assert.equal(obdb.marketScope, "UNKNOWN");
  assert.equal(obdb.executionAllowed, false);
  assert.equal(obdb.shareAlikeRequired, true);
  assert.equal(obdb.attributionRequired, true);
  const vehiclesDb = summary.packs.find((x) => x.id === "vehiclesdb-vag-identity");
  assert.deepEqual(vehiclesDb.counts, { sources: 14, models: 260, marketEvidence: 1524, russianEvidence: 0 });
  assert.equal(vehiclesDb.license, "CC-BY-4.0");
  assert.equal(vehiclesDb.status, "identity_candidate");
  assert.equal(vehiclesDb.ruEvidencePresent, false);
  assert.equal(vehiclesDb.attributionRequired, true);
  assert.match(vehiclesDb.attributionText, /Vehicle data by VehiclesDB/);
  const mechanicDb = summary.packs.find((x) => x.id === "mechanicdb-vag-dtc-candidates-odbl");
  assert.deepEqual(mechanicDb.counts, { manufacturerCandidates: 2, audi: 1, volkswagen: 1 });
  assert.equal(mechanicDb.license, "ODbL-1.0");
  assert.equal(mechanicDb.marketScope, "UNKNOWN");
  assert.equal(mechanicDb.applicabilityPrecision, "manufacturer_make_candidate");
  assert.equal(mechanicDb.reviewStatus, "community_reference_unverified");
  assert.equal(mechanicDb.displayStatus, "hidden_pending_technical_review");
  assert.equal(mechanicDb.fitmentClaim, false);
  assert.equal(mechanicDb.executionAllowed, false);
  assert.equal(mechanicDb.shareAlikeRequired, true);
  assert.equal(mechanicDb.attributionRequired, true);
  assert.match(mechanicDb.sourceManifestSha256, /^[a-f0-9]{64}$/);
  assert.match(mechanicDb.databaseSha256, /^[a-f0-9]{64}$/);
  assert.match(mechanicDb.attributionText, /MechanicDB/);
});

test("generic DTC search preserves generic namespace and never returns a repair instruction", () => {
  const rows = local.searchGenericDtcs("P0300", 5, root);
  assert.ok(rows.length > 0);
  assert.equal(rows[0].code, "P0300");
  assert.equal(rows[0].namespace, "generic_sae_iso_obd2");
  assert.equal(rows[0].fitmentClaim, false);
  assert.equal(rows[0].reviewStatus, "research_only");
  assert.equal(rows[0].license, "CC0-1.0");
  assert.match(rows[0].sourceManifestSha256, /^[a-f0-9]{64}$/);
  assert.equal(rows[0].snapshotGeneratedAt, "2026-11-03T07:21:36.7901580Z");
  assert.match(rows[0].sourceRecordSha256, /^[a-f0-9]{64}$/);
  assert.equal(rows[0].upstreamRevision, "09c8aac3d7cb3477a8d9345dfff90b82457b64d1");
  assert.equal(Object.hasOwn(rows[0], "repair"), false);
  assert.equal(Object.hasOwn(rows[0], "estimatedCost"), false);
});

test("make-labelled MechanicDB DTC candidates never leak into the generic SAE/ISO search", () => {
  assert.deepEqual(local.searchGenericDtcs("P3000", 5, root), []);
  assert.deepEqual(local.searchGenericDtcs("P1128", 5, root), []);
  assert.equal(typeof local.searchMechanicDbDtcs, "undefined");
});

test("VAG identity search returns descriptive candidates, never factory codes or exact fitment", () => {
  const rows = local.searchVehicleCandidates("Golf", 5, root);
  assert.ok(rows.length > 0);
  for (const row of rows) {
    assert.equal(row.brand, "Volkswagen");
    assert.equal(row.marketScope, "UNKNOWN");
    assert.equal(row.reviewStatus, "candidate");
    assert.equal(row.engineCode, null);
    assert.equal(row.gearboxCode, null);
    assert.equal(row.exactFitment, false);
    assert.equal(row.sourceLicense, "ODbL-1.0");
    assert.match(row.sourceUrl, /^https:\/\//);
    assert.match(row.sourceSha256, /^[a-f0-9]{64}$/);
    assert.match(row.sourceManifestSha256, /^[a-f0-9]{64}$/);
  }
});

test("VehiclesDB model evidence is foreign-market-only, attributed, and never promoted to exact fitment", () => {
  const rows = local.searchVehiclesDbCandidates("Golf", 10, root);
  assert.ok(rows.some((row) => row.brand === "Volkswagen" && row.model === "Golf"));
  const golf = rows.find((row) => row.brand === "Volkswagen" && row.model === "Golf");
  assert.equal(golf.sourceLicense, "CC-BY-4.0");
  assert.equal(golf.sourceRevision, "v2026.10.3");
  assert.equal(golf.applicabilityPrecision, "make_model_name_only");
  assert.equal(golf.reviewStatus, "identity_candidate");
  assert.equal(golf.fitmentStatus, "not_established");
  assert.equal(golf.ruEvidencePresent, false);
  assert.equal(golf.exactFitment, false);
  assert.equal(golf.engineCode, null);
  assert.equal(golf.gearboxCode, null);
  assert.equal(golf.modelYearStart, null);
  assert.ok(golf.marketEvidence.length > 0);
  assert.ok(golf.marketEvidence.every((item) => item.evidenceScope === "market_presence_only" && item.countryCode !== "ru"));
  assert.match(golf.sourceSha256, /^[a-f0-9]{64}$/);
  assert.match(golf.sourceManifestSha256, /^[a-f0-9]{64}$/);
  assert.match(golf.upstreamManifestSha256, /^[a-f0-9]{64}$/);
  assert.match(golf.databaseSha256, /^[a-f0-9]{64}$/);
  assert.match(golf.attribution, /VehiclesDB/);
  assert.match(golf.warning, /нет данных RU/i);
});

test("generic PID search uses mode and record key without VAG attribution", () => {
  const rows = local.searchGenericPids("0C", 5, root);
  assert.ok(rows.some((row) => row.mode === "01" && row.pid === "0C"));
  assert.ok(rows.every((row) => row.license === "CC0-1.0" && row.reviewStatus === "research_only"));
});

test("community UDS signals remain unverified, model-level candidates and are never executable", () => {
  const rows = local.searchUdsSignals("18A0", 5, root);
  assert.ok(rows.length > 0);
  assert.equal(rows[0].make, "Audi");
  assert.equal(rows[0].model, "A4");
  assert.equal(rows[0].serviceId, "22");
  assert.equal(rows[0].did, "18A0");
  assert.equal(rows[0].sourceLicense, "CC-BY-SA-4.0");
  assert.equal(rows[0].marketScope, "UNKNOWN");
  assert.equal(rows[0].applicabilityPrecision, "vehicle_model_candidate");
  assert.equal(rows[0].reviewStatus, "unverified_community_candidate");
  assert.equal(rows[0].executionAllowed, false);
  assert.match(rows[0].sourceRevision, /^[a-f0-9]{40}$/);
  assert.match(rows[0].sourceSha256, /^[a-f0-9]{64}$/);
  assert.match(rows[0].sourceManifestSha256, /^[a-f0-9]{64}$/);
  assert.match(rows[0].databaseSha256, /^[a-f0-9]{64}$/);
  assert.equal(Object.hasOwn(rows[0], "repair"), false);
  assert.equal(Object.hasOwn(rows[0], "testPlan"), false);
  assert.match(rows[0].warning, /Do not execute/i);
  assert.ok(local.searchUdsSignals("Golf", 5, root).every((row) => row.make === "Volkswagen" && row.executionAllowed === false));
});

test("local research queries enforce bounded inputs and result limits", () => {
  assert.throws(() => local.searchGenericDtcs("P", 5, root), /at least 2 characters/);
  assert.throws(() => local.searchVehicleCandidates("x".repeat(101), 5, root), /too long/);
  assert.throws(() => local.searchUdsSignals("x", 5, root), /at least 2 characters/);
  assert.throws(() => local.searchVehiclesDbCandidates("x", 5, root), /at least 2 characters/);
  assert.equal(local.searchVehicleCandidates("Golf", 500, root).length, 50);
  assert.equal(local.searchVehiclesDbCandidates("Volkswagen", 500, root).length, 50);
  assert.equal(local.searchUdsSignals("Golf", 500, root).length, 50);
  assert.equal(local.clampLimit(0), 1);
  assert.equal(local.clampLimit(999), 50);
});

test("research database connections are query-only and cannot mutate the source pack", () => {
  const db = new DatabaseSync(path.join(root, "obdex-generic-cc0", "generic-obdex-research.sqlite"), { readOnly: true });
  db.exec("PRAGMA query_only=ON");
  assert.throws(() => db.exec("DELETE FROM generic_dtc_research WHERE code='P0300'"), /readonly|read-only|query only/i);
  db.close();
  const udsDb = new DatabaseSync(path.join(root, "obdb-vag-signals-cc-by-sa", "vag-obdb-research.sqlite"), { readOnly: true });
  udsDb.exec("PRAGMA query_only=ON");
  assert.throws(() => udsDb.exec("DELETE FROM command_candidates WHERE command_id=1"), /readonly|read-only|query only/i);
  udsDb.close();
  const vehiclesDb = new DatabaseSync(path.join(root, "vehiclesdb-vag-identity", "vag-identity-vehiclesdb.sqlite"), { readOnly: true });
  vehiclesDb.exec("PRAGMA query_only=ON");
  assert.throws(() => vehiclesDb.exec("DELETE FROM model_candidates WHERE model_candidate_id=1"), /readonly|read-only|query only/i);
  vehiclesDb.close();
});


test("research pack database SHA-256 is checked at runtime and tampering is rejected", () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), "vagtech-pack-hash-"));
  try {
    const dataFile = path.join(temp, "pack.bin");
    fs.writeFileSync(dataFile, "verified pack bytes");
    const expected = crypto.createHash("sha256").update(fs.readFileSync(dataFile)).digest("hex");
    fs.writeFileSync(path.join(temp, "manifest.json"), JSON.stringify({ schema_version: 1, packs: [{ id: "test-pack", database_sha256: expected }] }));
    assert.equal(local.verifyPackDatabaseHash(temp, "test-pack", "pack.bin").database_sha256, expected);
    fs.writeFileSync(dataFile, "tampered pack bytes");
    assert.throws(() => local.verifyPackDatabaseHash(temp, "test-pack", "pack.bin"), /SHA-256 mismatch/);
  } finally {
    fs.rmSync(temp, { recursive: true, force: true });
  }
});


test("research provenance files are SHA-256 checked before license and attribution are exposed", () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), "vagtech-provenance-hash-"));
  try {
    const license = path.join(temp, "LICENSE.txt");
    fs.writeFileSync(license, "CC BY 4.0 license notice");
    const expected = crypto.createHash("sha256").update(fs.readFileSync(license)).digest("hex");
    fs.writeFileSync(path.join(temp, "manifest.json"), JSON.stringify({
      schema_version: 1,
      packs: [{ id: "test-pack", license_file: "LICENSE.txt", license_file_sha256: expected }],
    }));
    assert.equal(local.verifyPackFileHash(temp, "test-pack", "license_file", "license_file_sha256").id, "test-pack");
    fs.writeFileSync(license, "changed license notice");
    assert.throws(() => local.verifyPackFileHash(temp, "test-pack", "license_file", "license_file_sha256"), /SHA-256 mismatch/);
  } finally {
    fs.rmSync(temp, { recursive: true, force: true });
  }
});
