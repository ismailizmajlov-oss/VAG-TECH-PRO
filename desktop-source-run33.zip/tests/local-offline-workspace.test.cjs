"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const root = path.resolve(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("local API is bound to a configured desktop database and loopback host", () => {
  const route = read("app/api/local-core/route.ts");
  assert.match(route, /VAG_TECH_PRO_DB_PATH/);
  assert.match(route, /127\.0\.0\.1/);
  assert.match(route, /localhost/);
  assert.match(route, /isSameOriginMutation/);
  assert.match(route, /Cross-origin local database mutation is blocked/);
  assert.match(route, /256 \* 1024/);
  assert.match(route, /Cache-Control.*no-store/);
});

test("offline workspace supports manual vehicle selection without requiring or storing VIN", () => {
  const ui = read("components/local-offline-workspace.tsx");
  assert.match(ui, /brand_name/);
  assert.match(ui, /model_name/);
  assert.match(ui, /engine_code_declared/);
  assert.match(ui, /transmission_code_declared/);
  assert.match(ui, /pr_codes/);
  assert.match(ui, /VIN не обязателен и не сохраняется/);
  assert.match(ui, /Ручной выбор · не подтверждено/);
  assert.doesNotMatch(ui, /name="vin"|value=\{vin\}/i);
});

test("offline modules request only their own typed technical records", () => {
  const ui = read("components/local-offline-workspace.tsx");
  for (const type of ["repair_procedure","torque_specification","service_interval","oem_part","oem_supersession","wiring_diagram","pinout","ecu_reference","dtc_vag_specific","diagnostic_test_plan","adaptation"]) {
    assert.ok(ui.includes(`"${type}"`), `missing module record type ${type}`);
  }
  assert.match(ui, /exact_configuration_verified/);
  assert.match(ui, /точной конфигурации/);
  assert.match(ui, /Кандидаты.*не подставляются/);
});

test("offline page branch does not require a Supabase session to open the local workspace", () => {
  const page = read("app/page.tsx");
  assert.match(page, /!supabase \|\| \(!catalogOnline && !cloudLoading\)/);
  assert.match(page, /<LocalOfflineWorkspace/);
  assert.match(page, /setView\("workspace"\)/);
});
