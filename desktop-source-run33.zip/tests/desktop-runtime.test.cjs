"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const { reserveLoopbackPort, resolveRuntimeDirectory, probeHttp, waitForServer } = require("../electron/main.cjs");

test("packaged runtime resolves outside app.asar", () => {
  assert.equal(resolveRuntimeDirectory({ isPackaged: true, resourcesPath: "C:/Program Files/VAG/resources", appPath: "ignored" }), path.join("C:/Program Files/VAG/resources", "app-runtime"));
});
test("development runtime resolves to Next standalone output", () => {
  assert.equal(resolveRuntimeDirectory({ isPackaged: false, resourcesPath: "ignored", appPath: "/repo/vag_next" }), path.resolve("/repo/vag_next", ".next", "standalone"));
});
test("port reservation returns an available loopback port", async () => {
  const port = await reserveLoopbackPort();
  assert.ok(Number.isInteger(port) && port > 0 && port <= 65535);
});
test("health probe rejects an unused local port", async () => {
  assert.equal(await probeHttp("http://127.0.0.1:1", 200), false);
});


test("package configuration pins the Windows x64 NSIS toolchain and hardens Electron", () => {
  const pkg = require("../package.json");
  assert.equal(pkg.main, "electron/main.cjs");
  assert.equal(pkg.devDependencies.electron, "45.2.1");
  assert.equal(pkg.devDependencies["electron-builder"], "26.18.0");
  assert.equal(pkg.build.win.target[0].target, "nsis");
  assert.deepEqual(pkg.build.win.target[0].arch, ["x64"]);
  assert.equal(pkg.build.nsis.deleteAppDataOnUninstall, false);
  const researchResource = pkg.build.extraResources.find((resource) => resource.to === "research-data");
  assert.equal(researchResource?.from, "data/research");
  assert.equal(pkg.build.electronFuses.runAsNode, false);
  assert.equal(pkg.build.electronFuses.enableEmbeddedAsarIntegrityValidation, true);
});

test("desktop runner uses UtilityProcess and does not expose Node integration to renderer", () => {
  const fs = require("node:fs");
  const source = fs.readFileSync(path.join(__dirname, "../electron/main.cjs"), "utf8");
  assert.match(source, /utilityProcess\.fork/);
  assert.match(source, /contextIsolation:\s*true/);
  assert.match(source, /nodeIntegration:\s*false/);
  assert.match(source, /sandbox:\s*true/);
  assert.doesNotMatch(source, /ELECTRON_RUN_AS_NODE/);
  assert.match(source, /VAG_TECH_PRO_DB_PATH/);
  assert.match(source, /VAG_TECH_PRO_RESEARCH_DIR/);
  assert.match(source, /path\.join\(process\.resourcesPath, "research-data"\)/);
});

test("server readiness fails immediately when the utility process exits", async () => {
  await assert.rejects(
    waitForServer("http://127.0.0.1:1", {}, 1000, () => false),
    /exited before becoming ready/
  );
});
