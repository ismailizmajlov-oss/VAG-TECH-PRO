"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const read = (name) => fs.readFileSync(path.join(root, name), "utf8");

test("offline desktop exposes a dedicated local source/import administration view", () => {
  const page = read("app/page.tsx");
  const component = read("components/local-data-admin.tsx");
  assert.match(page, /LocalDataAdmin/);
  assert.match(page, /local-admin/);
  assert.match(component, /Реестр источников/);
  assert.match(component, /Журнал импорта и версии/);
  assert.match(component, /Добавить источник-кандидат/);
  assert.match(component, /не позволяет самостоятельно объявить источник лицензированным/);
});

test("local admin import and restore actions are file-backed and same-origin protected", () => {
  const route = read("app/api/local-core/route.ts");
  const component = read("components/local-data-admin.tsx");
  assert.match(route, /isSameOriginMutation\(request\)/);
  assert.match(route, /multipart\/form-data/);
  assert.match(route, /localCore\.importPackage\(dbPath, inputPackage\)/);
  assert.match(route, /source\.register-candidate/);
  assert.match(route, /localCore\.registerSourceCandidate/);
  assert.match(route, /localCore\.restoreDatabase\(dbPath, temporary\)/);
  assert.match(route, /localCore\.backupDatabase\(dbPath, backupPath\)/);
  assert.match(route, /256 \* 1024 \* 1024/);
  assert.match(component, /package\.import/);
  assert.match(component, /backup\.restore/);
  assert.match(component, /backup\.create/);
});

test("local admin reports only registered source rights and import provenance", () => {
  const core = read("lib/local-core-db.cjs");
  const route = read("app/api/local-core/route.ts");
  assert.match(core, /function listSources\(/);
  assert.match(core, /function listImportBatches\(/);
  assert.match(core, /listSources,listImportBatches/);
  assert.match(route, /action === "admin-summary"/);
  assert.match(route, /sources: localCore\.listSources\(dbPath\)/);
  assert.match(route, /importBatches: localCore\.listImportBatches\(dbPath, 50\)/);
});
