"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const Module = require("node:module");
const { execFileSync } = require("node:child_process");
const core = require("../lib/local-core-db.cjs");

function loadTypescript() {
  try { return require("typescript"); }
  catch {
    try {
      const globalRoot = execFileSync("npm", ["root", "-g"], { encoding: "utf8" }).trim();
      return require(path.join(globalRoot, "typescript"));
    } catch { return null; }
  }
}
const ts = loadTypescript();

test("local-core API enforces source rights and safely imports, backs up and restores SQLite", { skip: !ts && "TypeScript is unavailable; install the pinned dev dependencies to run route integration" }, async (t) => {
  assert.equal(typeof Request, "function");
  assert.equal(typeof File, "function");
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "vag-local-core-api-"));
  const dbPath = path.join(root, "data", "vag-tech-pro.sqlite");
  const previousDbPath = process.env.VAG_TECH_PRO_DB_PATH;
  t.after(() => {
    if (previousDbPath === undefined) delete process.env.VAG_TECH_PRO_DB_PATH;
    else process.env.VAG_TECH_PRO_DB_PATH = previousDbPath;
    fs.rmSync(root, { recursive: true, force: true });
  });
  core.initializeDatabase(dbPath);
  core.saveUserVehicle(dbPath, { brand_name: "Audi", model_name: "A4", nickname: "Before backup", is_default: true });
  process.env.VAG_TECH_PRO_DB_PATH = dbPath;

  const routePath = path.resolve(__dirname, "../app/api/local-core/route.ts");
  const routeSource = fs.readFileSync(routePath, "utf8");
  const compiled = ts.transpileModule(routeSource, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true },
    fileName: routePath,
  }).outputText;
  const routeModule = new Module(routePath, module);
  routeModule.filename = routePath;
  routeModule.paths = Module._nodeModulePaths(path.dirname(routePath));
  routeModule._compile(compiled, routePath);
  const { GET, POST } = routeModule.exports;
  const baseUrl = "http://127.0.0.1:43123/api/local-core";
  const headers = { host: "127.0.0.1:43123", origin: "http://127.0.0.1:43123" };

  const admin = await GET(new Request(`${baseUrl}?action=admin-summary`, { headers: { host: headers.host } }));
  assert.equal(admin.status, 200);
  assert.equal((await admin.json()).sources.length, 0);

  const candidateResponse = await POST(new Request(baseUrl, {
    method: "POST", headers: { ...headers, "content-type": "application/json" },
    body: JSON.stringify({ action: "source.register-candidate", source: {
      source_id: "fgis-otts-candidate", publisher: "Rosstandart", title: "FGIS OTTS discovery", source_type: "public_registry",
      source_url: "https://example.gov.ru/otts", revision: "2026-11-03", market_scope: "RU/EAEU", license_id: "not_confirmed",
      license_url: "https://example.gov.ru/terms",
    } }),
  }));
  assert.equal(candidateResponse.status, 201);
  const candidate = await candidateResponse.json();
  assert.equal(candidate.source.status, "candidate");
  assert.equal(candidate.source.rights_status, "permission_required");
  const candidateRow = core.listSources(dbPath)[0];
  for (const field of ["commercial_use_allowed", "display_allowed", "offline_cache_allowed", "bulk_reuse_allowed", "redistribution_allowed"]) assert.equal(candidateRow[field], 0);

  const crossOrigin = await POST(new Request(baseUrl, {
    method: "POST", headers: { host: headers.host, origin: "http://evil.example", "content-type": "application/json" },
    body: JSON.stringify({ action: "source.register-candidate", source: { source_id: "cross-origin", publisher: "Test", title: "Test", source_type: "test", revision: "r1", market_scope: "ALL" } }),
  }));
  assert.equal(crossOrigin.status, 404);
  assert.equal(core.listSources(dbPath).length, 1);

  const approvedSource = {
    source_id: "api-test-source", publisher: "API test", title: "API test CC0", source_type: "test", source_url: "https://example.invalid/source",
    revision: "r1", license_id: "CC0-1.0", license_url: "https://creativecommons.org/publicdomain/zero/1.0/", license_sha256: "a".repeat(64),
    rights_status: "approved_by_published_license", commercial_use_allowed: true, display_allowed: true, offline_cache_allowed: true,
    bulk_reuse_allowed: true, redistribution_allowed: true, share_alike_required: false, attribution_required: false,
    attribution_text: "CC0", market_scope: "ALL", source_snapshot_sha256: "b".repeat(64), rights_evidence_sha256: "c".repeat(64),
  };
  core.registerSource(dbPath, approvedSource);
  const payload = { code: "P0300", title: "Generic misfire" };
  const record = {
    record_type: "dtc_generic", namespace: "generic_sae_iso_obd2", natural_key: "generic:P0300", title: "P0300 generic",
    market_scope: "ALL", applicability_precision: "generic_standard", payload, record_sha256: core.sha256(payload), source_record_key: "obd:P0300",
  };
  const pack = {
    package_id: "api-package", source_id: approvedSource.source_id, source_revision: "r1", market_scope: "ALL",
    source_snapshot_sha256: approvedSource.source_snapshot_sha256, license_sha256: approvedSource.license_sha256,
    rights_evidence_sha256: approvedSource.rights_evidence_sha256, snapshot_manifest: { upstream_revision: "r1", record_count: 1 }, records: [record],
  };
  pack.package_sha256 = core.sha256({
    package_id: pack.package_id, source_id: pack.source_id, source_revision: pack.source_revision, market_scope: pack.market_scope,
    source_snapshot_sha256: pack.source_snapshot_sha256, license_sha256: pack.license_sha256, rights_evidence_sha256: pack.rights_evidence_sha256,
    snapshot_manifest: pack.snapshot_manifest, records: pack.records,
  });
  const packageForm = new FormData();
  packageForm.append("action", "package.import");
  packageForm.append("file", new File([JSON.stringify(pack)], "package.json", { type: "application/json" }));
  const importedResponse = await POST(new Request(baseUrl, { method: "POST", headers, body: packageForm }));
  assert.equal(importedResponse.status, 201);
  assert.equal((await importedResponse.json()).import.inserted, 1);

  const backupResponse = await POST(new Request(baseUrl, {
    method: "POST", headers: { ...headers, "content-type": "application/json" }, body: JSON.stringify({ action: "backup.create" }),
  }));
  assert.equal(backupResponse.status, 200);
  const backupBytes = Buffer.from(await backupResponse.arrayBuffer());
  assert.ok(backupBytes.length > 100);
  assert.match(backupResponse.headers.get("x-backup-sha256"), /^[a-f0-9]{64}$/);
  core.saveUserVehicle(dbPath, { brand_name: "Volkswagen", model_name: "Golf", nickname: "After backup" });

  const restoreForm = new FormData();
  restoreForm.append("action", "backup.restore");
  restoreForm.append("file", new File([backupBytes], "backup.sqlite", { type: "application/vnd.sqlite3" }));
  const restoreResponse = await POST(new Request(baseUrl, { method: "POST", headers, body: restoreForm }));
  assert.equal(restoreResponse.status, 200);
  const restoreResult = await restoreResponse.json();
  assert.ok(restoreResult.restore.safetyBackup);
  assert.ok(fs.existsSync(restoreResult.restore.safetyBackup));
  assert.deepEqual(core.listUserVehicles(dbPath).map((row) => row.nickname), ["Before backup"]);

  const corruptForm = new FormData();
  corruptForm.append("action", "backup.restore");
  corruptForm.append("file", new File([Buffer.alloc(512, 0x41)], "corrupt.sqlite", { type: "application/vnd.sqlite3" }));
  const corruptResponse = await POST(new Request(baseUrl, { method: "POST", headers, body: corruptForm }));
  assert.equal(corruptResponse.status, 400);
  assert.deepEqual(core.listUserVehicles(dbPath).map((row) => row.nickname), ["Before backup"]);

  const finalAdmin = await GET(new Request(`${baseUrl}?action=admin-summary`, { headers: { host: headers.host } }));
  const finalSummary = await finalAdmin.json();
  assert.equal(finalSummary.sources.length, 2);
  assert.equal(finalSummary.importBatches.length, 1);
  assert.equal(finalSummary.importBatches[0].records_inserted, 1);
});
