"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");
const core = require("../lib/local-core-db.cjs");

function fixture(t) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "vag-tech-pro-local-core-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const dbPath = path.join(dir, "data", "vag-tech-pro.sqlite");
  core.initializeDatabase(dbPath);
  return { dir, dbPath };
}
function source(overrides = {}) {
  return {
    source_id: "test-open-source", publisher: "Test publisher", title: "Test source", source_type: "test_dataset",
    source_url: "https://example.invalid/source", revision: "rev1", license_id: "CC0-1.0", license_url: "https://creativecommons.org/publicdomain/zero/1.0/",
    license_sha256: "a".repeat(64), rights_status: "approved_by_published_license", commercial_use_allowed: true, display_allowed: true,
    offline_cache_allowed: true, bulk_reuse_allowed: true, redistribution_allowed: true, share_alike_required: false, attribution_required: false,
    attribution_text: "Public domain", market_scope: "ALL", source_snapshot_sha256: "b".repeat(64), rights_evidence_sha256: "c".repeat(64), ...overrides
  };
}
function packageOf(records, overrides = {}) {
  const pkg = { package_id: "test-package", source_id: "test-open-source", source_revision: "rev1", market_scope: "ALL", source_snapshot_sha256: "b".repeat(64),
    license_sha256: "a".repeat(64), rights_evidence_sha256: "c".repeat(64), snapshot_manifest: { upstream_revision: "rev1", record_count: records.length }, records, ...overrides };
  pkg.package_sha256 = core.sha256({ package_id: pkg.package_id, source_id: pkg.source_id, source_revision: pkg.source_revision, market_scope: pkg.market_scope,
    source_snapshot_sha256: pkg.source_snapshot_sha256, license_sha256: pkg.license_sha256, rights_evidence_sha256: pkg.rights_evidence_sha256, snapshot_manifest: pkg.snapshot_manifest, records: pkg.records });
  return pkg;
}
function genericDtc(overrides = {}) {
  const payload = { code: "P0300", title: "Random/multiple cylinder misfire", namespace: "SAE/ISO" };
  return { record_type: "dtc_generic", namespace: "generic_sae_iso_obd2", natural_key: "generic:P0300", title: "P0300 — Random/multiple cylinder misfire",
    market_scope: "ALL", applicability_precision: "generic_standard", payload, record_sha256: core.sha256(payload), source_record_key: "obd:P0300", ...overrides };
}
function seedSourceSnapshot(db, sourceId = "test-open-source", rightsStatus = "approved_by_published_license") {
  const allowed = rightsStatus.startsWith("approved_by_");
  db.prepare(`INSERT INTO source_snapshots(source_id,revision,retrieved_at,market_scope,snapshot_sha256,license_id,license_url,license_sha256,rights_evidence_sha256,rights_status,
    commercial_use_allowed,display_allowed,offline_cache_allowed,bulk_reuse_allowed,redistribution_allowed,share_alike_required,attribution_required,attribution_text,manifest_json)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(sourceId,"rev1",new Date().toISOString(),"ALL","b".repeat(64),"CC0-1.0","https://creativecommons.org/publicdomain/zero/1.0/",
    "a".repeat(64),"c".repeat(64),rightsStatus,allowed?1:0,allowed?1:0,allowed?1:0,allowed?1:0,allowed?1:0,0,allowed?0:1,allowed?"Public domain":null,"{}");
}
function seedExactConfiguration(dbPath, sourceId = "test-open-source") {
  const db = new DatabaseSync(dbPath);
  db.exec("PRAGMA foreign_keys=ON");
  const now = new Date().toISOString();
  seedSourceSnapshot(db,sourceId);
  db.prepare("INSERT INTO brands(brand_key,display_name,group_name,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,review_status) VALUES('vw','Volkswagen','VAG',?,'rev1',?,'brand:vw',?,'verified')").run(sourceId,"b".repeat(64),"d".repeat(64));
  const brandId = Number(db.prepare("SELECT id FROM brands WHERE brand_key='vw'").get().id);
  db.prepare("INSERT INTO vehicle_models(brand_id,model_key,display_name,market_scope,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,applicability_precision,review_status) VALUES(?, 'golf','Golf','RU',?,'rev1',?,'model:golf',?,'exact_model','verified')").run(brandId,sourceId,"b".repeat(64),"e".repeat(64));
  const modelId = Number(db.prepare("SELECT id FROM vehicle_models WHERE model_key='golf'").get().id);
  db.prepare("INSERT INTO vehicle_generations(model_id,generation_key,display_name,platform_code,model_year_start,model_year_end,market_scope,applicability_precision,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,review_status) VALUES(?, 'mk7','Golf VII','MQB',2013,2020,'RU','exact_generation',?,'rev1',?,'generation:golf7',?,'verified')").run(modelId,sourceId,"b".repeat(64),"f".repeat(64));
  const genId = Number(db.prepare("SELECT id FROM vehicle_generations WHERE generation_key='mk7'").get().id);
  db.prepare("INSERT INTO engines(engine_code,engine_family,fuel_type,displacement_cc,market_scope,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,applicability_precision,review_status) VALUES('CZEA','EA211','petrol',1395,'RU',?,'rev1',?,'engine:czea',?,'exact_engine','verified')").run(sourceId,"b".repeat(64),"1".repeat(64));
  const engineId = Number(db.prepare("SELECT id FROM engines WHERE engine_code='CZEA'").get().id);
  db.prepare("INSERT INTO transmissions(transmission_code,transmission_type,gears,drive_type,market_scope,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,applicability_precision,review_status) VALUES('DQ200','DSG',7,'FWD','RU',?,'rev1',?,'transmission:dq200',?,'exact_transmission','verified')").run(sourceId,"b".repeat(64),"2".repeat(64));
  const transmissionId = Number(db.prepare("SELECT id FROM transmissions WHERE transmission_code='DQ200'").get().id);
  db.prepare("INSERT INTO ecu_units(manufacturer,ecu_family,hardware_number,software_number,ecu_address,market_scope,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,applicability_precision,review_status) VALUES('Bosch','MED17.5.25','06K907425','0001','01','RU',?,'rev1',?,'ecu:med17',?,'exact_ecu','verified')").run(sourceId,"b".repeat(64),"3".repeat(64));
  const ecuId = Number(db.prepare("SELECT id FROM ecu_units WHERE ecu_family='MED17.5.25'").get().id);
  db.prepare("INSERT INTO vehicle_configurations(generation_id,engine_id,transmission_id,ecu_id,market_scope,model_year,pr_codes_json,applicability_precision,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,review_status) VALUES(?,?,?,?,'RU',2017,'[\"1AT\"]','exact_configuration',?,'rev1',?,'configuration:golf7-czea-dq200',?,'verified')").run(genId,engineId,transmissionId,ecuId,sourceId,"b".repeat(64),"4".repeat(64));
  const configId = Number(db.prepare("SELECT id FROM vehicle_configurations WHERE source_record_key='configuration:golf7-czea-dq200'").get().id);
  db.close();
  return { configId, ecuId };
}

test("initializes a versioned local SQLite user database and is idempotent", (t) => {
  const { dbPath } = fixture(t);
  const first = core.initializeDatabase(dbPath);
  const second = core.initializeDatabase(dbPath);
  assert.equal(first.created, false); // fixture initialized it once
  assert.equal(second.created, false);
  assert.equal(second.schemaVersion, 1);
  assert.equal(second.integrity, "ok");
  assert.equal(second.foreignKeyViolations, 0);
});

test("versioned SQL migration file is byte-identical to the runtime migration checksum", (t) => {
  const { dbPath } = fixture(t);
  const migrationFile = path.resolve(__dirname, "../data/sql/local-core-v1.sql");
  assert.equal(core.sha256(fs.readFileSync(migrationFile)), core.sha256(core.MIGRATION_1));
  const db = new DatabaseSync(dbPath);
  assert.equal(db.prepare("SELECT checksum FROM schema_migrations WHERE version=1").get().checksum, core.sha256(fs.readFileSync(migrationFile)));
  db.close();
});

test("refuses to reinterpret the old OTTS research staging database as user data", (t) => {
  const { dir } = fixture(t);
  const stagingPath = path.join(dir, "legacy-staging.sqlite");
  const db = new DatabaseSync(stagingPath);
  db.exec("CREATE TABLE vehicles(id INTEGER PRIMARY KEY, brand TEXT); CREATE TABLE research_records(id INTEGER PRIMARY KEY, payload_json TEXT);");
  db.close();
  assert.throws(() => core.initializeDatabase(stagingPath), /Unrecognized legacy\/staging SQLite file/);
});

test("requires explicit commercial, display, cache, bulk and redistribution rights before approving a source", (t) => {
  const { dbPath } = fixture(t);
  assert.throws(() => core.registerSource(dbPath, source({ offline_cache_allowed: false })), /explicitly grant/);
  assert.throws(() => core.registerSource(dbPath, source({ license_sha256: null })), /license identity/);
  const pending = core.registerSource(dbPath, source({ rights_status: "permission_required", commercial_use_allowed: false, display_allowed: false, offline_cache_allowed: false, bulk_reuse_allowed: false, redistribution_allowed: false }));
  assert.equal(pending.status, "candidate");
});

test("local source administration can register permission-required candidates but cannot approve or overwrite sources", (t) => {
  const { dbPath } = fixture(t);
  const candidate = core.registerSourceCandidate(dbPath, {
    source_id: "fgis-otts-candidate", publisher: "Rosstandart", title: "FGIS vehicle type approvals", source_type: "government_registry",
    source_url: "https://example.gov.ru/otts", revision: "discovery-2026-11-03", market_scope: "RU/EAEU",
    license_id: "not_confirmed", license_url: "https://example.gov.ru/terms", attribution_text: "Rights review pending",
  });
  assert.equal(candidate.status, "candidate");
  assert.equal(candidate.rights_status, "permission_required");
  const sourceRow = core.listSources(dbPath)[0];
  assert.equal(sourceRow.commercial_use_allowed, 0);
  assert.equal(sourceRow.display_allowed, 0);
  assert.equal(sourceRow.offline_cache_allowed, 0);
  assert.equal(sourceRow.bulk_reuse_allowed, 0);
  assert.equal(sourceRow.redistribution_allowed, 0);
  assert.throws(() => core.registerSourceCandidate(dbPath, { source_id: "fgis-otts-candidate", publisher: "Changed", title: "Changed", source_type: "test", revision: "r2", market_scope: "RU" }), /never overwritten/);
  assert.throws(() => core.registerSourceCandidate(dbPath, { source_id: "unsafe-source", publisher: "Test", title: "Test", source_type: "test", revision: "r1", market_scope: "ALL", commercial_use_allowed: true }), /only register permission-required candidates/);
  assert.throws(() => core.registerSourceCandidate(dbPath, { source_id: "unsafe-url", publisher: "Test", title: "Test", source_type: "test", revision: "r1", market_scope: "ALL", source_url: "http://example.invalid" }), /HTTPS URL/);
  assert.equal(core.listSources(dbPath)[0].publisher, "Rosstandart");
});

test("requires package snapshot, license and rights-evidence hashes to match the approved registry", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const pkg = packageOf([genericDtc()], { license_sha256: "9".repeat(64) });
  pkg.package_sha256 = core.sha256({ package_id: pkg.package_id, source_id: pkg.source_id, source_revision: pkg.source_revision, market_scope: pkg.market_scope,
    source_snapshot_sha256: pkg.source_snapshot_sha256, license_sha256: pkg.license_sha256, rights_evidence_sha256: pkg.rights_evidence_sha256, snapshot_manifest: pkg.snapshot_manifest, records: pkg.records });
  assert.throws(() => core.importPackage(dbPath, pkg), /hashes do not match the approved source registry/);
});

test("rejects an import from a permission-required source", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source({ rights_status: "permission_required", commercial_use_allowed: false, display_allowed: false, offline_cache_allowed: false, bulk_reuse_allowed: false, redistribution_allowed: false }));
  assert.throws(() => core.importPackage(dbPath, packageOf([genericDtc()])), /rights do not explicitly permit/);
});

test("rejects a package with a bad canonical SHA-256 before writing anything", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const pkg = packageOf([genericDtc()]);
  pkg.package_sha256 = "0".repeat(64);
  assert.throws(() => core.importPackage(dbPath, pkg), /Package SHA-256 does not match/);
  const db = new DatabaseSync(dbPath);
  assert.equal(db.prepare("SELECT count(*) AS n FROM import_batches").get().n, 0);
  assert.equal(db.prepare("SELECT count(*) AS n FROM technical_records").get().n, 0);
  db.close();
});

test("keeps generic SAE/ISO DTCs in a separate namespace with no vehicle or ECU fitment", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const result = core.importPackage(dbPath, packageOf([genericDtc()]));
  assert.equal(result.inserted, 1);
  assert.equal(core.searchVerifiedTechnicalRecords(dbPath, { record_type: "dtc_generic", query: "P0300" }).length, 0);
  const db = new DatabaseSync(dbPath);
  const row = db.prepare("SELECT namespace,configuration_id,ecu_id,review_status FROM technical_records").get();
  assert.equal(row.namespace, "generic_sae_iso_obd2");
  assert.equal(row.configuration_id, null);
  assert.equal(row.ecu_id, null);
  assert.equal(row.review_status, "candidate");
  db.close();
});

test("rejects a generic DTC record that tries to claim VAG or ECU applicability", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const bad = genericDtc({ namespace: "vag_oem_specific", applicability_precision: "exact_configuration", configuration_id: 1, ecu_id: 1 });
  const pkg = packageOf([bad]);
  assert.throws(() => core.importPackage(dbPath, pkg), /Generic SAE\/ISO DTC records must remain generic/);
});

test("rejects a VAG-specific DTC unless exact configuration and ECU links are present", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const payload = { code: "P1A00", description: "Manufacturer-controlled candidate" };
  const bad = { record_type: "dtc_vag_specific", namespace: "vag_oem_specific", natural_key: "vag:P1A00", title: "P1A00", market_scope: "ALL",
    applicability_precision: "manufacturer_make_candidate", payload, record_sha256: core.sha256(payload), source_record_key: "vag:P1A00" };
  assert.throws(() => core.importPackage(dbPath, packageOf([bad])), /VAG-specific DTC records require an exact configuration and ECU/);
});

test("external packages cannot self-approve critical repair or diagnostic records", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const payload = { torque_nm: 90, angle_deg: 90 };
  const record = { record_type: "torque_specification", natural_key: "test:torque", title: "Test torque", market_scope: "ALL",
    applicability_precision: "exact_configuration", configuration_id: 1, source_record_key: "torque:1", review_status: "verified", payload, record_sha256: core.sha256(payload) };
  assert.throws(() => core.importPackage(dbPath, packageOf([record])), /cannot self-approve/);
});

test("imports a valid package atomically and is idempotent for the same package hash", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  core.saveUserVehicle(dbPath,{brand_name:"Audi",model_name:"A4",nickname:"Customer vehicle"});
  const pkg = packageOf([genericDtc()]);
  const first = core.importPackage(dbPath, pkg);
  const second = core.importPackage(dbPath, pkg);
  assert.equal(first.status, "applied");
  assert.equal(first.inserted, 1);
  assert.equal(second.status, "already_applied");
  assert.equal(second.inserted, 0);
  const db = new DatabaseSync(dbPath);
  assert.equal(db.prepare("SELECT count(*) AS n FROM technical_records").get().n, 1);
  assert.equal(db.prepare("SELECT count(*) AS n FROM import_batches").get().n, 1);
  assert.equal(db.prepare("SELECT count(*) AS n FROM local_user_vehicles WHERE nickname='Customer vehicle'").get().n, 1);
  db.close();
});

test("rolls back the whole package when a source record key collides with changed content", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const one = genericDtc();
  const changedPayload = { code: "P0300", title: "Changed meaning" };
  const two = genericDtc({ natural_key: "generic:P0300-changed", title: "Changed", payload: changedPayload, record_sha256: core.sha256(changedPayload) });
  assert.throws(() => core.importPackage(dbPath, packageOf([one,two])), /collision with changed content/);
  const db = new DatabaseSync(dbPath);
  assert.equal(db.prepare("SELECT count(*) AS n FROM technical_records").get().n, 0);
  assert.equal(db.prepare("SELECT count(*) AS n FROM import_batches").get().n, 0);
  db.close();
});

test("preserves imported record revisions instead of overwriting prior source revisions", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  core.importPackage(dbPath, packageOf([genericDtc()]));
  core.registerSource(dbPath, source({ revision: "rev2" }));
  const revisedPayload = { code: "P0300", title: "Updated upstream text" };
  const revised = genericDtc({ title: "P0300 — Updated", payload: revisedPayload, record_sha256: core.sha256(revisedPayload) });
  const result = core.importPackage(dbPath, packageOf([revised], { package_id: "test-package-rev2", source_revision: "rev2" }));
  assert.equal(result.inserted, 1);
  const db = new DatabaseSync(dbPath);
  const versions = db.prepare("SELECT source_revision,review_status,supersedes_id FROM technical_records ORDER BY id").all();
  assert.deepEqual(versions.map((x)=>x.source_revision), ["rev1","rev2"]);
  assert.equal(versions[0].review_status, "superseded");
  assert.equal(versions[1].supersedes_id, 1);
  db.close();
});

test("blocks a configuration from being marked verified without exact engine, transmission, market and year", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const db = new DatabaseSync(dbPath);
  db.exec("PRAGMA foreign_keys=ON");
  seedSourceSnapshot(db);
  db.prepare("INSERT INTO brands(brand_key,display_name,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,review_status) VALUES('vw','Volkswagen','test-open-source','rev1',?,'brand:vw',?,'candidate')").run("b".repeat(64),"d".repeat(64));
  const brandId = Number(db.prepare("SELECT id FROM brands WHERE brand_key='vw'").get().id);
  db.prepare("INSERT INTO vehicle_models(brand_id,model_key,display_name,market_scope,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,applicability_precision,review_status) VALUES(?, 'golf','Golf','RU','test-open-source','rev1',?,'model:golf',?,'exact_model','candidate')").run(brandId,"b".repeat(64),"e".repeat(64));
  const modelId = Number(db.prepare("SELECT id FROM vehicle_models WHERE model_key='golf'").get().id);
  db.prepare("INSERT INTO vehicle_generations(model_id,generation_key,display_name,market_scope,applicability_precision,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,review_status) VALUES(?, 'mk7','Golf VII','UNKNOWN','generation_candidate','test-open-source','rev1',?,'generation:mk7',?,'candidate')").run(modelId,"b".repeat(64),"f".repeat(64));
  const generationId = Number(db.prepare("SELECT id FROM vehicle_generations WHERE generation_key='mk7'").get().id);
  db.prepare("INSERT INTO vehicle_configurations(generation_id,market_scope,pr_codes_json,applicability_precision,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,review_status) VALUES(?,'UNKNOWN','[]','generation_candidate','test-open-source','rev1',?,'config:candidate',?,'candidate')").run(generationId,"b".repeat(64),"1".repeat(64));
  const configId = Number(db.prepare("SELECT id FROM vehicle_configurations WHERE source_record_key='config:candidate'").get().id);
  assert.throws(()=>db.prepare("UPDATE vehicle_configurations SET review_status='verified' WHERE id=?").run(configId),/exact engine, transmission, market and production scope/);
  db.close();
});

test("only links a manual garage entry to a rights-cleared exact engine/transmission configuration for the same model", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const { configId } = seedExactConfiguration(dbPath);
  const configs = core.listVerifiedConfigurations(dbPath, "RU");
  assert.equal(configs.length, 1);
  assert.equal(configs[0].engine_code, "CZEA");
  assert.equal(configs[0].transmission_code, "DQ200");
  const vehicle = core.saveUserVehicle(dbPath,{brand_name:"Volkswagen",model_name:"Golf",nickname:"My Golf"});
  const linked = core.linkUserVehicleConfiguration(dbPath,vehicle.id,configId);
  assert.equal(linked.identity_status,"exact_configuration_verified");
  assert.equal(linked.engine_code_declared,"CZEA");
  assert.equal(linked.transmission_code_declared,"DQ200");
  const wrong = core.saveUserVehicle(dbPath,{brand_name:"Audi",model_name:"A4",nickname:"Other car"});
  assert.throws(()=>core.linkUserVehicleConfiguration(dbPath,wrong.id,configId),/does not match/);
});

test("removes a previously linked configuration from active identity when its source rights are revoked", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const { configId } = seedExactConfiguration(dbPath);
  const vehicle = core.saveUserVehicle(dbPath,{brand_name:"Volkswagen",model_name:"Golf",nickname:"Rights test"});
  core.linkUserVehicleConfiguration(dbPath,vehicle.id,configId);
  assert.equal(core.listUserVehicles(dbPath)[0].identity_status,"exact_configuration_verified");
  core.registerSource(dbPath, source({ rights_status:"restricted", commercial_use_allowed:false, display_allowed:false, offline_cache_allowed:false, bulk_reuse_allowed:false, redistribution_allowed:false }));
  assert.equal(core.listVerifiedConfigurations(dbPath).length,0);
  assert.equal(core.listUserVehicles(dbPath)[0].identity_status,"configuration_no_longer_eligible");
  assert.throws(()=>core.linkUserVehicleConfiguration(dbPath,vehicle.id,configId),/rights-cleared/);
});

test("saves a manually selected vehicle without requiring or storing a VIN", (t) => {
  const { dbPath } = fixture(t);
  const vehicle = core.saveUserVehicle(dbPath, { brand_name: "Volkswagen", model_name: "Golf", generation_name: "VII", market_scope: "RU", model_year: 2017,
    engine_code_declared: "CZEA", transmission_code_declared: "DQ200", pr_codes: ["1AT","1AT"], is_default: true });
  assert.equal(vehicle.identity_status, "user_declared_unverified");
  assert.equal(vehicle.configuration_id, null);
  assert.equal(Object.hasOwn(vehicle, "vin"), false);
  assert.deepEqual(core.listUserVehicles(dbPath)[0].pr_codes, ["1AT"]);
});

test("enforces a single default local vehicle without deleting other vehicles", (t) => {
  const { dbPath } = fixture(t);
  core.saveUserVehicle(dbPath, { brand_name: "Audi", model_name: "A4", nickname: "Audi", is_default: true });
  core.saveUserVehicle(dbPath, { brand_name: "Volkswagen", model_name: "Golf", nickname: "VW", is_default: true });
  const rows = core.listUserVehicles(dbPath);
  assert.equal(rows.length, 2);
  assert.equal(rows.filter((x)=>x.is_default===1).length, 1);
  assert.equal(rows.find((x)=>x.nickname==="VW").is_default, 1);
});

test("renames and switches the default local vehicle without changing declared fitment status", (t) => {
  const { dbPath } = fixture(t);
  const first = core.saveUserVehicle(dbPath,{brand_name:"Audi",model_name:"A4",nickname:"Audi A4",is_default:true});
  const second = core.saveUserVehicle(dbPath,{brand_name:"Volkswagen",model_name:"Golf",nickname:"Golf"});
  assert.equal(core.renameUserVehicle(dbPath,second.id,"Golf daily"),true);
  assert.equal(core.setDefaultUserVehicle(dbPath,second.id),true);
  const rows=core.listUserVehicles(dbPath);
  assert.equal(rows.find(x=>x.id===first.id).is_default,0);
  assert.equal(rows.find(x=>x.id===second.id).is_default,1);
  assert.equal(rows.find(x=>x.id===second.id).nickname,"Golf daily");
  assert.equal(rows.find(x=>x.id===second.id).identity_status,"user_declared_unverified");
});

test("stores local bookmarks and query history independently of technical package imports", (t) => {
  const { dbPath } = fixture(t);
  const bookmark = core.saveBookmark(dbPath, { target_type: "vehicle_candidate", target_key: "vag:golf7", label: "Golf VII candidate" });
  const history = core.addHistory(dbPath, { query_text: "P0300", module_code: "DIAGNOSTIC", result_count: 1 });
  assert.equal(core.listBookmarks(dbPath).length, 1);
  assert.equal(core.listHistory(dbPath)[0].id, history.id);
  assert.equal(core.deleteBookmark(dbPath, bookmark.id), true);
  assert.equal(core.listBookmarks(dbPath).length, 0);
});

test("local administration lists source rights, snapshots and immutable import revisions", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source({ attribution_required: true, attribution_text: "Test publisher attribution" }));
  const imported = core.importPackage(dbPath, packageOf([genericDtc()]));
  const sources = core.listSources(dbPath);
  const batches = core.listImportBatches(dbPath);
  assert.equal(sources.length, 1);
  assert.equal(sources[0].source_id, "test-open-source");
  assert.equal(sources[0].rights_status, "approved_by_published_license");
  assert.equal(sources[0].commercial_use_allowed, 1);
  assert.equal(sources[0].offline_cache_allowed, 1);
  assert.equal(sources[0].snapshot_count, 1);
  assert.equal(sources[0].record_count, 1);
  assert.equal(sources[0].verified_record_count, 0);
  assert.equal(batches.length, 1);
  assert.equal(batches[0].id, imported.batchId);
  assert.equal(batches[0].status, "applied");
  assert.equal(batches[0].records_seen, 1);
  assert.equal(batches[0].records_inserted, 1);
  assert.equal(batches[0].rejected_items, 0);
});

test("does not expose candidate technical content through verified module search", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  core.importPackage(dbPath, packageOf([genericDtc()]));
  assert.deepEqual(core.getModuleCoverage(dbPath), []);
  assert.deepEqual(core.searchVerifiedTechnicalRecords(dbPath, { record_type: "dtc_generic", query: "P0300" }), []);
});

test("only returns verified technical records from a rights-cleared source and exact selected configuration", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const { configId, ecuId } = seedExactConfiguration(dbPath);
  const db = new DatabaseSync(dbPath);
  const payload = { title: "Oil pressure test", steps: ["Check sensor supply", "Measure signal"] };
  const insert = db.prepare(`INSERT INTO technical_records(record_type,namespace,natural_key,title,market_scope,applicability_precision,configuration_id,ecu_id,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,payload_json,review_status,created_at)
    VALUES('diagnostic_test_plan','vag_oem_specific','test:oil-pressure','Oil pressure test','RU','exact_configuration',?,?,?,'rev1',?,'test:oil-pressure',?,?, 'needs_review',?)`);
  insert.run(configId,ecuId,"test-open-source","b".repeat(64),core.sha256(payload),JSON.stringify(payload),new Date().toISOString());
  const id = Number(db.prepare("SELECT id FROM technical_records WHERE natural_key='test:oil-pressure'").get().id);
  db.prepare("UPDATE technical_records SET review_status='verified' WHERE id=?").run(id);
  db.close();
  assert.equal(core.searchVerifiedTechnicalRecords(dbPath, { record_type: "diagnostic_test_plan", configuration_id: configId, query: "oil" }).length, 1);
  assert.equal(core.searchVerifiedTechnicalRecords(dbPath, { record_type: "diagnostic_test_plan", configuration_id: configId+1, query: "oil" }).length, 0);
});

test("can search an exact ECU reference through the selected verified configuration without inventing configuration fitment", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source());
  const { configId, ecuId } = seedExactConfiguration(dbPath);
  const db = new DatabaseSync(dbPath);
  const payload = { ecu_family:"MED17.5.25", hardware_number:"06K907425", software_number:"0001" };
  db.prepare(`INSERT INTO technical_records(record_type,natural_key,title,market_scope,applicability_precision,ecu_id,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,payload_json,review_status,created_at)
    VALUES('ecu_reference','ecu:med17.5.25','MED17.5.25 ECU','RU','exact_ecu',?,'test-open-source','rev1',?,'ecu-ref:med17',?,?, 'needs_review',?)`)
    .run(ecuId,"b".repeat(64),core.sha256(payload),JSON.stringify(payload),new Date().toISOString());
  db.prepare("UPDATE technical_records SET review_status='verified' WHERE natural_key='ecu:med17.5.25'").run();
  db.close();
  const found=core.searchVerifiedTechnicalRecords(dbPath,{record_type:"ecu_reference",configuration_id:configId,query:"MED17"});
  assert.equal(found.length,1);
  assert.equal(found[0].configuration_id,null);
  assert.equal(found[0].ecu_id,ecuId);
});

test("blocks verification if the source rights are not approved", (t) => {
  const { dbPath } = fixture(t);
  core.registerSource(dbPath, source({ rights_status: "permission_required", commercial_use_allowed: false, display_allowed: false, offline_cache_allowed: false, bulk_reuse_allowed: false, redistribution_allowed: false }));
  const db = new DatabaseSync(dbPath);
  seedSourceSnapshot(db,"test-open-source","permission_required");
  const payload = { title: "generic definition" };
  db.prepare(`INSERT INTO technical_records(record_type,namespace,natural_key,title,market_scope,applicability_precision,source_id,source_revision,source_snapshot_sha256,source_record_key,record_sha256,payload_json,review_status,created_at)
    VALUES('dtc_generic','generic_sae_iso_obd2','P0300','P0300','ALL','generic_standard','test-open-source','rev1',?,'P0300',?,?, 'candidate',?)`).run("b".repeat(64),core.sha256(payload),JSON.stringify(payload),new Date().toISOString());
  assert.throws(()=>db.prepare("UPDATE technical_records SET review_status='verified' WHERE natural_key='P0300'").run(),/rights-cleared source/);
  db.close();
});

test("creates a consistent SQLite backup and restores it without silently discarding the current database", (t) => {
  const { dir, dbPath } = fixture(t);
  core.saveUserVehicle(dbPath, { brand_name: "Audi", model_name: "A6", nickname: "Before backup" });
  const backupPath = path.join(dir,"backup.sqlite");
  const backup = core.backupDatabase(dbPath,backupPath);
  assert.match(backup.sha256,/^[a-f0-9]{64}$/);
  core.saveUserVehicle(dbPath, { brand_name: "Volkswagen", model_name: "Passat", nickname: "After backup" });
  const restored = core.restoreDatabase(dbPath,backupPath);
  assert.equal(restored.restored,true);
  assert.ok(restored.safetyBackup);
  assert.deepEqual(core.listUserVehicles(dbPath).map((x)=>x.nickname),["Before backup"]);
  assert.ok(fs.existsSync(restored.safetyBackup));
});

test("safely replaces an existing backup while retaining the previous backup file", (t) => {
  const { dir, dbPath } = fixture(t);
  core.saveUserVehicle(dbPath,{brand_name:"Audi",model_name:"A4",nickname:"Snapshot one"});
  const backupPath=path.join(dir,"rolling.sqlite");
  core.backupDatabase(dbPath,backupPath);
  core.saveUserVehicle(dbPath,{brand_name:"Volkswagen",model_name:"Golf",nickname:"Snapshot two"});
  const updated=core.backupDatabase(dbPath,backupPath,{overwrite:true});
  assert.ok(updated.previousBackup);
  assert.ok(fs.existsSync(updated.previousBackup));
  const backupDb=new DatabaseSync(backupPath,{readOnly:true});
  assert.equal(backupDb.prepare("SELECT count(*) AS n FROM local_user_vehicles").get().n,2);
  backupDb.close();
});

test("refuses to back up a missing or uninitialized live database", (t) => {
  const { dir } = fixture(t);
  const missing=path.join(dir,"missing.sqlite");
  assert.throws(()=>core.backupDatabase(missing,path.join(dir,"missing-backup.sqlite")),/does not exist/);
});

test("rejects a corrupt backup and leaves the live user database intact", (t) => {
  const { dir, dbPath } = fixture(t);
  core.saveUserVehicle(dbPath,{brand_name:"Škoda",model_name:"Octavia",nickname:"Keep me"});
  const corrupt=path.join(dir,"corrupt.sqlite"); fs.writeFileSync(corrupt,"not sqlite");
  assert.throws(()=>core.restoreDatabase(dbPath,corrupt),/file is not a database|SQLite integrity check failed/i);
  assert.deepEqual(core.listUserVehicles(dbPath).map((x)=>x.nickname),["Keep me"]);
});
