"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const script = fs.readFileSync(path.join(__dirname, "..", "scripts", "windows-installer-lifecycle.ps1"), "utf8");

test("Windows lifecycle test requires an isolated CI profile and a newer upgrade installer", () => {
  assert.match(script, /\$env:CI -ne "true"/);
  assert.match(script, /InstallerPath/);
  assert.match(script, /UpgradeInstallerPath/);
  assert.match(script, /\$upgradeVersion -le \$firstVersion/);
});

test("Windows lifecycle test proves offline launch and local SQLite initialization", () => {
  assert.match(script, /server-ready/);
  assert.match(script, /Офлайн-режим/);
  assert.match(script, /api\/local-core\?action=admin-summary/);
  assert.match(script, /vag-tech-pro\.sqlite/);
});

test("Windows lifecycle test validates backup hash, restore and rollback of user data", () => {
  assert.match(script, /backup\.create/);
  assert.match(script, /X-Backup-SHA256/);
  assert.match(script, /backup\.restore/);
  assert.match(script, /Must disappear after restore/);
  assert.match(script, /safetyBackup/);
  assert.match(script, /PRAGMA foreign_key_check/);
  assert.match(script, /Restore safety backup file is missing/);
});

test("Windows lifecycle test verifies in-place upgrade and user database preservation on uninstall", () => {
  assert.match(script, /Install-NSIS \$UpgradeInstallerPath/);
  assert.match(script, /User database changed during the NSIS upgrade/);
  assert.match(script, /NSIS uninstall/);
  assert.match(script, /Assert-Database "Lifecycle vehicle"/);
  assert.match(script, /CloseMainWindow\(\)/);
});
