"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const component = fs.readFileSync(path.join(__dirname, "../components/local-research-catalog.tsx"), "utf8");
const page = fs.readFileSync(path.join(__dirname, "../app/page.tsx"), "utf8");

test("offline catalog UI keeps generic DTCs and candidate vehicle labels clearly separated from verified VAG fitment", () => {
  assert.match(component, /GENERIC SAE\/ISO OBD-II/);
  assert.match(component, /Не VAG-specific/);
  assert.match(component, /рынок: UNKNOWN/);
  assert.match(component, /точная применимость: не подтверждена/);
  assert.match(component, /Заводской код двигателя: отсутствует/);
  assert.match(component, /код КПП: отсутствует/);
  assert.match(component, /ODbL-1\.0/);
  assert.match(component, /CC0-1\.0/);
  assert.match(component, /UDS · сигналы сообщества/);
  assert.match(component, /CC BY-SA 4\.0/);
  assert.match(component, /Модели · рыночные данные/);
  assert.match(component, /Vehicle data by VehiclesDB/);
  assert.match(component, /зарубежное свидетельство|зарубежных свидетельств/);
  assert.match(component, /Данных нет/);
  assert.match(component, /Полные уведомления VehiclesDB/);
  assert.match(component, /Команда UDS не выполняется/);
  assert.match(component, /точная генерация, двигатель, КПП, аппаратная\/программная версия ECU и VIN не подтверждены/);
  assert.doesNotMatch(component, /Выполнить команду/);
  assert.match(component, /MechanicDB/);
  assert.match(component, /mechanicDb\.displayStatus/);
  assert.match(component, /не являются подтверждёнными VAG-specific кодами/);
  assert.match(component, /Wal33D \/ Waleed Judah/);
  assert.doesNotMatch(component, /id: "mechanicdb"/);
});

test("local research page is reachable from the main graphite workspace navigation", () => {
  assert.match(page, /Локальные справочники/);
  assert.match(page, /view===\"local-research\" \? <LocalResearchCatalog \/>/);
});


test("VehiclesDB market evidence is exposed only through the local read-only dataset route", () => {
  const route = fs.readFileSync(path.join(__dirname, "../app/api/local-research/route.ts"), "utf8");
  assert.match(route, /dataset === "vehiclesdb"/);
  assert.match(route, /searchVehiclesDbCandidates/);
  assert.match(component, /dataset === "vehiclesdb"/);
  assert.match(component, /marketEvidence/);
  assert.match(component, /row\.ruEvidencePresent/);
  assert.match(component, /row\.exactFitment/);
});

test("desktop opens the local SQLite workspace when Supabase is not configured and keeps research packs separate", () => {
  assert.match(page, /useState<"workspace"\|"bookmarks"\|"history"\|"garage"\|"local-research"\|"local-admin">\("workspace"\)/);
  assert.match(page, /if \(!supabase\) \{ setCloudLoading\(false\); setCatalogOnline\(false\); setView\("workspace"\)/);
  assert.match(page, /Локальный офлайн-режим: работает локальная SQLite/);
  assert.match(page, /Офлайн-режим/);
  assert.match(page, /const \[catalogOnline, setCatalogOnline\] = useState\(false\)/);
  assert.match(page, /const \[cloudLoading, setCloudLoading\] = useState\(Boolean\(supabase\)\)/);
  assert.match(page, /disabled=\{searching \|\| !catalogOnline\}/);
  assert.match(page, /Офлайн-поиск выполняется внутри выбранного технического модуля по локальной SQLite/);
  assert.match(page, /const catalogError = brandError \|\| modelError \|\| generationError \|\| authError/);
  assert.match(page, /Облачный каталог недоступен\. Переключено на локальную SQLite/);
  assert.match(page, /Облачная техническая база недоступна\. Используется локальная SQLite/);
  assert.match(page, /!supabase \|\| \(!catalogOnline && !cloudLoading\)/);
  assert.match(page, /<LocalOfflineWorkspace/);
  assert.match(page, /setView\("workspace"\)/);
});
