"use client";

import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Role = "admin" | "editor" | "reviewer";
type Source = {
  id: string;
  publisher: string;
  title: string;
  source_url: string | null;
  permission_status: string;
  revision: string | null;
  license_note: string | null;
  attribution_display_enabled?: boolean;
};
type Model = { id: string; name: string; slug: string; brand_id: string; is_active: boolean };
type Brand = { id: string; name: string };
type Evidence = {
  id: string;
  model_id: string;
  source_id: string;
  dataset_name: string;
  dataset_version: string;
  source_record_key: string;
  source_reference: string;
  country_code: string | null;
  evidence_type: string;
  source_name: string;
  source_url: string;
  source_license: string;
  source_license_url: string;
  source_notice: string;
  source_notice_url: string;
  attribution_text: string;
  attribution_url: string;
  evidence_payload: Record<string, unknown>;
  source_row_sha256: string;
  review_status: string;
  review_note: string | null;
  created_by: string;
  created_at: string;
  reviewed_by: string | null;
  reviewed_at: string | null;
};

type FormState = {
  model_id: string;
  source_id: string;
  dataset_name: string;
  dataset_version: string;
  source_record_key: string;
  source_reference: string;
  country_code: string;
  evidence_type: "registration" | "approval" | "sales" | "other";
  source_license: string;
  source_license_url: string;
  source_notice: string;
  source_notice_url: string;
  attribution_text: string;
  attribution_url: string;
  evidence_payload: string;
};

const EMPTY_FORM: FormState = {
  model_id: "", source_id: "", dataset_name: "", dataset_version: "", source_record_key: "",
  source_reference: "", country_code: "", evidence_type: "registration", source_license: "",
  source_license_url: "", source_notice: "", source_notice_url: "", attribution_text: "",
  attribution_url: "", evidence_payload: "{}"
};

function canonicalJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(record[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

async function sha256(value: string): Promise<string> {
  const digest = await globalThis.crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function isHttpsUrl(value: string): boolean {
  try { return new URL(value).protocol === "https:"; } catch { return false; }
}

function dateLabel(value: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat("ru-RU", { dateStyle: "medium", timeStyle: "short" }).format(date) : "Дата не указана";
}

function statusLabel(value: string) {
  return ({ draft: "Черновик", needs_review: "Ожидает проверки", verified: "Подтверждено", rejected: "Отклонено" } as Record<string, string>)[value] || value;
}

export default function ModelEvidenceManager({ sources, roles }: { sources: Source[]; roles: Role[] }) {
  const supabase = useMemo(() => createClient(), []);
  const [models, setModels] = useState<Model[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [rows, setRows] = useState<Evidence[]>([]);
  const [sessionUserId, setSessionUserId] = useState<string | null>(null);
  const sessionUserRef = useRef<string | null>(null);
  const sessionSequence = useRef(0);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [reviewNotes, setReviewNotes] = useState<Record<string, string>>({});
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const canEdit = roles.includes("admin") || roles.includes("editor");
  const canReview = roles.includes("admin") || roles.includes("reviewer");
  const sourceById = useMemo(() => new Map(sources.map((source) => [source.id, source])), [sources]);
  const brandById = useMemo(() => new Map(brands.map((brand) => [brand.id, brand.name])), [brands]);
  const modelById = useMemo(() => new Map(models.map((model) => [model.id, model])), [models]);

  const loadRows = useCallback(async (expectedSequence: number, ownerId: string) => {
    if (!supabase) return;
    const { data: authData, error: authError } = await supabase.auth.getUser();
    if (expectedSequence !== sessionSequence.current || sessionUserRef.current !== ownerId) return;
    if (authError || authData.user?.id !== ownerId) return;
    const [modelResult, brandResult, evidenceResult] = await Promise.all([
      supabase.from("vehicle_models").select("id,name,slug,brand_id,is_active").order("name").limit(500),
      supabase.from("brands").select("id,name").order("name").limit(50),
      supabase.from("vehicle_model_source_evidence").select("id,model_id,source_id,dataset_name,dataset_version,source_record_key,source_reference,country_code,evidence_type,source_name,source_url,source_license,source_license_url,source_notice,source_notice_url,attribution_text,attribution_url,evidence_payload,source_row_sha256,review_status,review_note,created_by,created_at,reviewed_by,reviewed_at").order("created_at", { ascending: false }).limit(200)
    ]);
    if (expectedSequence !== sessionSequence.current || sessionUserRef.current !== ownerId) return;
    const failed = [modelResult, brandResult, evidenceResult].find((result) => result.error);
    if (failed?.error) {
      setError(`Не удалось загрузить доказательства каталога: ${failed.error.message}`);
      return;
    }
    setModels((modelResult.data || []) as Model[]);
    setBrands((brandResult.data || []) as Brand[]);
    setRows((evidenceResult.data || []) as Evidence[]);
  }, [supabase]);

  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    const applyUser = (id: string | null) => {
      const sequence = ++sessionSequence.current;
      sessionUserRef.current = id;
      setSessionUserId(id);
      setModels([]); setBrands([]); setRows([]); setReviewNotes({});
      setForm(EMPTY_FORM); setBusy(false); setMessage(""); setError("");
      if (id) void loadRows(sequence, id);
    };
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (alive) applyUser(session?.user.id ?? null);
    });
    const initialSequence = sessionSequence.current;
    void supabase.auth.getUser().then(({ data, error: authError }) => {
      if (alive && !authError && initialSequence === sessionSequence.current) applyUser(data.user?.id ?? null);
    });
    return () => {
      alive = false;
      sessionSequence.current += 1;
      listener.subscription.unsubscribe();
    };
  }, [supabase, loadRows]);

  async function refresh() {
    const ownerId = sessionUserRef.current;
    if (!ownerId) return;
    await loadRows(sessionSequence.current, ownerId);
  }

  async function createEvidence(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase || !canEdit) return;
    const ownerId = sessionUserRef.current;
    const ownerSequence = sessionSequence.current;
    const source = sourceById.get(form.source_id);
    if (!ownerId || !source) { setError("Выберите действующую сессию и зарегистрированный источник."); return; }
    if (!form.model_id || !modelById.has(form.model_id)) { setError("Выберите модель из каталога."); return; }
    if (!source.source_url || !isHttpsUrl(source.source_url)) { setError("У источника в реестре должна быть HTTPS-ссылка."); return; }
    if (!form.dataset_name.trim() || form.dataset_name.trim().length > 120 || !form.dataset_version.trim() || form.dataset_version.trim().length > 80) { setError("Укажите название набора (до 120 символов) и его версию (до 80). "); return; }
    if (!form.source_record_key.trim() || form.source_record_key.trim().length > 240 || !form.source_reference.trim() || form.source_reference.trim().length > 120) { setError("Укажите ключ исходной записи (до 240 символов) и точную ссылку/раздел (до 120)."); return; }
    if (form.country_code.trim() && !/^[a-z]{2}$/i.test(form.country_code.trim())) { setError("Код страны должен состоять ровно из двух букв, например DE."); return; }
    if (!form.source_license.trim() || form.source_license.trim().length > 120 || !isHttpsUrl(form.source_license_url.trim())) { setError("Укажите точное обозначение лицензии и HTTPS-ссылку на её текст."); return; }
    if (!form.source_notice.trim() || form.source_notice.trim().length > 3000 || !isHttpsUrl(form.source_notice_url.trim())) { setError("Добавьте полный применимый notice и HTTPS-ссылку на него."); return; }
    if (!form.attribution_text.trim() || form.attribution_text.trim().length > 500 || !isHttpsUrl(form.attribution_url.trim())) { setError("Укажите точный текст атрибуции и HTTPS-ссылку на страницу источника."); return; }
    let payload: unknown;
    try { payload = JSON.parse(form.evidence_payload); } catch { setError("Исходная запись должна быть корректным JSON."); return; }
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) { setError("Корнем исходной записи должен быть JSON-объект."); return; }
    const canonical = canonicalJson(payload);
    if (new TextEncoder().encode(canonical).byteLength > 64 * 1024) { setError("Исходная запись превышает серверный лимит 64 КБ."); return; }
    setBusy(true); setError(""); setMessage("");
    try {
      const { data: authData, error: authError } = await supabase.auth.getUser();
      if (authError || authData.user?.id !== ownerId || sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) throw new Error("Сессия изменилась. Создание доказательства остановлено.");
      const rowHash = await sha256(canonical);
      if (sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) throw new Error("Сессия изменилась до сохранения доказательства.");
      const { error: insertError } = await supabase.from("vehicle_model_source_evidence").insert({
        model_id: form.model_id,
        source_id: source.id,
        dataset_name: form.dataset_name.trim(),
        dataset_version: form.dataset_version.trim(),
        source_record_key: form.source_record_key.trim(),
        source_reference: form.source_reference.trim(),
        country_code: form.country_code.trim() ? form.country_code.trim().toLowerCase() : null,
        evidence_type: form.evidence_type,
        source_name: source.publisher,
        source_url: source.source_url,
        source_license: form.source_license.trim(),
        source_license_url: form.source_license_url.trim(),
        source_notice: form.source_notice.trim(),
        source_notice_url: form.source_notice_url.trim(),
        attribution_text: form.attribution_text.trim(),
        attribution_url: form.attribution_url.trim(),
        evidence_payload: payload,
        source_row_sha256: rowHash,
        review_status: "draft",
        created_by: ownerId
      });
      if (insertError) throw new Error(insertError.message);
      if (sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) return;
      setForm(EMPTY_FORM);
      setMessage("Доказательство сохранено как черновик. Оно не активирует модель и не открывает публичную выдачу до отдельного решения проверяющего и одобрения прав источника.");
      await refresh();
    } catch (e) {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence) {
        setError(e instanceof Error ? e.message : "Не удалось сохранить доказательство.");
      }
    } finally {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence) setBusy(false);
    }
  }

  async function decide(row: Evidence, decision: "verified" | "rejected") {
    if (!supabase || !canReview) return;
    const ownerId = sessionUserRef.current;
    const ownerSequence = sessionSequence.current;
    const note = (reviewNotes[row.id] || "").trim();
    if (!ownerId || note.length < 20) { setError("Для решения требуется комментарий не короче 20 символов с указанием документа, версии, записи и проверки применимости."); return; }
    setBusy(true); setError(""); setMessage("");
    try {
      const { data: authData, error: authError } = await supabase.auth.getUser();
      if (authError || authData.user?.id !== ownerId || sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) throw new Error("Сессия изменилась. Решение не отправлено.");
      const { data, error: rpcError } = await supabase.rpc("verify_vehicle_model_source_evidence", {
        p_evidence_id: row.id,
        p_decision: decision,
        p_review_note: note
      });
      if (rpcError) throw new Error(rpcError.message);
      if (sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) return;
      const result = data as { status?: string } | null;
      setMessage(decision === "verified"
        ? `Доказательство ${result?.status || "подтверждено"}. Модель активируется только при одобренных правах источника и включённой атрибуции.`
        : "Доказательство отклонено. Исправления должны поступить новой версией, исходная запись остаётся в аудите.");
      await refresh();
    } catch (e) {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence) {
        setError(e instanceof Error ? e.message : "Решение не сохранено.");
      }
    } finally {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence) setBusy(false);
    }
  }

  const filteredRows = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    return rows.filter((row) => status === "all" || row.review_status === status)
      .filter((row) => {
        if (!needle) return true;
        const model = modelById.get(row.model_id);
        const source = sourceById.get(row.source_id);
        return [model?.name, brandById.get(model?.brand_id || ""), row.dataset_name, row.dataset_version, row.source_record_key, row.source_reference, source?.title, row.source_name, row.review_status].filter(Boolean).join(" ").toLocaleLowerCase().includes(needle);
      });
  }, [rows, status, query, modelById, sourceById, brandById]);

  if (!sessionUserId) return <section className="admin-section" id="model-evidence"><div className="admin-empty">Проверка источников моделей доступна после входа сотрудника.</div></section>;

  return <section className="admin-section" id="model-evidence">
    <div className="admin-section-head">
      <div><div className="admin-kicker">MODEL IDENTITY PROVENANCE</div><h2>Доказательства названий моделей</h2><p>Эта очередь подтверждает только происхождение названия модели. Она не создаёт поколение, двигатель, КПП, ECU, PR-коды или точную VIN-комплектацию.</p></div>
      <span className="admin-count">{rows.filter((row) => row.review_status === "draft" || row.review_status === "needs_review").length} ожидают</span>
    </div>

    {canEdit && <form className="admin-form" onSubmit={(event) => void createEvidence(event)}>
      <div className="admin-form-title">Новое доказательство источника</div>
      <div className="admin-form-grid">
        <label>Модель каталога<select required value={form.model_id} onChange={(event) => setForm((v) => ({ ...v, model_id: event.target.value }))}><option value="">Выберите модель</option>{models.map((model) => <option key={model.id} value={model.id}>{brandById.get(model.brand_id) || "VAG"} · {model.name}{model.is_active ? " · активна, только навигационная метка" : " · скрыта"}</option>)}</select></label>
        <label>Зарегистрированный источник<select required value={form.source_id} onChange={(event) => setForm((v) => ({ ...v, source_id: event.target.value }))}><option value="">Выберите источник</option>{sources.map((source) => <option key={source.id} value={source.id}>{source.publisher} · {source.permission_status}</option>)}</select></label>
        <label>Название набора<input required maxLength={120} value={form.dataset_name} onChange={(event) => setForm((v) => ({ ...v, dataset_name: event.target.value }))} placeholder="Название набора / реестра" /></label>
        <label>Версия набора<input required maxLength={80} value={form.dataset_version} onChange={(event) => setForm((v) => ({ ...v, dataset_version: event.target.value }))} placeholder="Ревизия, дата или DOI" /></label>
        <label>Ключ исходной записи<input required maxLength={240} value={form.source_record_key} onChange={(event) => setForm((v) => ({ ...v, source_record_key: event.target.value }))} placeholder="Идентификатор записи у издателя" /></label>
        <label>Ссылка / раздел источника<input required maxLength={120} value={form.source_reference} onChange={(event) => setForm((v) => ({ ...v, source_reference: event.target.value }))} placeholder="DOI, номер страницы, ID записи" /></label>
        <label>Страна (необязательно)<input maxLength={2} value={form.country_code} onChange={(event) => setForm((v) => ({ ...v, country_code: event.target.value.toUpperCase() }))} placeholder="DE" /></label>
        <label>Тип доказательства<select value={form.evidence_type} onChange={(event) => setForm((v) => ({ ...v, evidence_type: event.target.value as FormState["evidence_type"] }))}><option value="registration">Регистрационный реестр</option><option value="approval">Официальное одобрение типа</option><option value="sales">Официальная модельная линейка</option><option value="other">Другое</option></select></label>
        <label>Лицензия<input required maxLength={120} value={form.source_license} onChange={(event) => setForm((v) => ({ ...v, source_license: event.target.value }))} placeholder="Точное обозначение лицензии" /></label>
        <label>URL текста лицензии<input required type="url" value={form.source_license_url} onChange={(event) => setForm((v) => ({ ...v, source_license_url: event.target.value }))} placeholder="https://…" /></label>
        <label className="wide">Copyright / source notice<textarea required maxLength={3000} rows={3} value={form.source_notice} onChange={(event) => setForm((v) => ({ ...v, source_notice: event.target.value }))} placeholder="Полный применимый notice без пересказа" /></label>
        <label>URL notice<input required type="url" value={form.source_notice_url} onChange={(event) => setForm((v) => ({ ...v, source_notice_url: event.target.value }))} placeholder="https://…" /></label>
        <label>URL страницы атрибуции<input required type="url" value={form.attribution_url} onChange={(event) => setForm((v) => ({ ...v, attribution_url: event.target.value }))} placeholder="https://…" /></label>
        <label className="wide">Точный текст публичной атрибуции<textarea required maxLength={500} rows={2} value={form.attribution_text} onChange={(event) => setForm((v) => ({ ...v, attribution_text: event.target.value }))} placeholder="Текст, который будет показан пользователю при разрешённой публикации" /></label>
        <label className="wide">Исходная запись JSON<textarea required className="admin-json" rows={7} spellCheck={false} value={form.evidence_payload} onChange={(event) => setForm((v) => ({ ...v, evidence_payload: event.target.value }))} /></label>
      </div>
      {form.source_id && (() => { const source = sourceById.get(form.source_id); return source ? <div className="admin-alert" style={{ borderColor: "#46576a", background: "#111d29", color: "#b9c7d5" }}>Источник: {source.title}. Текущий статус прав — <strong>{source.permission_status}</strong>; атрибуция включена: <strong>{source.attribution_display_enabled ? "да" : "нет"}</strong>. Статус источника нельзя заменить заполнением этой формы. Для подтверждения нужны отдельное решение администратора по правам и включённая атрибуция.</div> : null; })()}
      <div className="admin-form-foot"><span>SHA-256 исходного JSON рассчитывается автоматически по каноническому представлению. Новый объект создаётся только как draft.</span><button className="admin-primary" disabled={busy || !form.model_id || !form.source_id}>Сохранить доказательство</button></div>
    </form>}

    <div className="admin-queue-filters"><input aria-label="Поиск доказательств моделей" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Модель, источник, DOI или ключ записи…" /><select aria-label="Статус доказательства" value={status} onChange={(event) => setStatus(event.target.value)}><option value="all">Все статусы</option><option value="draft">Черновики</option><option value="needs_review">Ожидают проверки</option><option value="verified">Подтверждены</option><option value="rejected">Отклонены</option></select><span>{filteredRows.length} из {rows.length}</span></div>
    <div className="admin-item-list">
      {filteredRows.map((row) => {
        const model = modelById.get(row.model_id);
        const source = sourceById.get(row.source_id);
        const rightsReady = source?.permission_status === "licensed" || source?.permission_status === "public_domain";
        return <article className="admin-item" key={row.id}>
          <div className="admin-item-head"><div><strong>{brandById.get(model?.brand_id || "") || "VAG"} · {model?.name || "Модель не найдена"}</strong><span>{row.dataset_name} · {row.dataset_version} · {row.source_record_key}</span></div><span className={`admin-status ${row.review_status === "verified" ? "verified" : row.review_status === "draft" || row.review_status === "needs_review" ? "pending" : ""}`}>{statusLabel(row.review_status)}</span></div>
          <div className="admin-review-note">{row.source_name} · {row.source_reference} · {row.country_code || "страна не указана"} · {row.evidence_type}</div>
          <details><summary>Показать лицензию, notice, исходную запись и SHA-256</summary><p className="admin-review-note">Лицензия: {row.source_license} · {row.source_license_url}</p><p className="admin-review-note">Notice: {row.source_notice}</p><p className="admin-review-note">Атрибуция: {row.attribution_text} · {row.attribution_url}</p><pre>{JSON.stringify(row.evidence_payload, null, 2)}</pre><code>{row.source_row_sha256}</code><p className="admin-review-note">Создано: {dateLabel(row.created_at)} · проверено: {dateLabel(row.reviewed_at)}</p></details>
          <div className="admin-review-note">Права источника: {source?.permission_status || "не найден"} · атрибуция: {source?.attribution_display_enabled ? "включена" : "выключена"} · модель: {model?.is_active ? "активна — навигационное название, не точная применимость" : "скрыта"}</div>
          {canReview && (row.review_status === "draft" || row.review_status === "needs_review") && <div className="admin-review-actions"><input value={reviewNotes[row.id] || ""} onChange={(event) => setReviewNotes((current) => ({ ...current, [row.id]: event.target.value }))} placeholder="Основание: источник, версия, запись и применимость (мин. 20 символов)" /><button type="button" disabled={busy || !rightsReady || !source?.attribution_display_enabled} onClick={() => void decide(row, "verified")} className="admin-primary">Подтвердить</button><button type="button" disabled={busy} onClick={() => void decide(row, "rejected")} className="admin-danger">Отклонить</button></div>}
          {canReview && (row.review_status === "draft" || row.review_status === "needs_review") && !rightsReady && <p className="admin-review-note">Подтверждение заблокировано: права источника ещё не одобрены. Черновик остаётся закрытым.</p>}
        </article>;
      })}
      {!filteredRows.length && <div className="admin-empty">Доказательства по заданным фильтрам не найдены.</div>}
    </div>
    <small>Источник и атрибуция проверяются повторно сервером при принятии решения. Исправления происхождения оформляются новой записью, а не редактированием проверенного доказательства.</small>
    {message && <div className="admin-notice">{message}</div>}{error && <div className="admin-error">{error}</div>}
  </section>;
}
