"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Source = { id: string; publisher: string; title: string; source_url: string | null; permission_status: string; revision: string | null };
type Role = "admin" | "editor" | "reviewer";
type Candidate = {
  source_record_key: string; source_row_sha256: string; source_doi: string; source_dataset_title: string;
  registration_year: number; data_status: "F" | "P"; country_code: string | null; brand_canonical: string;
  commercial_name: string; type_approval_number: string; vehicle_type: string | null; variant: string | null; version: string | null;
  engine_capacity_cc: number | null; engine_power_kw: number | null; fuel_type: string | null; fuel_mode: string | null;
  mass_running_order_kg: number | null; co2_wltp_g_km: number | null; co2_nedc_g_km: number | null; raw_source_record: Record<string, unknown>;
};
type ReviewRow = { id: string; brand_name: string; commercial_name: string; registration_year: number; data_status: string; type_approval_number: string; review_status: string; country_code: string | null; engine_capacity_cc: number | null; engine_power_kw: number | null; fuel_type: string | null; created_at: string; source_id: string };

const EEA_URLS: Record<number, string> = {
  2024: "https://sdi.eea.europa.eu/catalogue/srv/api/records/5018ec17-2348-4c92-8761-6f2377bbd1c0",
  2025: "https://sdi.eea.europa.eu/catalogue/srv/api/records/b4044b06-2e6b-4f8e-a6e6-66e0e98bb0dd",
};

export default function HomologationImport({ sources, roles }: { sources: Source[]; roles: Role[] }) {
  const supabase = useMemo(() => createClient(), []);
  const [rows, setRows] = useState<ReviewRow[]>([]);
  const [sessionUserId, setSessionUserId] = useState<string | null>(null);
  const sessionUserRef = useRef<string | null>(null);
  const sessionSequence = useMemo(() => ({ current: 0 }), []);
  const [fileName, setFileName] = useState("");
  const [candidateCount, setCandidateCount] = useState(0);
  const [preview, setPreview] = useState<Candidate[]>([]);
  const [bundleRecords, setBundleRecords] = useState<Candidate[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [reviewNote, setReviewNote] = useState<Record<string, string>>({});
  const canImport = roles.includes("admin") || roles.includes("editor");
  const canReview = roles.includes("admin") || roles.includes("reviewer");

  const loadRows = useCallback(async () => {
    if (!supabase) return;
    const sequence = sessionSequence.current;
    const { data, error: queryError } = await supabase.from("vehicle_homologation_variants")
      .select("id,brand_name,commercial_name,registration_year,data_status,type_approval_number,review_status,country_code,engine_capacity_cc,engine_power_kw,fuel_type,created_at,source_id")
      .order("created_at", { ascending: false }).limit(100);
    if (sequence !== sessionSequence.current) return;
    if (queryError) setError(`Очередь омологации: ${queryError.message}`);
    else setRows((data || []) as ReviewRow[]);
  }, [supabase, sessionSequence]);

  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    const applyUser = (id: string | null) => {
      sessionSequence.current += 1;
      if (!alive) return;
      sessionUserRef.current = id;
      setSessionUserId(id);
      setRows([]); setPreview([]); setBundleRecords([]); setCandidateCount(0);
      if (id) void loadRows();
    };
    void supabase.auth.getUser().then(({ data, error: authError }) => {
      if (alive && !authError) applyUser(data.user?.id ?? null);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => applyUser(session?.user.id ?? null));
    return () => { alive = false; listener.subscription.unsubscribe(); sessionSequence.current += 1; };
  }, [supabase, loadRows, sessionSequence]);

  async function readCandidateFile(file: File) {
    setError(""); setMessage(""); setPreview([]); setBundleRecords([]); setCandidateCount(0); setFileName(file.name);
    if (file.size > 25 * 1024 * 1024) { setError("Файл превышает лимит 25 МБ. Разделите пакет на части."); return; }
    try {
      const bundle = JSON.parse(await file.text()) as { provider?: string; license?: string; records?: Candidate[]; source_datasets?: Array<{ year: number; doi: string; source_url?: string; status: string }> };
      if (bundle.provider !== "European Environment Agency / DG CLIMA" || bundle.license !== "CC BY 4.0" || !Array.isArray(bundle.records) || !Array.isArray(bundle.source_datasets)) throw new Error("Это не распознанный пакет EEA VAG.");
      if (!bundle.records.length || bundle.records.length > 5000) throw new Error("Пакет должен содержать от 1 до 5000 строк. Разделите выгрузку по годам/частям.");
      const datasets = new Map(bundle.source_datasets.map((item) => [item.year, item]));
      const seen = new Set<string>();
      for (const [i, row] of bundle.records.entries()) {
        const ds = datasets.get(row.registration_year);
        if (!ds || ds.doi !== row.source_doi || row.data_status !== ds.status) throw new Error(`Строка ${i + 1}: год, DOI или статус выпуска не совпадают.`);
        if (EEA_URLS[row.registration_year] !== ds.source_url) throw new Error(`Строка ${i + 1}: неизвестный источник для ${row.registration_year}.`);
        if (!/^[a-f0-9]{64}$/.test(row.source_row_sha256) || !row.source_record_key || !row.type_approval_number || !row.commercial_name || !row.raw_source_record || typeof row.raw_source_record !== "object" || Array.isArray(row.raw_source_record)) throw new Error(`Строка ${i + 1}: нет обязательной идентичности, исходной строки или SHA-256.`);
        const rawBytes = new TextEncoder().encode(JSON.stringify(row.raw_source_record));
        if (rawBytes.byteLength > 128 * 1024) throw new Error(`Строка ${i + 1}: исходная запись превышает 128 КБ.`);
        const digest = await globalThis.crypto.subtle.digest("SHA-256", rawBytes);
        const actualHash = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
        if (actualHash !== row.source_row_sha256) throw new Error(`Строка ${i + 1}: SHA-256 исходной записи не совпадает.`);
        if (!["Volkswagen", "Audi", "Škoda", "SEAT", "CUPRA"].includes(row.brand_canonical)) throw new Error(`Строка ${i + 1}: марка вне списка VAG.`);
        if ((row as Candidate & { engine_code?: unknown; gearbox_code?: unknown; ecu_id?: unknown; pr_codes?: unknown }).engine_code || (row as Candidate & { gearbox_code?: unknown }).gearbox_code || (row as Candidate & { ecu_id?: unknown }).ecu_id || (row as Candidate & { pr_codes?: unknown }).pr_codes) throw new Error(`Строка ${i + 1}: запрещённые поля точной комплектации.`);
        const key = `${row.registration_year}:${row.source_record_key}:${row.source_row_sha256}`;
        if (seen.has(key)) throw new Error(`Строка ${i + 1}: повтор исходной записи.`);
        seen.add(key);
      }
      for (const year of new Set(bundle.records.map((row) => row.registration_year))) {
        if (!sources.some((source) => source.source_url === EEA_URLS[year])) throw new Error(`В реестре источников отсутствует EEA ${year}.`);
      }
      setBundleRecords(bundle.records);
      setCandidateCount(bundle.records.length);
      setPreview(bundle.records.slice(0, 5));
      setMessage(`Пакет проверен локально: ${bundle.records.length} строк. Они ещё не загружены и не опубликованы.`);
    } catch (e) { setError(e instanceof Error ? e.message : "Не удалось прочитать пакет."); }
  }

  async function importCandidates() {
    const bundle = bundleRecords;
    if (!supabase) { setError("Supabase не подключён."); return; }
    if (!bundle.length) { setError("Сначала выберите и проверьте файл EEA."); return; }
    setBusy(true); setError(""); setMessage("");
    const ownerId = sessionUserId;
    const { data: authData, error: authError } = await supabase.auth.getUser();
    if (authError || !authData.user || !ownerId || authData.user.id !== ownerId) { setError("Нужна действующая авторизованная сессия с правами импорта."); setBusy(false); return; }
    let inserted = 0; let skipped = 0;
    let failed = false;
    for (let offset = 0; offset < bundle.length; offset += 100) {
      const { data: currentAuth } = await supabase.auth.getUser();
      if (currentAuth.user?.id !== ownerId || sessionUserRef.current !== ownerId) { setError("Сессия изменилась. Импорт остановлен; уже отправленные строки остались на проверке."); failed = true; break; }
      const chunk: Candidate[] = bundle.slice(offset, offset + 100);
      const payload: Array<Record<string, unknown> | null> = chunk.map((row: Candidate) => {
        const source = sources.find((item) => item.source_url === EEA_URLS[row.registration_year]);
        if (!source) return null;
        return {
          source_id: source.id, dataset_doi: row.source_doi, dataset_revision: row.source_dataset_title,
          registration_year: row.registration_year, data_status: row.data_status, country_code: row.country_code,
          brand_name: row.brand_canonical, commercial_name: row.commercial_name, type_approval_number: row.type_approval_number,
          vehicle_type: row.vehicle_type, variant: row.variant, version: row.version,
          engine_capacity_cc: row.engine_capacity_cc, engine_power_kw: row.engine_power_kw, fuel_type: row.fuel_type,
          fuel_mode: row.fuel_mode, mass_running_order_kg: row.mass_running_order_kg,
          co2_wltp_g_km: row.co2_wltp_g_km, co2_nedc_g_km: row.co2_nedc_g_km,
          source_record_key: row.source_record_key, source_row_sha256: row.source_row_sha256,
          raw_source_record: row.raw_source_record,
          attribution_text: "Contains data from the European Environment Agency (EEA), Monitoring of CO2 emissions from passenger cars, licensed under CC BY 4.0.",
          review_status: "needs_review", created_by: authData.user.id,
        };
      });
      if (payload.some((item) => item === null)) { setError("Не найден зарегистрированный источник для одного из годов выгрузки."); failed = true; break; }
      const validPayload = payload.filter((item): item is Record<string, unknown> => item !== null);
      const { data, error: insertError } = await supabase.from("vehicle_homologation_variants").upsert(validPayload, { onConflict: "source_id,source_record_key,source_row_sha256", ignoreDuplicates: true }).select("id");
      if (insertError) { setError(`Загружено ${inserted}, остановка на строках ${offset + 1}–${offset + chunk.length}: ${insertError.message}`); failed = true; break; }
      if (sessionUserRef.current !== ownerId) { setError("Сессия изменилась после ответа сервера. Новые действия остановлены."); failed = true; break; }
      inserted += data?.length || 0; skipped += chunk.length - (data?.length || 0);
    }
    if (!failed) { setMessage(`Загрузка завершена. Новых строк: ${inserted}; пропущено как уже существующих: ${skipped}. Все строки остаются на проверке.`); setBundleRecords([]); setCandidateCount(0); setPreview([]); }
    setBusy(false); if (sessionUserRef.current === ownerId) await loadRows();
  }

  async function decide(row: ReviewRow, decision: "verified" | "rejected") {
    if (!supabase) { setError("Supabase не подключён."); return; }
    if (!sessionUserId) { setError("Для проверки нужна авторизованная сессия."); return; }
    const ownerAtStart = sessionUserId;
    const note = (reviewNote[row.id] || "").trim();
    if (note.length < 20) { setError("Для решения требуется обоснование минимум 20 символов."); return; }
    setBusy(true); setError(""); setMessage("");
    const { error: rpcError } = await supabase.rpc("review_vehicle_homologation_variant", { p_id: row.id, p_decision: decision, p_note: note });
    if (sessionUserRef.current !== ownerAtStart) { setBusy(false); return; }
    if (rpcError) setError(`Решение не сохранено: ${rpcError.message}`);
    else { setMessage(`Запись ${row.brand_name} ${row.commercial_name}: ${decision === "verified" ? "проверена" : "отклонена"}.`); await loadRows(); }
    setBusy(false);
  }

  return <section className="admin-section" id="homologation">
    <div className="admin-section-head"><div><div className="admin-kicker">EU TYPE APPROVAL DATA</div><h2>Омологационный каталог EEA</h2><p>Отдельный слой типов, вариантов и версий. Не является заводской комплектацией VAG.</p></div><span className="admin-count">{rows.filter((r) => r.review_status === "needs_review").length} на проверке</span></div>
    {canImport && sessionUserId && <div className="admin-card">
      <h3>Загрузка пакета EEA</h3>
      <p>Поддерживаются только выгрузки подготовителя EEA с зарегистрированными DOI за 2024 Final и 2025 Provisional. Максимум 5000 строк за импорт.</p>
      <label>Файл кандидатов JSON<input type="file" accept="application/json,.json" disabled={busy} onChange={(e) => { const file = e.target.files?.[0]; if (file) void readCandidateFile(file); }} /></label>
      {fileName && <small>{fileName} · {candidateCount} строк · первые 5 показаны в предпросмотре</small>}
      {preview.length > 0 && <div className="admin-payload-preview">{preview.map((r, i) => <div key={`${r.source_record_key}-${i}`}>{r.brand_canonical} {r.commercial_name} · {r.registration_year} · {r.type_approval_number} · {r.engine_capacity_cc ?? "—"} см³ · {r.engine_power_kw ?? "—"} кВт · {r.data_status === "P" ? "ПРЕДВАРИТЕЛЬНЫЕ" : "ФИНАЛЬНЫЕ"}</div>)}</div>}
      <button type="button" className="admin-primary" disabled={busy || !candidateCount} onClick={() => void importCandidates()}>Загрузить в очередь проверки</button>
    </div>}
    {message && <div className="admin-notice">{message}</div>}{error && <div className="admin-error">{error}</div>}
    <div className="admin-review-list">{rows.map((row) => <article className="admin-review-item" key={row.id}>
      <div><strong>{row.brand_name} {row.commercial_name}</strong><span>{row.registration_year} · {row.data_status === "P" ? "Предварительные" : "Финальные"} · {row.country_code || "рынок не указан"} · {row.type_approval_number}</span><small>{row.engine_capacity_cc ?? "—"} см³ · {row.engine_power_kw ?? "—"} кВт · {row.fuel_type || "топливо не указано"}</small><small>Статус: {row.review_status}</small></div>
      {canReview && row.review_status === "needs_review" && <div className="admin-review-actions"><textarea rows={2} placeholder="Основание проверки (минимум 20 символов)" value={reviewNote[row.id] || ""} onChange={(e) => setReviewNote((v) => ({ ...v, [row.id]: e.target.value }))} /><button type="button" disabled={busy} className="admin-primary" onClick={() => void decide(row, "verified")}>Подтвердить</button><button type="button" disabled={busy} className="admin-secondary" onClick={() => void decide(row, "rejected")}>Отклонить</button></div>}
    </article>)}</div>
    <small>Публичная выдача заблокирована до одобрения прав источника, атрибуции и отдельной проверки записи. Отсутствующие поля остаются неизвестными.</small>
  </section>;
}
