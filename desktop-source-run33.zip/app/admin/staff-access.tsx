"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Account = { user_id: string; email: string | null; created_at: string; roles: string[] };
type Role = "admin" | "editor" | "reviewer";

function dateLabel(value: string) {
  const date = new Date(value);
  return Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat("ru-RU", { dateStyle: "medium" }).format(date) : "Дата не указана";
}

export default function StaffAccessManager({ roles }: { roles: string[] }) {
  const supabase = useMemo(() => createClient(), []);
  const canManage = roles.includes("admin");
  const sessionUserRef = useRef<string | null>(null);
  const sessionSequence = useRef(0);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [selectedRole, setSelectedRole] = useState<Role>("editor");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const loadAccounts = useCallback(async (expectedSequence: number, ownerId: string) => {
    if (!supabase) return;
    const { data: authData, error: authError } = await supabase.auth.getUser();
    if (authError || authData.user?.id !== ownerId || sessionUserRef.current !== ownerId || sessionSequence.current !== expectedSequence) return;
    const { data, error: listError } = await supabase.rpc("list_staff_accounts");
    if (sessionUserRef.current !== ownerId || sessionSequence.current !== expectedSequence) return;
    if (listError) { setError(`Не удалось загрузить список сотрудников: ${listError.message}`); return; }
    const next = (data || []) as Account[];
    setAccounts(next);
    setSelectedUserId((current) => next.some((account) => account.user_id === current) ? current : next[0]?.user_id || "");
  }, [supabase]);

  useEffect(() => {
    if (!supabase || !canManage) return;
    let alive = true;
    const applyUser = (id: string | null) => {
      const sequence = ++sessionSequence.current;
      sessionUserRef.current = id;
      setAccounts([]); setSelectedUserId(""); setSelectedRole("editor"); setReason(""); setBusy(false); setMessage(""); setError("");
      if (id) void loadAccounts(sequence, id);
    };
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { if (alive) applyUser(session?.user.id ?? null); });
    const initialSequence = sessionSequence.current;
    void supabase.auth.getUser().then(({ data, error: authError }) => {
      if (alive && !authError && initialSequence === sessionSequence.current) applyUser(data.user?.id ?? null);
    });
    return () => { alive = false; sessionSequence.current += 1; listener.subscription.unsubscribe(); };
  }, [supabase, canManage, loadAccounts]);

  async function refresh() {
    const ownerId = sessionUserRef.current;
    if (ownerId) await loadAccounts(sessionSequence.current, ownerId);
  }

  async function changeRole(grant: boolean) {
    if (!supabase || !canManage) return;
    const ownerId = sessionUserRef.current;
    const ownerSequence = sessionSequence.current;
    const note = reason.trim();
    if (!ownerId || !selectedUserId) { setError("Выберите существующую учётную запись."); return; }
    if (note.length < 20 || note.length > 500) { setError("Основание изменения роли должно содержать от 20 до 500 символов."); return; }
    if (!grant && selectedRole === "admin" && selectedUserId === ownerId) { setError("Собственную роль admin может отозвать только другой администратор."); return; }
    setBusy(true); setError(""); setMessage("");
    try {
      const { data: authData, error: authError } = await supabase.auth.getUser();
      if (authError || authData.user?.id !== ownerId || sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) throw new Error("Сессия изменилась. Изменение роли отменено.");
      const { data, error: rpcError } = await supabase.rpc("set_app_user_role", {
        p_user_id: selectedUserId,
        p_role: selectedRole,
        p_grant: grant,
        p_reason: note
      });
      if (rpcError) throw new Error(rpcError.message);
      if (sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) return;
      const result = data as { status?: string; role?: string } | null;
      const labels: Record<string, string> = { assigned: "назначена", already_assigned: "уже назначена", revoked: "отозвана", already_absent: "уже отсутствует" };
      setMessage(`Роль ${result?.role || selectedRole} ${labels[result?.status || ""] || "обработана"}. Изменение записано в аудит.`);
      setReason("");
      await refresh();
    } catch (e) {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence) setError(e instanceof Error ? e.message : "Изменение роли не выполнено.");
    } finally {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence) setBusy(false);
    }
  }

  if (!canManage) return null;
  const selectedAccount = accounts.find((account) => account.user_id === selectedUserId);
  const adminCount = accounts.filter((account) => account.roles.includes("admin")).length;

  return <section className="admin-section" id="staff-access">
    <div className="admin-section-head"><div><div className="admin-kicker">ACCESS CONTROL</div><h2>Сотрудники и роли</h2><p>Только администратор может назначать роли существующим учётным записям. Создание пользователей остаётся в Supabase Auth.</p></div><span className="admin-count">{accounts.length} учётных записей</span></div>
    <div className="admin-form">
      <div className="admin-form-title">Изменить роль</div>
      <div className="admin-form-grid">
        <label>Учётная запись<select value={selectedUserId} onChange={(event) => setSelectedUserId(event.target.value)} disabled={busy || !accounts.length}><option value="">Нет доступных пользователей</option>{accounts.map((account) => <option key={account.user_id} value={account.user_id}>{account.email || account.user_id} · {account.roles.join(", ") || "без роли"}</option>)}</select></label>
        <label>Роль<select value={selectedRole} onChange={(event) => setSelectedRole(event.target.value as Role)} disabled={busy}><option value="editor">Editor — загрузка и подготовка</option><option value="reviewer">Reviewer — проверка и модерация</option><option value="admin">Admin — управление правами и источниками</option></select></label>
        <label className="wide">Основание изменения<textarea rows={3} maxLength={500} value={reason} onChange={(event) => setReason(event.target.value)} disabled={busy} placeholder="Кто получает доступ, для каких обязанностей и на каком основании (минимум 20 символов)" /></label>
      </div>
      <div className="admin-form-foot"><span>Администраторов: {adminCount}. Нельзя отозвать последнюю роль admin или собственную роль admin.</span><div className="admin-review-actions"><button type="button" className="admin-secondary" disabled={busy || !selectedAccount || !reason.trim()} onClick={() => void changeRole(false)}>Отозвать роль</button><button type="button" className="admin-primary" disabled={busy || !selectedAccount || !reason.trim()} onClick={() => void changeRole(true)}>Назначить роль</button></div></div>
    </div>
    <div className="admin-item-list">
      {accounts.map((account) => <article className="admin-item" key={account.user_id}>
        <div className="admin-item-head"><div><strong>{account.email || "Email не указан"}</strong><span>{account.user_id} · создана {dateLabel(account.created_at)}</span></div><span className="admin-status">{account.roles.length ? account.roles.join(" · ") : "Без роли"}</span></div>
      </article>)}
      {!accounts.length && <div className="admin-empty">Пользователей пока нет. Создайте первую учётную запись через Supabase Auth; затем владелец проекта должен один раз выдать ей роль admin через SQL Editor.</div>}
    </div>
    {message && <div className="admin-notice">{message}</div>}{error && <div className="admin-error">{error}</div>}
    <small>Список ограничен последними 200 учётными записями. Email показывается только администраторам; прямой клиентский доступ к `auth.users` и `app_user_roles` не предоставляется.</small>
  </section>;
}
