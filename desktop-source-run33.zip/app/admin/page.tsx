"use client";

import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import HomologationImport from "./homologation-import";
import ModelEvidenceManager from "./model-evidence";
import BulkIngestion from "./bulk-ingestion";
import StaffAccessManager from "./staff-access";

type Role = "admin" | "editor" | "reviewer";
type Source = {
  id: string;
  publisher: string;
  title: string;
  source_type: string | null;
  source_url: string | null;
  document_number: string | null;
  revision: string | null;
  permission_status: string;
  license_note: string | null;
  attribution_display_enabled: boolean;
  created_at: string;
};
type Batch = {
  id: string;
  title: string;
  source_id: string | null;
  input_format: string;
  status: string;
  created_by: string;
  created_at: string;
};
type IngestionItem = {
  id: string;
  batch_id: string;
  record_type: string;
  natural_key: string | null;
  payload: Record<string, unknown>;
  validation_errors: unknown[];
  status: string;
  created_by: string;
  reviewed_at: string | null;
  review_note: string | null;
  applied_table: string | null;
  applied_record_id: string | null;
  applied_record_key: string | null;
  import_error: string | null;
  import_attempts: number;
  imported_at: string | null;
  content_review_status: string;
  content_review_note: string | null;
  content_reviewed_by: string | null;
  content_reviewed_at: string | null;
  created_at: string;
};
type AuditEntry = {
  id: number;
  actor_id: string | null;
  event: string;
  table_name: string;
  record_key: string | null;
  created_at: string;
};

const sourcePermissionOptions = [
  ["not_reviewed", "Не проверено"],
  ["permission_required", "Требуется разрешение"],
  ["restricted", "Ограничено"],
  ["user_provided", "Предоставлено пользователем"],
  ["licensed", "Лицензировано"],
  ["public_domain", "Общественное достояние"]
] as const;

const recordTypes = [
  ["vehicle_generation", "Поколение автомобиля"],
  ["engine", "Двигатель"],
  ["transmission", "Трансмиссия"],
  ["ecu_unit", "Блок управления (ECU)"],
  ["vehicle_configuration", "Конфигурация автомобиля"],
  ["technical_document", "Технический документ"],
  ["procedure", "Ремонтная процедура"],
  ["specification", "Спецификация / момент"],
  ["wiring_diagram", "Электросхема / цепь"],
  ["dtc_code", "Код неисправности DTC"],
  ["diagnostic_test", "Диагностический тест-план"],
  ["document_fitment", "Применимость документа к конфигурации"],
  ["procedure_fitment", "Применимость процедуры к конфигурации"]
 ] as const;

const payloadTemplates: Record<string, Record<string, unknown>> = {
  vehicle_generation: { model_id: "REPLACE_WITH_EXISTING_MODEL_UUID", name: "", platform_code: "", source_id: "REPLACE_WITH_LICENSED_SOURCE_UUID" },
  engine: { engine_code: "", engine_family: "", fuel_type: "", displacement_cc: null, power_kw: null, power_hp: null, source_id: "REPLACE_WITH_LICENSED_SOURCE_UUID" },
  transmission: { transmission_code: "", transmission_type: "", gears: null, drive_type: "", source_id: "REPLACE_WITH_LICENSED_SOURCE_UUID" },
  ecu_unit: { manufacturer: "", ecu_family: "", hardware_number: "", software_number: "", ecu_name: "", source_id: "REPLACE_WITH_LICENSED_SOURCE_UUID" },
  vehicle_configuration: { generation_id: "REPLACE_WITH_IMPORTED_GENERATION_UUID", engine_id: null, transmission_id: null, market: "", model_year: null, production_date: null, body_code: "", drive_type: "", pr_codes: [], source_id: "REPLACE_WITH_LICENSED_SOURCE_UUID" },
  technical_document: { source_id: "REPLACE_WITH_LICENSED_SOURCE_UUID", kind: "manual", title: "", language: "en", revision: "", document_date: null, storage_path: "", external_reference: "", summary: "" },
  procedure: { document_id: "REPLACE_WITH_IMPORTED_DOCUMENT_UUID", title: "", objective: "", safety_warnings: [], prerequisites: [], steps: [] },
  specification: { document_id: "REPLACE_WITH_IMPORTED_DOCUMENT_UUID", configuration_id: "REPLACE_WITH_VERIFIED_CONFIGURATION_UUID", system_name: "", component_name: "", parameter_name: "", value_text: "", unit: "", conditions: "" },
  wiring_diagram: { document_id: "REPLACE_WITH_IMPORTED_DOCUMENT_UUID", configuration_id: "REPLACE_WITH_VERIFIED_CONFIGURATION_UUID", system_name: "", component_name: "", connector_id: "", pin_number: "", wire_color: "", wire_function: "", image_storage_path: "" },
  dtc_code: { document_id: "REPLACE_WITH_IMPORTED_DOCUMENT_UUID", code: "", system_name: "", ecu_family: "", description: "", possible_causes: [], diagnostic_notes: "" },
  diagnostic_test: { document_id: "REPLACE_WITH_IMPORTED_DOCUMENT_UUID", configuration_id: "REPLACE_WITH_VERIFIED_CONFIGURATION_UUID", title: "", test_purpose: "", prerequisites: [], test_steps: [], expected_results: [] },
  document_fitment: { document_id: "REPLACE_WITH_IMPORTED_DOCUMENT_UUID", configuration_id: "REPLACE_WITH_VERIFIED_CONFIGURATION_UUID", fitment_note: "" },
  procedure_fitment: { procedure_id: "REPLACE_WITH_IMPORTED_PROCEDURE_UUID", configuration_id: "REPLACE_WITH_VERIFIED_CONFIGURATION_UUID", fitment_note: "" }
};

function dateLabel(value: string) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return "Дата не указана";
  return new Intl.DateTimeFormat("ru-RU", { dateStyle: "medium", timeStyle: "short" }).format(date);
}

function safeHttpUrl(value: string | null | undefined): string | null {
  if (!value) return null;
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:" ? url.href : null;
  } catch {
    return null;
  }
}

function permissionLabel(value: string) {
  return sourcePermissionOptions.find(([key]) => key === value)?.[1] || value;
}

function statusLabel(value: string) {
  const labels: Record<string, string> = {
    open: "Открыт",
    submitted: "Отправлен",
    closed: "Закрыт",
    failed: "Ошибка",
    draft: "Черновик",
    needs_review: "Ожидает проверки",
    accepted_for_import: "Допущен к импорту",
    rejected: "Отклонён",
    applied: "Импортирован · ожидает техпроверки",
    pending: "Ожидает технической проверки",
    verified: "Технически проверено",
  };
  return labels[value] || value;
}

export default function AdminPage() {
  const supabase = useMemo(() => createClient(), []);
  const [loading, setLoading] = useState(true);
  const [roles, setRoles] = useState<Role[]>([]);
  const [userId, setUserId] = useState<string | null>(null);
  const [sources, setSources] = useState<Source[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [items, setItems] = useState<IngestionItem[]>([]);
  const [audit, setAudit] = useState<AuditEntry[]>([]);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const loadSequence = useRef(0);

  const [sourcePublisher, setSourcePublisher] = useState("");
  const [sourceTitle, setSourceTitle] = useState("");
  const [sourceType, setSourceType] = useState("manufacturer_documentation");
  const [sourceUrl, setSourceUrl] = useState("");
  const [sourceNumber, setSourceNumber] = useState("");
  const [sourceRevision, setSourceRevision] = useState("");
  const [sourceLicenseNote, setSourceLicenseNote] = useState("");

  const [batchTitle, setBatchTitle] = useState("");
  const [batchSourceId, setBatchSourceId] = useState("");
  const [itemBatchId, setItemBatchId] = useState("");
  const [itemType, setItemType] = useState("dtc_code");
  const [itemKey, setItemKey] = useState("");
  const [itemPayload, setItemPayload] = useState(JSON.stringify(payloadTemplates.dtc_code, null, 2) ?? "{}");
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [reviewNotes, setReviewNotes] = useState<Record<string, string>>({});
  const [licenseNotes, setLicenseNotes] = useState<Record<string, string>>({});
  const [moderationQuery, setModerationQuery] = useState("");
  const [moderationStatus, setModerationStatus] = useState("all");
  const [technicalQuery, setTechnicalQuery] = useState("");
  const [technicalStatus, setTechnicalStatus] = useState("pending");

  const isAdmin = roles.includes("admin");
  const canEdit = isAdmin || roles.includes("editor");
  const canReview = isAdmin || roles.includes("reviewer");

  const loadWorkspace = useCallback(async () => {
    const sequence = ++loadSequence.current;
    const isCurrent = () => sequence === loadSequence.current;
    if (!supabase) {
      setError("Supabase не подключён. Настройте переменные окружения приложения.");
      setLoading(false);
      return;
    }
    setLoading(true);
    setError("");
    const { data: authData, error: authError } = await supabase.auth.getUser();
    if (!isCurrent()) return;
    if (authError) {
      setUserId(null);
      setRoles([]);
      setError(`Не удалось проверить сессию: ${authError.message}`);
      setLoading(false);
      return;
    }
    const currentUserId = authData.user?.id || null;
    setUserId(currentUserId);
    if (!currentUserId) {
      setRoles([]);
      setSources([]); setBatches([]); setItems([]); setAudit([]);
      setError("Для доступа к панели войдите в VAG TECH PRO.");
      setLoading(false);
      return;
    }
    const { data: roleData, error: roleError } = await supabase.rpc("get_my_app_roles");
    if (!isCurrent()) return;
    const roleList = Array.isArray(roleData) ? roleData.filter((x): x is Role => ["admin", "editor", "reviewer"].includes(x)) : [];
    setRoles(roleList);
    if (roleError) {
      setError(`Не удалось проверить роль: ${roleError.message}`);
      setLoading(false);
      return;
    }
    if (!roleList.length) {
      setSources([]); setBatches([]); setItems([]); setAudit([]);
      setLoading(false);
      return;
    }

    const [sourceResult, batchResult, itemResult, auditResult] = await Promise.all([
      supabase.from("sources").select("id,publisher,title,source_type,source_url,document_number,revision,permission_status,license_note,attribution_display_enabled,created_at").order("created_at", { ascending: false }).limit(100),
      supabase.from("ingestion_batches").select("id,title,source_id,input_format,status,created_by,created_at").order("created_at", { ascending: false }).limit(50),
      supabase.from("ingestion_items").select("id,batch_id,record_type,natural_key,payload,validation_errors,status,created_by,reviewed_at,review_note,applied_table,applied_record_id,applied_record_key,import_error,import_attempts,imported_at,content_review_status,content_review_note,content_reviewed_by,content_reviewed_at,created_at").order("created_at", { ascending: false }).limit(100),
      supabase.from("admin_audit_log").select("id,actor_id,event,table_name,record_key,created_at").order("created_at", { ascending: false }).limit(40)
    ]);
    if (!isCurrent()) return;
    const failed = [sourceResult, batchResult, itemResult, auditResult].find((result) => result.error);
    if (failed?.error) setError(`Ошибка загрузки панели: ${failed.error.message}`);
    setSources((sourceResult.data || []) as Source[]);
    setLicenseNotes((current) => Object.fromEntries(((sourceResult.data || []) as Source[]).map((source) => [source.id, current[source.id] ?? source.license_note ?? ""])));
    setBatches((batchResult.data || []) as Batch[]);
    setItems((itemResult.data || []) as IngestionItem[]);
    setAudit((auditResult.data || []) as AuditEntry[]);
    setLoading(false);
  }, [supabase]);

  useEffect(() => {
    let active = true;
    void loadWorkspace();
    const authSubscription = supabase?.auth.onAuthStateChange(() => {
      if (active) window.setTimeout(() => { if (active) void loadWorkspace(); }, 0);
    });
    return () => {
      active = false;
      loadSequence.current += 1;
      authSubscription?.data.subscription.unsubscribe();
    };
  }, [loadWorkspace, supabase]);

  async function createSource(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase || !userId) return;
    const normalizedSourceUrl = sourceUrl.trim();
    if (normalizedSourceUrl && !safeHttpUrl(normalizedSourceUrl)) {
      setError("Ссылка на источник должна быть корректным HTTP/HTTPS-адресом.");
      return;
    }
    setBusy(true);
    setNotice("");
    setError("");
    const { error: insertError } = await supabase.from("sources").insert({
      publisher: sourcePublisher.trim(),
      title: sourceTitle.trim(),
      source_type: sourceType,
      source_url: normalizedSourceUrl ? safeHttpUrl(normalizedSourceUrl) : null,
      document_number: sourceNumber.trim() || null,
      revision: sourceRevision.trim() || null,
      permission_status: "not_reviewed",
      license_note: sourceLicenseNote.trim() || null,
      created_by: userId
    });
    if (insertError) setError(`Источник не сохранён: ${insertError.message}`);
    else {
      setNotice("Источник добавлен со статусом «Не проверено». Он не будет использоваться для публичной выдачи.");
      setSourcePublisher(""); setSourceTitle(""); setSourceUrl(""); setSourceNumber(""); setSourceRevision(""); setSourceLicenseNote("");
      await loadWorkspace();
    }
    setBusy(false);
  }

  async function saveSourceLicenseNote(source: Source) {
    if (!supabase || !isAdmin) return;
    setBusy(true); setError(""); setNotice("");
    const note = (licenseNotes[source.id] ?? "").trim();
    const { error: updateError } = await supabase.from("sources").update({ license_note: note || null }).eq("id", source.id);
    if (updateError) setError(`Основание прав не сохранено: ${updateError.message}`);
    else { setNotice("Основание прав источника сохранено."); await loadWorkspace(); }
    setBusy(false);
  }

  async function updateSourcePermission(source: Source, permissionStatus: string) {
    if (!supabase || !isAdmin) return;
    const licenseNote = (licenseNotes[source.id] ?? source.license_note ?? "").trim();
    if (["licensed", "public_domain"].includes(permissionStatus) && licenseNote.length < 20) {
      setError("Для разрешённого статуса требуется документальное основание не короче 20 символов: договор/лицензия, право хранения и показа, ограничения и срок действия.");
      return;
    }
    setBusy(true); setError(""); setNotice("");
    const { error: updateError } = await supabase.from("sources").update({ permission_status: permissionStatus, license_note: licenseNote || null }).eq("id", source.id);
    if (updateError) setError(`Статус источника не изменён: ${updateError.message}`);
    else {
      setNotice(`Статус источника «${source.title}» обновлён. Основание лицензии хранится в карточке источника.`);
      await loadWorkspace();
    }
    setBusy(false);
  }

  async function createBatch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase || !userId) return;
    setBusy(true); setError(""); setNotice("");
    const { data, error: insertError } = await supabase.from("ingestion_batches").insert({
      title: batchTitle.trim(),
      source_id: batchSourceId || null,
      input_format: "manual",
      created_by: userId
    }).select("id").single();
    if (insertError) setError(`Пакет не создан: ${insertError.message}`);
    else {
      setBatchTitle("");
      setItemBatchId(data.id);
      setNotice("Пакет импорта создан.");
      await loadWorkspace();
    }
    setBusy(false);
  }

  async function createItem(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase || !userId) return;
    if (new TextEncoder().encode(itemPayload).byteLength > 256 * 1024) {
      setError("Payload превышает лимит 256 КБ. Разделите запись на несколько элементов.");
      return;
    }
    if (itemKey.trim().length > 180) {
      setError("Ключ записи не должен превышать 180 символов.");
      return;
    }
    let payload: unknown;
    try {
      payload = JSON.parse(itemPayload);
    } catch {
      setError("Payload должен быть корректным JSON.");
      return;
    }
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
      setError("Корневой элемент payload должен быть JSON-объектом.");
      return;
    }
    setBusy(true); setError(""); setNotice("");
    const write = editingItemId
      ? await supabase.from("ingestion_items").update({
          batch_id: itemBatchId,
          record_type: itemType,
          natural_key: itemKey.trim() || null,
          payload
        }).eq("id", editingItemId).select("id").single()
      : await supabase.from("ingestion_items").insert({
          batch_id: itemBatchId,
          record_type: itemType,
          natural_key: itemKey.trim() || null,
          payload,
          created_by: userId,
          status: "draft"
        }).select("id").single();
    if (write.error) setError(`Элемент не сохранён: ${write.error.message}`);
    else if (write.data?.id) {
      setNotice(editingItemId ? "Черновик обновлён. Запускаю повторную проверку." : "Черновик добавлен. Запускаю серверную проверку.");
      await submitItem(write.data.id);
    }
    setBusy(false);
  }

  async function submitItem(itemId: string) {
    if (!supabase) return;
    const { data, error: submitError } = await supabase.rpc("submit_ingestion_item", { p_item_id: itemId });
    if (submitError) {
      setError(`Не удалось отправить элемент на проверку: ${submitError.message}`);
      return;
    }
    const result = data as { status?: string; errors?: unknown[] } | null;
    if (result?.status === "needs_review") {
      setEditingItemId(null);
      setNotice("Проверка структуры пройдена. Элемент помещён в очередь модерации.");
    } else setError(`Элемент остался черновиком. Ошибки проверки: ${(result?.errors || []).map(String).join("; ") || "неизвестная ошибка"}`);
    await loadWorkspace();
  }

  function editDraft(item: IngestionItem) {
    setEditingItemId(item.id);
    setItemBatchId(item.batch_id);
    setItemType(item.record_type);
    setItemKey(item.natural_key || "");
    setItemPayload(JSON.stringify(item.payload, null, 2));
    setNotice("Черновик загружен в форму. После изменения он повторно пройдёт серверную проверку.");
    document.getElementById("ingestion")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function reviewItem(itemId: string, decision: "accept" | "reject") {
    if (!supabase) return;
    setBusy(true); setError(""); setNotice("");
    const { data, error: reviewError } = await supabase.rpc("review_ingestion_item", {
      p_item_id: itemId,
      p_decision: decision,
      p_note: reviewNotes[itemId] || null
    });
    if (reviewError) setError(`Решение не сохранено: ${reviewError.message}`);
    else {
      const result = data as { status?: string } | null;
      setNotice(decision === "accept"
        ? `Элемент принят: ${statusLabel(result?.status || "accepted_for_import")}. Публикации в ремонтном поиске не произошло.`
        : "Элемент отклонён; решение записано в аудит.");
      await loadWorkspace();
    }
    setBusy(false);
  }

  async function importItem(itemId: string) {
    if (!supabase || !isAdmin) return;
    setBusy(true); setError(""); setNotice("");
    const { data, error: importError } = await supabase.rpc("import_ingestion_item", { p_item_id: itemId });
    if (importError) {
      setError(`Импорт не выполнен: ${importError.message}`);
    } else {
      const result = data as { status?: string; imported?: boolean; already_applied?: boolean; table?: string; record_key?: string; error?: string } | null;
      if (result?.status === "applied") {
        setNotice(result.already_applied
          ? "Эта запись уже была импортирована. Повторная вставка не выполнялась."
          : `Запись перенесена в ${result.table || "рабочий каталог"} (${result.record_key || "ID сохранён"}). Статус содержимого — «Ожидает технической проверки», публичный поиск её пока не показывает.`);
      } else {
        setError(`Импорт отложен; элемент остаётся допущенным к импорту. ${result?.error || "Проверьте зависимости, формат полей и уникальность записи."}`);
      }
      await loadWorkspace();
    }
    setBusy(false);
  }

  async function reviewImportedItem(itemId: string, decision: "verify" | "reject") {
    if (!supabase || !canReview) return;
    const note = (reviewNotes[itemId] || "").trim();
    if (decision === "verify" && note.length < 20) {
      setError("Для подтверждения технических данных укажите основание проверки не короче 20 символов: документ, раздел, ревизию и проверенную применимость.");
      return;
    }
    setBusy(true); setError(""); setNotice("");
    const { data, error: reviewError } = await supabase.rpc("review_imported_item", {
      p_item_id: itemId,
      p_decision: decision,
      p_note: note || null
    });
    if (reviewError) {
      setError(`Техническая проверка не завершена: ${reviewError.message}. Проверьте сначала источник и зависимости автомобиля/документа.`);
    } else {
      const result = data as { status?: string; already_reviewed?: boolean; record_type?: string } | null;
      setNotice(result?.already_reviewed
        ? `Эта запись уже прошла техническую проверку: ${statusLabel(result.status || "verified")}.`
        : decision === "verify"
          ? `Запись ${result?.record_type || "каталога"} подтверждена. Её можно показывать только при совпадении проверенной конфигурации и разрешённого источника.`
          : "Запись отклонена; она останется скрытой из публичного ремонта.");
      await loadWorkspace();
    }
    setBusy(false);
  }

  const sourceById = useMemo(() => new Map(sources.map((source) => [source.id, source])), [sources]);
  const moderationItems = useMemo(() => {
    const query = moderationQuery.trim().toLocaleLowerCase();
    return items.filter((item) => item.status !== "applied")
      .filter((item) => moderationStatus === "all" || item.status === moderationStatus)
      .filter((item) => !query || [item.record_type, item.natural_key, item.id, JSON.stringify(item.payload), item.import_error].filter(Boolean).join(" ").toLocaleLowerCase().includes(query));
  }, [items, moderationQuery, moderationStatus]);
  const technicalItems = useMemo(() => {
    const query = technicalQuery.trim().toLocaleLowerCase();
    return items.filter((item) => item.status === "applied")
      .filter((item) => technicalStatus === "all" || item.content_review_status === technicalStatus)
      .filter((item) => !query || [item.record_type, item.natural_key, item.applied_record_key, item.applied_table, item.id, JSON.stringify(item.payload)].filter(Boolean).join(" ").toLocaleLowerCase().includes(query));
  }, [items, technicalQuery, technicalStatus]);
  const batchById = useMemo(() => new Map(batches.map((batch) => [batch.id, batch])), [batches]);
  const payloadPreview = useMemo(() => {
    const bytes = new TextEncoder().encode(itemPayload).byteLength;
    try {
      const parsed: unknown = JSON.parse(itemPayload);
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        return { bytes, valid: false, fields: [] as string[], note: "Корнем должен быть JSON-объект." };
      }
      return { bytes, valid: true, fields: Object.keys(parsed as Record<string, unknown>).sort(), note: "Синтаксис JSON корректен. Серверная проверка обязательных полей и ссылок ещё не выполнена." };
    } catch {
      return { bytes, valid: false, fields: [] as string[], note: "JSON пока не разбирается." };
    }
  }, [itemPayload]);

  if (loading) return <main className="admin-shell"><div className="admin-loading">Проверка доступа и загрузка рабочего пространства…</div></main>;

  if (!roles.length) return <main className="admin-shell">
    <header className="admin-top"><Link href="/" className="admin-brand">VAG TECH <em>PRO</em></Link><span>Защищённая зона</span></header>
    <section className="admin-denied">
      <div className="admin-lock">⌑</div>
      <h1>{userId ? "Нет административной роли" : "Требуется вход"}</h1>
      <p>{userId
        ? "Учётная запись не включена в список сотрудников VAG TECH PRO. Роли выдаются владельцем проекта через доверенную административную процедуру; самостоятельно повысить привилегии здесь нельзя."
        : "Войдите в основное приложение, затем откройте панель управления."}</p>
      <Link className="admin-primary" href={userId ? "/" : "/login"}>{userId ? "Вернуться в приложение" : "Перейти ко входу"}</Link>
      {error && <p className="admin-error">{error}</p>}
    </section>
  </main>;

  return <main className="admin-shell">
    <header className="admin-top">
      <Link href="/" className="admin-brand">VAG TECH <em>PRO</em></Link>
      <div className="admin-top-meta"><span className="admin-secure">● Защищённая зона</span><span>{roles.join(" · ")}</span><Link href="/">Рабочее место ↗</Link></div>
    </header>
    <div className="admin-layout">
      <aside className="admin-sidebar">
        <div className="admin-kicker">CONTROL CENTER</div>
        <h1>Управление базой</h1>
        <p>Источники, импорт, проверка и аудит технических данных.</p>
        <div className="admin-nav"><a href="#staff-access">01　Сотрудники и роли</a><a href="#sources">02　Источники</a><a href="#model-evidence">03　Доказательства моделей</a><a href="#homologation">04　Омологация EEA</a><a href="#ingestion">05　Импорт</a><a href="#review">06　Модерация</a><a href="#technical-review">07　Техпроверка</a><a href="#audit">08　Журнал аудита</a></div>
        <div className="admin-role-card"><small>ТЕКУЩИЕ ПОЛНОМОЧИЯ</small><strong>{roles.join(" / ")}</strong><span>Права дополнительно ограничены RLS на уровне базы данных.</span></div>
      </aside>
      <section className="admin-content">
        {error && <div className="admin-alert error">{error}</div>}
        {notice && <div className="admin-alert success">{notice}</div>}

        <StaffAccessManager roles={roles} />

        <section className="admin-section" id="sources">
          <div className="admin-section-head"><div><div className="admin-kicker">SOURCE GOVERNANCE</div><h2>Реестр источников</h2><p>Ни один источник не считается разрешённым только по факту добавления.</p></div><span className="admin-count">{sources.length} источников</span></div>
          <div className="admin-source-list">
            {sources.length === 0 ? <div className="admin-empty">Источники ещё не добавлены.</div> : sources.map((source) => <article className="admin-source" key={source.id}>
              <div className="admin-source-main"><strong>{source.publisher} · {source.title}</strong><span>{[source.document_number, source.revision, source.source_type].filter(Boolean).join(" · ") || "Без номера и ревизии"}</span>{safeHttpUrl(source.source_url) && <a href={safeHttpUrl(source.source_url)!} target="_blank" rel="noopener noreferrer">Открыть источник ↗</a>}{source.license_note && <small>Основание: {source.license_note}</small>}</div>
              <div className="admin-source-status"><span className={`admin-status ${source.permission_status === "licensed" || source.permission_status === "public_domain" ? "verified" : "pending"}`}>{permissionLabel(source.permission_status)}</span>
                {isAdmin && <><textarea aria-label={`Основание прав источника ${source.title}`} rows={2} value={licenseNotes[source.id] ?? source.license_note ?? ""} onChange={(event) => setLicenseNotes((current) => ({ ...current, [source.id]: event.target.value }))} placeholder="Основание (мин. 20 символов): договор/лицензия, право хранения и показа, ограничения и срок действия" /><button className="admin-secondary" type="button" disabled={busy} onClick={() => void saveSourceLicenseNote(source)}>Сохранить основание</button><select aria-label={`Правовой статус источника ${source.title}`} value={source.permission_status} disabled={busy} onChange={(event) => void updateSourcePermission(source, event.target.value)}>{sourcePermissionOptions.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></>}
              </div>
            </article>)}
          </div>
          {canEdit && <form className="admin-form" onSubmit={createSource}>
            <div className="admin-form-title">Добавить источник</div>
            <div className="admin-form-grid">
              <label>Издатель<input required value={sourcePublisher} onChange={(e) => setSourcePublisher(e.target.value)} placeholder="Например, производитель" /></label>
              <label>Название / документ<input required value={sourceTitle} onChange={(e) => setSourceTitle(e.target.value)} placeholder="Название публикации" /></label>
              <label>Тип источника<input value={sourceType} onChange={(e) => setSourceType(e.target.value)} placeholder="manufacturer_documentation" /></label>
              <label>URL<input type="url" value={sourceUrl} onChange={(e) => setSourceUrl(e.target.value)} placeholder="https://…" /></label>
              <label>Номер документа<input value={sourceNumber} onChange={(e) => setSourceNumber(e.target.value)} /></label>
              <label>Ревизия<input value={sourceRevision} onChange={(e) => setSourceRevision(e.target.value)} /></label>
              <label className="wide">Основание прав / примечание<textarea value={sourceLicenseNote} onChange={(e) => setSourceLicenseNote(e.target.value)} placeholder="Договор, лицензия, условия отображения и кэширования. Не указывайте предположения." rows={2} /></label>
            </div>
            <div className="admin-form-foot"><span>Статус нового источника всегда «Не проверено».</span><button className="admin-primary" disabled={busy}>Сохранить источник</button></div>
          </form>}
        </section>

        <ModelEvidenceManager sources={sources} roles={roles} />
        <HomologationImport sources={sources} roles={roles} />

        <section className="admin-section" id="ingestion">
          <div className="admin-section-head"><div><div className="admin-kicker">CONTROLLED INGESTION</div><h2>Пакеты и черновики импорта</h2><p>Поддерживаются пакетный JSON dry-run до 100 записей, ручной JSON-ввод, серверная проверка, модерация и типизированный перенос принятой записи в рабочую таблицу. CSV-парсер пока не включён.</p></div><span className="admin-count">{batches.length} пакетов · {items.length} элементов</span></div>
          <BulkIngestion sources={sources} roles={roles} onComplete={loadWorkspace} />
          {canEdit && <div className="admin-two-col">
            <form className="admin-form" onSubmit={createBatch}>
              <div className="admin-form-title">Новый пакет</div>
              <label>Название пакета<input required minLength={3} maxLength={180} value={batchTitle} onChange={(e) => setBatchTitle(e.target.value)} placeholder="Например, DTC — EA888 Gen 3" /></label>
              <label>Основной источник<select value={batchSourceId} onChange={(e) => setBatchSourceId(e.target.value)}><option value="">Не выбран — источник задаётся в payload</option>{sources.map((source) => <option key={source.id} value={source.id}>{source.publisher} · {source.title} ({permissionLabel(source.permission_status)})</option>)}</select></label>
              <div className="admin-form-foot"><span>Создатель и время фиксируются автоматически.</span><button className="admin-primary" disabled={busy}>Создать пакет</button></div>
            </form>
            <form className="admin-form" onSubmit={createItem}>
              <div className="admin-form-title">{editingItemId ? "Редактировать JSON-черновик" : "Добавить JSON-элемент"}</div>
              <label>Пакет<select required value={itemBatchId} onChange={(e) => setItemBatchId(e.target.value)}><option value="">Выберите открытый пакет</option>{batches.filter((batch) => batch.status === "open" && (batch.created_by === userId || isAdmin)).map((batch) => <option key={batch.id} value={batch.id}>{batch.title}</option>)}</select></label>
              <label>Тип записи<select value={itemType} onChange={(e) => setItemType(e.target.value)}>{recordTypes.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
              <button className="admin-secondary" type="button" disabled={busy} onClick={() => setItemPayload(JSON.stringify(payloadTemplates[itemType] || {}, null, 2) ?? "{}")}>Вставить шаблон JSON для выбранного типа</button>
              <small>Шаблон содержит UUID-заглушки. Замените их реальными ID из каталога; шаблон не является техническими данными.</small>
              <label>Ключ записи<input value={itemKey} onChange={(e) => setItemKey(e.target.value)} placeholder="Например, P0299 / EA888-CJZA" /></label>
              <label>Payload JSON<textarea className="admin-json" required spellCheck={false} rows={9} value={itemPayload} onChange={(e) => setItemPayload(e.target.value)} /></label>
              <div className={`admin-payload-preview ${payloadPreview.valid && payloadPreview.bytes <= 256 * 1024 ? "is-valid" : "is-invalid"}`}><strong>{payloadPreview.valid ? "Локальный разбор: корректен" : "Локальный разбор: ошибка"}</strong><span>{(payloadPreview.bytes / 1024).toFixed(1)} КБ / 256 КБ · {payloadPreview.fields.length} полей</span><small>{payloadPreview.note}</small>{payloadPreview.fields.length > 0 && <code>{payloadPreview.fields.join(" · ")}</code>}</div>
              <div className="admin-form-foot"><span>Лимит payload: 256 КБ. Отправка запускает серверную проверку обязательных полей.</span><button className="admin-primary" disabled={busy || !itemBatchId || !payloadPreview.valid || payloadPreview.bytes > 256 * 1024}>{editingItemId ? "Сохранить и проверить" : "Создать и проверить"}</button></div>
            </form>
          </div>}
          <div className="admin-batch-list">
            {batches.map((batch) => <div className="admin-batch" key={batch.id}><div><strong>{batch.title}</strong><span>{dateLabel(batch.created_at)} · {batch.input_format} · {sourceById.get(batch.source_id || "")?.title || "Источник в элементах"}</span></div><span className="admin-status">{statusLabel(batch.status)}</span></div>)}
            {!batches.length && <div className="admin-empty">Пакетов импорта пока нет.</div>}
          </div>
        </section>

        <section className="admin-section" id="review">
          <div className="admin-section-head"><div><div className="admin-kicker">QUALITY GATE</div><h2>Очередь модерации</h2><p>Принятие допускает запись к типизированному импорту. Импортированные сведения остаются в статусе «Ожидает технической проверки» и не публикуются автоматически.</p></div><span className="admin-count">{items.filter((item) => item.status === "needs_review").length} ожидают</span></div>
          <div className="admin-queue-filters"><input aria-label="Поиск по очереди модерации" value={moderationQuery} onChange={(event) => setModerationQuery(event.target.value)} placeholder="Найти по типу, ключу или payload…" /><select aria-label="Статус модерации" value={moderationStatus} onChange={(event) => setModerationStatus(event.target.value)}><option value="all">Все статусы</option><option value="draft">Черновики</option><option value="needs_review">Ожидают модерации</option><option value="accepted_for_import">Допущены к импорту</option><option value="rejected">Отклонены</option></select><span>{moderationItems.length} из {items.filter((item) => item.status !== "applied").length}</span></div>
          <div className="admin-item-list">
            {moderationItems.length === 0 ? <div className="admin-empty">По заданным фильтрам элементов нет.</div> : moderationItems.map((item) => <article className="admin-item" key={item.id}>
              <div className="admin-item-head"><div><strong>{recordTypes.find(([value]) => value === item.record_type)?.[1] || item.record_type}</strong><span>{item.natural_key || item.id} · пакет: {batchById.get(item.batch_id)?.title || item.batch_id}</span></div><span className={`admin-status ${item.status === "accepted_for_import" ? "verified" : item.status === "needs_review" ? "pending" : ""}`}>{statusLabel(item.status)}</span></div>
              <details><summary>Показать payload и ошибки проверки</summary><pre>{JSON.stringify(item.payload, null, 2)}</pre>{item.validation_errors.length > 0 && <pre className="admin-validation">{JSON.stringify(item.validation_errors, null, 2)}</pre>}{item.review_note && <p className="admin-review-note">Комментарий: {item.review_note}</p>}{item.import_error && <p className="admin-validation">Ошибка импорта: {item.import_error} · попыток: {item.import_attempts}</p>}{item.status === "applied" && <p className="admin-review-note">Рабочая таблица: {item.applied_table || "—"} · запись: {item.applied_record_key || item.applied_record_id || "—"}{item.imported_at ? ` · ${dateLabel(item.imported_at)}` : ""}</p>}</details>
              {isAdmin && item.status === "accepted_for_import" && <div className="admin-review-actions"><span>Импорт создаст запись только со статусом «Ожидает технической проверки».</span><button disabled={busy} onClick={() => void importItem(item.id)} className="admin-primary">Импортировать в каталог</button></div>}
              {canReview && item.status === "needs_review" && <div className="admin-review-actions"><input value={reviewNotes[item.id] || ""} onChange={(e) => setReviewNotes((current) => ({ ...current, [item.id]: e.target.value }))} placeholder="Комментарий модератора (необязательно)" /><button disabled={busy} onClick={() => void reviewItem(item.id, "reject")} className="admin-danger">Отклонить</button><button disabled={busy} onClick={() => void reviewItem(item.id, "accept")} className="admin-primary">Допустить к импорту</button></div>}
              {canEdit && item.status === "draft" && item.created_by === userId && <div className="admin-review-actions"><span>Черновик можно исправить и отправить повторно.</span><button disabled={busy} onClick={() => editDraft(item)} className="admin-secondary">Редактировать</button><button disabled={busy} onClick={() => void submitItem(item.id)} className="admin-primary">Повторить проверку</button></div>}
            </article>)}
          </div>
        </section>

        <section className="admin-section" id="technical-review">
          <div className="admin-section-head"><div><div className="admin-kicker">TECHNICAL VERIFICATION</div><h2>Техническая проверка каталога</h2><p>Подтверждение выполняется по зависимостям: сначала источник и конфигурация, затем точная привязка, документ и дочерние технические записи. Ошибка зависимости не меняет статус записи.</p></div><span className="admin-count">{items.filter((item) => item.status === "applied" && item.content_review_status === "pending").length} ожидают</span></div>
          <div className="admin-queue-filters"><input aria-label="Поиск по технической проверке" value={technicalQuery} onChange={(event) => setTechnicalQuery(event.target.value)} placeholder="Найти по типу, ключу или payload…" /><select aria-label="Статус технической проверки" value={technicalStatus} onChange={(event) => setTechnicalStatus(event.target.value)}><option value="pending">Ожидают проверки</option><option value="verified">Подтверждены</option><option value="rejected">Отклонены</option><option value="all">Все статусы</option></select><span>{technicalItems.length} из {items.filter((item) => item.status === "applied").length}</span></div>
          <div className="admin-item-list">
            {technicalItems.length === 0 ? <div className="admin-empty">По заданным фильтрам импортированных записей нет.</div> : technicalItems.map((item) => <article className="admin-item" key={item.id}>
              <div className="admin-item-head"><div><strong>{recordTypes.find(([value]) => value === item.record_type)?.[1] || item.record_type}</strong><span>{item.natural_key || item.applied_record_key || item.applied_record_id || item.id} · {item.applied_table || "—"}</span></div><span className={`admin-status ${item.content_review_status === "verified" ? "verified" : item.content_review_status === "pending" ? "pending" : ""}`}>{item.content_review_status === "rejected" ? "Отклонено техпроверкой" : statusLabel(item.content_review_status)}</span></div>
              <details><summary>Payload и результат импорта</summary><pre>{JSON.stringify(item.payload, null, 2)}</pre>{item.content_review_note && <p className="admin-review-note">Комментарий техпроверки: {item.content_review_note}</p>}{item.content_reviewed_at && <p className="admin-review-note">Проверено: {dateLabel(item.content_reviewed_at)} · {item.content_reviewed_by || "—"}</p>}</details>
              {canReview && item.content_review_status === "pending" && <div className="admin-review-actions"><input required minLength={20} value={reviewNotes[item.id] || ""} onChange={(e) => setReviewNotes((current) => ({ ...current, [item.id]: e.target.value }))} placeholder="Основание проверки: документ, раздел, ревизия, применимость (мин. 20 символов)" /><button disabled={busy} onClick={() => void reviewImportedItem(item.id, "reject")} className="admin-danger">Отклонить</button><button disabled={busy} onClick={() => void reviewImportedItem(item.id, "verify")} className="admin-primary">Подтвердить данные</button></div>}
            </article>)}
          </div>
        </section>

        <section className="admin-section" id="audit">
          <div className="admin-section-head"><div><div className="admin-kicker">IMMUTABLE EVENT TRAIL</div><h2>Журнал аудита</h2><p>События изменений источников, каталога, контента, ролей и staging.</p></div><span className="admin-count">Последние {audit.length}</span></div>
          <div className="admin-audit-list">
            {audit.map((entry) => <div className="admin-audit-row" key={entry.id}><time>{dateLabel(entry.created_at)}</time><strong>{entry.event}</strong><span>{entry.table_name}</span><code>{entry.record_key || "—"}</code><small>{entry.actor_id || "Системный / SQL Editor"}</small></div>)}
            {!audit.length && <div className="admin-empty">Событий аудита пока нет.</div>}
          </div>
        </section>
        <footer className="admin-footer">VAG TECH PRO · Импортированные сведения остаются needs_review до отдельной технической проверки, проверки источника и подтверждения точной применимости.</footer>
      </section>
    </div>
  </main>;
}
