"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { parseCsvBatch } from "@/lib/technical-batch-csv.cjs";

type Role = "admin" | "editor" | "reviewer";
type Source = { id: string; publisher: string; title: string; permission_status: string };
type NaturalKeyReference = { field: string; record_type: string; natural_key: string; target_item_index: number | null };
type BatchItem = { index: number; record_type: string; natural_key: string | null; payload: Record<string, unknown>; references: NaturalKeyReference[] };
type ReferenceResolution = { field: string; target_record_type: string; target_natural_key: string; target_item_id: string; target_record_id: string; target_table: string };
type PreparedItem = { index: number; record_type: string; natural_key: string | null; payload: Record<string, unknown>; reference_resolution: ReferenceResolution[]; existing_item_id?: string | null };
type PreviewResult = { index: number; record_type: string | null; natural_key: string | null; status: string; errors: string[] };
type Preview = { status: string; total: number; valid: number; invalid: number; source_permission: string; validation_scope: string; limitations: string; results: PreviewResult[] };
type SubmitResult = { status?: string; batch_id?: string; total?: number; submitted?: number; rejected?: number; results?: PreviewResult[] };
type DependencyBlock = { index: number; field: string; record_type: string; natural_key: string; reason: string };
type DependencySummary = { ready: number; blocked: DependencyBlock[]; issues: Array<{ index: number; message: string }>; alreadyStaged: Array<{ index: number; status: string }>; warnings: string[]; reusedBatchId: string | null };
type ExistingBatch = { id: string; status: string; input_format: string; source_id: string | null; source_version: string | null; created_by: string };
type ExistingItem = { id: string; batch_id: string; record_type: string; natural_key: string | null; payload: Record<string, unknown>; reference_resolution: ReferenceResolution[]; status: string; applied_table: string | null; applied_record_id: string | null; content_review_status: string };

const MAX_FILE_BYTES = 2 * 1024 * 1024;
const MAX_ITEMS = 100;
const ALLOWED_TYPES = new Set([
  "vehicle_generation", "engine", "transmission", "ecu_unit", "vehicle_configuration",
  "technical_document", "procedure", "specification", "wiring_diagram", "dtc_code",
  "diagnostic_test", "document_fitment", "procedure_fitment"
]);
const REFERENCE_TARGET_TYPES: Record<string, Record<string, string>> = {
  vehicle_configuration: { generation_id: "vehicle_generation", engine_id: "engine", transmission_id: "transmission", ecu_id: "ecu_unit" },
  procedure: { document_id: "technical_document" },
  specification: { document_id: "technical_document", configuration_id: "vehicle_configuration" },
  wiring_diagram: { document_id: "technical_document", configuration_id: "vehicle_configuration" },
  dtc_code: { document_id: "technical_document" },
  diagnostic_test: { document_id: "technical_document", configuration_id: "vehicle_configuration" },
  document_fitment: { document_id: "technical_document", configuration_id: "vehicle_configuration" },
  procedure_fitment: { procedure_id: "procedure", configuration_id: "vehicle_configuration" }
};
const REFERENCE_TABLES: Record<string, string> = {
  vehicle_generation: "vehicle_generations", engine: "engines", transmission: "transmissions", ecu_unit: "ecu_units",
  vehicle_configuration: "vehicle_configurations", technical_document: "technical_documents", procedure: "procedures"
};

async function digestFile(file: File): Promise<string> {
  const digest = await globalThis.crypto.subtle.digest("SHA-256", await file.arrayBuffer());
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonical(record[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function containsReference(value: unknown): boolean {
  if (Array.isArray(value)) return value.some(containsReference);
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    if (Object.hasOwn(record, "$ref")) return true;
    return Object.values(record).some(containsReference);
  }
  return false;
}

function parseBatch(value: unknown): { items: BatchItem[]; sourceVersion: string } {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Корень JSON должен быть объектом.");
  const root = value as Record<string, unknown>;
  const extra = Object.keys(root).filter((key) => !["items", "source_version"].includes(key));
  if (extra.length) throw new Error(`Неизвестные поля пакета: ${extra.join(", ")}.`);
  if (!Array.isArray(root.items) || root.items.length < 1 || root.items.length > MAX_ITEMS) throw new Error(`Пакет должен содержать от 1 до ${MAX_ITEMS} элементов.`);
  if (root.source_version !== undefined && (typeof root.source_version !== "string" || root.source_version.length > 80 || root.source_version !== root.source_version.trim() || /[\u0000-\u001F\u007F]/.test(root.source_version))) throw new Error("source_version должен быть строкой до 80 символов без пробелов по краям и управляющих символов.");
  const items = root.items.map((raw, index): BatchItem => {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new Error(`items[${index}]: ожидается объект.`);
    const item = raw as Record<string, unknown>;
    const extraItem = Object.keys(item).filter((key) => !["record_type", "natural_key", "payload"].includes(key));
    if (extraItem.length) throw new Error(`items[${index}]: неизвестные поля ${extraItem.join(", ")}.`);
    if (typeof item.record_type !== "string" || !ALLOWED_TYPES.has(item.record_type)) throw new Error(`items[${index}]: неизвестный тип записи.`);
    if (!item.payload || typeof item.payload !== "object" || Array.isArray(item.payload)) throw new Error(`items[${index}]: payload должен быть JSON-объектом.`);
    if (item.natural_key !== undefined && item.natural_key !== null && (typeof item.natural_key !== "string" || !item.natural_key.trim() || item.natural_key.length > 180 || item.natural_key !== item.natural_key.trim() || /[\u0000-\u001F\u007F]/.test(item.natural_key))) throw new Error(`items[${index}]: natural_key должен быть непустой строкой до 180 символов без пробелов по краям и управляющих символов.`);
    const payload = item.payload as Record<string, unknown>;
    const references: NaturalKeyReference[] = [];
    for (const [field, fieldValue] of Object.entries(payload)) {
      const isReference = !!fieldValue && typeof fieldValue === "object" && !Array.isArray(fieldValue) && Object.hasOwn(fieldValue as object, "$ref");
      if (isReference) {
        const expectedTargetType = REFERENCE_TARGET_TYPES[item.record_type]?.[field];
        const wrapper = fieldValue as Record<string, unknown>;
        const reference = wrapper.$ref;
        const referenceRecord = reference && typeof reference === "object" && !Array.isArray(reference) ? reference as Record<string, unknown> : null;
        const validShape = Object.keys(wrapper).length === 1 && referenceRecord !== null
          && Object.keys(referenceRecord).length === 2 && Object.hasOwn(referenceRecord, "record_type") && Object.hasOwn(referenceRecord, "natural_key");
        if (!expectedTargetType) throw new Error(`items[${index}]: поле ${field} не поддерживает ссылку {$ref} для типа ${item.record_type}.`);
        if (!validShape) throw new Error(`items[${index}]: ${field} должен содержать {$ref:{record_type,natural_key}} без дополнительных полей.`);
        if (referenceRecord.record_type !== expectedTargetType) throw new Error(`items[${index}]: недопустимый тип цели $ref для ${item.record_type}.${field}; ожидается ${expectedTargetType}.`);
        if (typeof referenceRecord.natural_key !== "string" || !referenceRecord.natural_key.trim() || referenceRecord.natural_key.length > 180 || referenceRecord.natural_key !== referenceRecord.natural_key.trim() || /[\u0000-\u001F\u007F]/.test(referenceRecord.natural_key)) throw new Error(`items[${index}]: natural_key внутри $ref некорректен.`);
        references.push({ field, record_type: referenceRecord.record_type, natural_key: referenceRecord.natural_key, target_item_index: null });
      } else if (containsReference(fieldValue)) {
        throw new Error(`items[${index}]: $ref разрешён только в поддерживаемом поле UUID верхнего уровня; вложенные ссылки запрещены.`);
      }
    }
    return { index, record_type: item.record_type, natural_key: (item.natural_key as string | null | undefined) ?? null, payload, references };
  });
  const seen = new Map<string, number>();
  for (const [index, item] of items.entries()) {
    const normalizedNaturalKey = item.natural_key?.toLocaleLowerCase("en-US");
    const key = `${item.record_type}:${normalizedNaturalKey || canonical(item.payload)}`;
    if (seen.has(key)) throw new Error(`items[${index}]: повтор типа и natural_key/payload (items[${seen.get(key)}]).`);
    seen.set(key, index);
  }
  if (items.some((item) => item.references.length > 0) && items.some((item) => !item.natural_key)) {
    throw new Error("Для возобновляемого пакета с $ref у каждой записи должен быть natural_key.");
  }
  const naturalKeyIndexes = new Map(items.filter((item) => item.natural_key).map((item) => [`${item.record_type}:${item.natural_key!.toLocaleLowerCase("en-US")}`, item.index]));
  const dependencyIndexes = items.map(() => new Set<number>());
  for (const item of items) {
    for (const reference of item.references) {
      const targetIndex = naturalKeyIndexes.get(`${reference.record_type}:${reference.natural_key.toLocaleLowerCase("en-US")}`) ?? null;
      reference.target_item_index = targetIndex;
      if (targetIndex === item.index) throw new Error(`items[${item.index}]: запись не может ссылаться сама на себя через ${reference.field}.`);
      if (targetIndex !== null) dependencyIndexes[item.index].add(targetIndex);
    }
  }
  const indegree = dependencyIndexes.map((dependencies) => dependencies.size);
  const dependents = items.map(() => [] as number[]);
  dependencyIndexes.forEach((dependencies, index) => dependencies.forEach((dependency) => dependents[dependency].push(index)));
  let frontier = indegree.flatMap((count, index) => count === 0 ? [index] : []);
  let processed = 0;
  while (frontier.length) {
    const next: number[] = [];
    for (const index of frontier) {
      processed += 1;
      for (const dependent of dependents[index]) {
        indegree[dependent] -= 1;
        if (indegree[dependent] === 0) next.push(dependent);
      }
    }
    frontier = next;
  }
  if (processed !== items.length) throw new Error("В пакете обнаружен цикл зависимостей $ref. Исправьте ссылки до staging.");
  if (new TextEncoder().encode(JSON.stringify(items)).byteLength > MAX_FILE_BYTES) throw new Error("Сериализованные элементы превышают лимит серверного preview 2 МиБ.");
  return { items, sourceVersion: (root.source_version as string | undefined) || "" };
}

export default function BulkIngestion({ sources, roles, onComplete }: { sources: Source[]; roles: Role[]; onComplete: () => Promise<void> }) {
  const supabase = useMemo(() => createClient(), []);
  const canEdit = roles.includes("admin") || roles.includes("editor");
  const [sessionUserId, setSessionUserId] = useState<string | null>(null);
  const sessionUserRef = useRef<string | null>(null);
  const sessionSequence = useRef(0);
  const fileSequence = useRef(0);
  const [fileName, setFileName] = useState("");
  const [fileHash, setFileHash] = useState("");
  const [inputFormat, setInputFormat] = useState<"json" | "csv">("json");
  const [items, setItems] = useState<BatchItem[]>([]);
  const [sourceVersion, setSourceVersion] = useState("");
  const [title, setTitle] = useState("");
  const [sourceId, setSourceId] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  const [preparedItems, setPreparedItems] = useState<PreparedItem[]>([]);
  const [dependencySummary, setDependencySummary] = useState<DependencySummary | null>(null);
  const [batchId, setBatchId] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    const applyUser = (id: string | null) => {
      sessionSequence.current += 1;
      fileSequence.current += 1;
      sessionUserRef.current = id;
      setSessionUserId(id);
      setFileName(""); setFileHash(""); setInputFormat("json"); setItems([]); setSourceVersion("");
      setTitle(""); setSourceId(""); setPreview(null); setPreparedItems([]); setDependencySummary(null); setBatchId(""); setBusy(false); setMessage(""); setError("");
    };
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { if (alive) applyUser(session?.user.id ?? null); });
    const initialSequence = sessionSequence.current;
    void supabase.auth.getUser().then(({ data, error: authError }) => {
      if (alive && !authError && initialSequence === sessionSequence.current) applyUser(data.user?.id ?? null);
    });
    return () => { alive = false; sessionSequence.current += 1; fileSequence.current += 1; listener.subscription.unsubscribe(); };
  }, [supabase]);

  async function readFile(file: File | undefined) {
    const currentFileSequence = ++fileSequence.current;
    setError(""); setMessage(""); setPreview(null); setPreparedItems([]); setDependencySummary(null); setBatchId(""); setItems([]); setFileName(""); setTitle(""); setSourceVersion(""); setFileHash(""); setInputFormat("json");
    if (!file) return;
    if (file.size > MAX_FILE_BYTES) { setError("Файл превышает лимит 2 МиБ для серверного preview."); return; }
    const ownerId = sessionUserRef.current;
    const ownerSequence = sessionSequence.current;
    if (!ownerId) { setError("Дождитесь подтверждения авторизованной сессии сотрудника."); return; }
    try {
      const [text, hash] = await Promise.all([file.text(), digestFile(file)]);
      const format = file.name.toLowerCase().endsWith(".csv") || file.type === "text/csv" ? "csv" : "json";
      const parsed = format === "csv" ? parseBatch(parseCsvBatch(text)) : parseBatch(JSON.parse(text));
      if (sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence || fileSequence.current !== currentFileSequence) return;
      setFileName(file.name.slice(0, 255));
      setTitle(file.name.replace(/\.[^.]+$/, "").slice(0, 180));
      setItems(parsed.items); setSourceVersion(parsed.sourceVersion); setFileHash(hash); setInputFormat(format);
      setMessage(`Файл ${format.toUpperCase()} прочитан: ${parsed.items.length} элементов. Это только локальный разбор; серверная проверка ещё не выполнена.`);
    } catch (e) {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence && fileSequence.current === currentFileSequence) setError(e instanceof Error ? e.message : "Не удалось прочитать JSON-пакет.");
    }
  }

  async function resolveReadyItems(ownerId: string): Promise<{ prepared: PreparedItem[]; summary: DependencySummary }> {
    if (!supabase) throw new Error("Supabase не подключён.");
    const planSourceId = sourceId || null;
    const planVersion = sourceVersion.trim() || null;
    let batchQuery = supabase.from("ingestion_batches")
      .select("id,status,input_format,source_id,source_version,created_by")
      .eq("created_by", ownerId).eq("file_sha256", fileHash).eq("input_format", inputFormat);
    batchQuery = planSourceId ? batchQuery.eq("source_id", planSourceId) : batchQuery.is("source_id", null);
    batchQuery = planVersion ? batchQuery.eq("source_version", planVersion) : batchQuery.is("source_version", null);
    const { data: batchData, error: batchError } = await batchQuery.order("created_at", { ascending: false }).limit(51);
    if (batchError) throw new Error(`Не удалось найти предыдущий staging этого файла: ${batchError.message}`);
    const matchingBatches = (batchData || []) as ExistingBatch[];
    if (matchingBatches.length > 50) throw new Error("Для этого SHA-256 найдено слишком много staging-пакетов; требуется ручная сверка, автоматическое продолжение остановлено.");
    const matchingBatchIds = new Set(matchingBatches.map((batch) => batch.id));
    const batchStatusById = new Map(matchingBatches.map((batch) => [batch.id, batch.status]));
    const openBatch = matchingBatches.find((batch) => batch.status === "open") || null;

    let planItems: ExistingItem[] = [];
    if (matchingBatchIds.size) {
      const { data, error: itemError } = await supabase.from("ingestion_items")
        .select("id,batch_id,record_type,natural_key,payload,reference_resolution,status,applied_table,applied_record_id,content_review_status")
        .in("batch_id", [...matchingBatchIds]).limit(501);
      if (itemError) throw new Error(`Не удалось прочитать предыдущие staging-записи: ${itemError.message}`);
      planItems = (data || []) as ExistingItem[];
      if (planItems.length > 500) throw new Error("В предыдущих staging-пакетах найдено слишком много элементов; автоматическое продолжение остановлено.");
    }

    const allReferences = items.flatMap((item) => item.references);
    const candidateTypes = [...new Set([...items.map((item) => item.record_type), ...allReferences.map((reference) => reference.record_type)])];
    const candidateKeys = [...new Set([...items.flatMap((item) => item.natural_key ? [item.natural_key] : []), ...allReferences.map((reference) => reference.natural_key)])];
    let candidates: ExistingItem[] = [];
    if (candidateKeys.length) {
      for (let offset = 0; offset < candidateKeys.length; offset += 100) {
        const keyChunk = candidateKeys.slice(offset, offset + 100);
        const { data, error: candidateError } = await supabase.from("ingestion_items")
          .select("id,batch_id,record_type,natural_key,payload,reference_resolution,status,applied_table,applied_record_id,content_review_status")
          .in("record_type", candidateTypes).in("natural_key", keyChunk).limit(1000);
        if (candidateError) throw new Error(`Не удалось разрешить natural_key: ${candidateError.message}`);
        candidates.push(...((data || []) as ExistingItem[]));
        if ((data || []).length >= 1000 || candidates.length >= 1000) throw new Error("Найдено слишком много совпадений natural_key. Уточните ключи; автоматический выбор неоднозначной записи запрещён.");
      }
    }

    const keyOf = (recordType: string, naturalKey: string) => `${recordType}:${naturalKey.toLocaleLowerCase("en-US")}`;
    const planByKey = new Map<string, ExistingItem[]>();
    const allByKey = new Map<string, ExistingItem[]>();
    const addTo = (map: Map<string, ExistingItem[]>, row: ExistingItem) => {
      if (!row.natural_key) return;
      const key = keyOf(row.record_type, row.natural_key);
      map.set(key, [...(map.get(key) || []), row]);
    };
    for (const row of candidates) addTo(allByKey, row);
    for (const row of planItems) addTo(planByKey, row);
    const planRowsByFingerprint = new Map<string, ExistingItem[]>();
    for (const row of planItems.filter((entry) => !entry.natural_key)) {
      const fingerprint = `${row.record_type}:${canonical(row.payload)}`;
      planRowsByFingerprint.set(fingerprint, [...(planRowsByFingerprint.get(fingerprint) || []), row]);
    }

    const prepared: PreparedItem[] = [];
    const blocked: DependencyBlock[] = [];
    const issues: Array<{ index: number; message: string }> = [];
    const alreadyStaged: Array<{ index: number; status: string }> = [];
    const warnings: string[] = [];

    for (const item of items) {
      const resolvedPayload: Record<string, unknown> = { ...item.payload };
      const referenceResolution: ReferenceResolution[] = [];
      let itemBlocked = false;
      let itemHasIssue = false;

      for (const reference of item.references) {
        const referenceKey = keyOf(reference.record_type, reference.natural_key);
        let target: ExistingItem | null = null;
        if (reference.target_item_index !== null) {
          const planVariants = planByKey.get(referenceKey) || [];
          const inPlan = planVariants.filter((row) => row.natural_key === reference.natural_key);
          if (!inPlan.length && planVariants.length) {
            issues.push({ index: item.index, message: `${reference.field}: natural_key совпадает без учёта регистра, но отличается по написанию; для аудита требуется точное совпадение.` });
            itemHasIssue = true;
            continue;
          }
          if (inPlan.length > 1) {
            issues.push({ index: item.index, message: `${reference.field}: в этом staging-плане несколько записей ${reference.record_type}/${reference.natural_key}.` });
            itemHasIssue = true;
            continue;
          }
          if (inPlan.length === 1) {
            if (inPlan[0].status === "applied") target = inPlan[0];
            else if (["rejected", "failed"].includes(inPlan[0].status)) {
              issues.push({ index: item.index, message: `${reference.field}: родитель ${reference.record_type}/${reference.natural_key} имеет статус ${inPlan[0].status}; исправьте или создайте новую ревизию пакета.` });
              itemHasIssue = true;
              continue;
            } else {
              blocked.push({ index: item.index, field: reference.field, record_type: reference.record_type, natural_key: reference.natural_key, reason: `родительский элемент сейчас ${inPlan[0].status}; требуется модерация и импорт` });
              itemBlocked = true;
              continue;
            }
          } else {
            const globalVariants = (allByKey.get(referenceKey) || []).filter((row) => !matchingBatchIds.has(row.batch_id));
            const globalApplied = globalVariants.filter((row) => row.natural_key === reference.natural_key && row.status === "applied");
            if (!globalApplied.length && globalVariants.length && globalVariants.some((row) => row.natural_key !== reference.natural_key)) {
              issues.push({ index: item.index, message: `${reference.field}: natural_key найден только с другим регистром; для точного аудита используйте сохранённое написание.` });
              itemHasIssue = true;
              continue;
            }
            const packageTarget = items[reference.target_item_index];
            if (globalApplied.length === 1 && packageTarget.references.length === 0 && canonical(globalApplied[0].payload) === canonical(packageTarget.payload)) {
              target = globalApplied[0];
              warnings.push(`${reference.record_type}/${reference.natural_key} уже импортирован в другом пакете и совпадает по payload; повторная запись пропущена.`);
            } else if (globalApplied.length > 1) {
              issues.push({ index: item.index, message: `${reference.field}: найдено несколько импортированных записей ${reference.record_type}/${reference.natural_key}; требуется устранить неоднозначность.` });
              itemHasIssue = true;
              continue;
            } else if (globalApplied.length === 1) {
              issues.push({ index: item.index, message: packageTarget.references.length
                ? `${reference.field}: родитель с собственными $ref уже импортирован в другом пакете; безопасно сравнить его исходный payload нельзя. Продолжите исходный пакет или исключите повторную запись родителя.`
                : `${reference.field}: ${reference.record_type}/${reference.natural_key} уже существует, но payload не совпадает с записью пакета.` });
              itemHasIssue = true;
              continue;
            } else {
              const pending = globalVariants.filter((row) => ["draft", "needs_review", "accepted_for_import"].includes(row.status));
              const terminal = globalVariants.filter((row) => ["rejected", "failed"].includes(row.status));
              if (!globalVariants.length || (pending.length === 1 && terminal.length === 0)) {
                blocked.push({ index: item.index, field: reference.field, record_type: reference.record_type, natural_key: reference.natural_key, reason: "родитель ещё не импортирован; сначала обработайте предыдущий слой" });
                itemBlocked = true;
                continue;
              }
              issues.push({ index: item.index, message: `${reference.field}: staging-цель ${reference.record_type}/${reference.natural_key} имеет отклонённый, неуспешный или неоднозначный статус.` });
              itemHasIssue = true;
              continue;
            }
          }
        } else {
          const variants = allByKey.get(referenceKey) || [];
          const matches = variants.filter((row) => row.natural_key === reference.natural_key);
          if (!matches.length && variants.length) {
            issues.push({ index: item.index, message: `${reference.field}: natural_key найден только с другим регистром; для точного аудита используйте сохранённое написание.` });
            itemHasIssue = true;
            continue;
          }
          const applied = matches.filter((row) => row.status === "applied");
          if (applied.length === 1) target = applied[0];
          else if (applied.length > 1) {
            issues.push({ index: item.index, message: `${reference.field}: ссылка ${reference.record_type}/${reference.natural_key} неоднозначна (${applied.length} импортированных совпадения).` });
            itemHasIssue = true;
            continue;
          } else if (matches.length) {
            const pending = matches.filter((row) => ["draft", "needs_review", "accepted_for_import"].includes(row.status));
            const terminal = matches.filter((row) => ["rejected", "failed"].includes(row.status));
            if (pending.length === 1 && terminal.length === 0) {
              blocked.push({ index: item.index, field: reference.field, record_type: reference.record_type, natural_key: reference.natural_key, reason: "найден staging-элемент, но он ещё не импортирован" });
              itemBlocked = true;
              continue;
            }
            issues.push({ index: item.index, message: `${reference.field}: staging-цель ${reference.record_type}/${reference.natural_key} имеет отклонённый, неуспешный или неоднозначный статус.` });
            itemHasIssue = true;
            continue;
          } else {
            issues.push({ index: item.index, message: `${reference.field}: не найдена импортированная staging-запись ${reference.record_type}/${reference.natural_key}.` });
            itemHasIssue = true;
            continue;
          }
        }

        const expectedTable = REFERENCE_TABLES[reference.record_type];
        if (!target || target.applied_table !== expectedTable || !target.applied_record_id) {
          issues.push({ index: item.index, message: `${reference.field}: цель не подтверждена как applied-запись таблицы ${expectedTable}.` });
          itemHasIssue = true;
          continue;
        }
        resolvedPayload[reference.field] = target.applied_record_id;
        referenceResolution.push({
          field: reference.field,
          target_record_type: reference.record_type,
          target_natural_key: reference.natural_key,
          target_item_id: target.id,
          target_record_id: target.applied_record_id,
          target_table: expectedTable
        });
        if (target.content_review_status !== "verified") warnings.push(`Родитель ${reference.record_type}/${reference.natural_key} импортирован, но ещё не прошёл техническую проверку.`);
      }

      if (itemBlocked || itemHasIssue) continue;

      let existing: ExistingItem | null = null;
      if (item.natural_key) {
        const key = keyOf(item.record_type, item.natural_key);
        const planVariants = planByKey.get(key) || [];
        const inPlan = planVariants.filter((row) => row.natural_key === item.natural_key);
        if (!inPlan.length && planVariants.length) {
          issues.push({ index: item.index, message: "natural_key в существующем staging отличается только регистром; автоматическое объединение запрещено." });
          continue;
        }
        if (inPlan.length > 1) {
          issues.push({ index: item.index, message: "В текущем плане найдено несколько staging-записей с этим natural_key." });
          continue;
        }
        if (inPlan.length === 1) existing = inPlan[0];
        else {
          const globalVariants = (allByKey.get(key) || []).filter((row) => !matchingBatchIds.has(row.batch_id));
          const globalMatches = globalVariants.filter((row) => row.natural_key === item.natural_key);
          if (!globalMatches.length && globalVariants.length) {
            issues.push({ index: item.index, message: "natural_key уже используется с другим регистром; автоматическое объединение запрещено." });
            continue;
          }
          if (globalMatches.length > 1) {
            issues.push({ index: item.index, message: "Этот natural_key уже используется в нескольких других пакетах; автоматический выбор запрещён." });
            continue;
          }
          if (globalMatches.length === 1) existing = globalMatches[0];
        }
      } else {
        const fingerprint = `${item.record_type}:${canonical(resolvedPayload)}`;
        const inPlan = planRowsByFingerprint.get(fingerprint) || [];
        if (inPlan.length > 1) {
          issues.push({ index: item.index, message: "В текущем плане найдено несколько одинаковых записей без natural_key." });
          continue;
        }
        if (inPlan.length === 1) existing = inPlan[0];
      }

      if (existing) {
        if (canonical(existing.payload) !== canonical(resolvedPayload)) {
          issues.push({ index: item.index, message: `natural_key ${item.natural_key || item.record_type} уже существует с другим payload; автоматическое обновление запрещено.` });
          continue;
        }
        if (["rejected", "failed"].includes(existing.status)) {
          issues.push({ index: item.index, message: `Предыдущая staging-запись имеет статус ${existing.status}; исправьте её вручную или используйте новый natural_key. Одна только смена source_version не перезаписывает существующую запись.` });
          continue;
        }
        if (existing.status === "draft") {
          if (!matchingBatchIds.has(existing.batch_id) || batchStatusById.get(existing.batch_id) !== "open") {
            blocked.push({ index: item.index, field: "natural_key", record_type: item.record_type, natural_key: item.natural_key || "", reason: "черновик уже находится в другом staging-пакете; завершите его там" });
            continue;
          }
          if (canonical(existing.reference_resolution || []) !== canonical(referenceResolution)) {
            issues.push({ index: item.index, message: "Аудит reference_resolution отличается от текущего разрешения; создайте новую ревизию пакета." });
            continue;
          }
          prepared.push({ index: item.index, record_type: item.record_type, natural_key: item.natural_key, payload: resolvedPayload, reference_resolution: referenceResolution, existing_item_id: existing.id });
          continue;
        }
        alreadyStaged.push({ index: item.index, status: existing.status });
        continue;
      }

      prepared.push({ index: item.index, record_type: item.record_type, natural_key: item.natural_key, payload: resolvedPayload, reference_resolution: referenceResolution });
    }

    return {
      prepared,
      summary: { ready: prepared.length, blocked, issues, alreadyStaged, warnings: [...new Set(warnings)], reusedBatchId: openBatch?.id || null }
    };
  }

  async function runPreview() {
    if (!supabase || !canEdit || !items.length) return;
    const ownerId = sessionUserRef.current;
    const ownerSequence = sessionSequence.current;
    const previewHash = fileHash;
    const previewSourceId = sourceId;
    const previewVersion = sourceVersion;
    if (!ownerId || !previewHash) { setError("Требуется авторизованная сессия и загруженный пакет."); return; }
    setBusy(true); setError(""); setMessage(""); setPreview(null); setPreparedItems([]); setDependencySummary(null);
    try {
      const { data: authData, error: authError } = await supabase.auth.getUser();
      if (authError || authData.user?.id !== ownerId || sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) throw new Error("Сессия изменилась. Preview отменён.");
      const resolution = await resolveReadyItems(ownerId);
      if (sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence || fileHash !== previewHash || sourceId !== previewSourceId || sourceVersion !== previewVersion) return;
      setPreparedItems(resolution.prepared);
      setDependencySummary(resolution.summary);
      setBatchId(resolution.summary.reusedBatchId || "");
      if (!resolution.prepared.length) {
        const waiting = resolution.summary.blocked.length;
        const issues = resolution.summary.issues.length;
        setMessage(waiting || issues || resolution.summary.alreadyStaged.length
          ? `Новых готовых записей нет. Ожидают родителей: ${waiting}; ошибок разрешения: ${issues}; уже обработано: ${resolution.summary.alreadyStaged.length}.`
          : "Все записи уже находятся в staging; повторная загрузка не требуется.");
        return;
      }
      const previewItems = resolution.prepared.map((item) => ({ record_type: item.record_type, natural_key: item.natural_key, payload: item.payload }));
      const { data, error: rpcError } = await supabase.rpc("preview_ingestion_batch", { p_source_id: sourceId || null, p_items: previewItems as unknown as never });
      if (rpcError) throw new Error(rpcError.message);
      if (sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence || fileHash !== previewHash || sourceId !== previewSourceId || sourceVersion !== previewVersion) return;
      const rawResult = data as unknown as Preview;
      if (!rawResult || rawResult.status !== "previewed" || !Array.isArray(rawResult.results)) throw new Error("Сервер вернул неизвестный формат preview.");
      const result: Preview = {
        ...rawResult,
        results: rawResult.results.map((row) => ({ ...row, index: resolution.prepared[row.index - 1]?.index ?? row.index - 1 }))
      };
      setPreview(result);
      const blockedCount = resolution.summary.blocked.length;
      const issueCount = resolution.summary.issues.length;
      setMessage(result.invalid === 0 && result.valid === result.total
        ? `Серверная проверка пройдена: ${result.valid}/${result.total} готовых записей. Ожидают родителей: ${blockedCount}; уже обработано: ${resolution.summary.alreadyStaged.length}; ошибок разрешения: ${issueCount}. Данные ещё не сохранены в staging.`
        : `Серверный preview обнаружил ошибки: корректно ${result.valid}, с ошибками ${result.invalid}. Исправьте отмеченные записи и повторите preview; неподготовленные зависимости останутся заблокированы.`);
    } catch (e) {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence && fileHash === previewHash && sourceId === previewSourceId && sourceVersion === previewVersion) setError(e instanceof Error ? e.message : "Серверный preview не выполнен.");
    } finally {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence && fileHash === previewHash && sourceId === previewSourceId && sourceVersion === previewVersion) setBusy(false);
    }
  }

  async function stageBatch() {
    if (!supabase || !canEdit || !preview || preview.invalid !== 0 || preview.valid !== preparedItems.length || !preparedItems.length) return;
    const ownerId = sessionUserRef.current;
    const ownerSequence = sessionSequence.current;
    if (!ownerId) { setError("Требуется авторизованная сессия сотрудника."); return; }
    if (!title.trim() || title.trim().length > 180) { setError("Название пакета должно содержать от 1 до 180 символов."); return; }
    const stageHash = fileHash;
    const stageSourceId = sourceId;
    const stageVersion = sourceVersion;
    setBusy(true); setError(""); setMessage("");
    let createdBatchId = "";
    try {
      const { data: authData, error: authError } = await supabase.auth.getUser();
      if (authError || authData.user?.id !== ownerId || sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) throw new Error("Сессия изменилась. Пакет не создан.");
      let batchQuery = supabase.from("ingestion_batches")
        .select("id,status,input_format,source_id,source_version,created_by")
        .eq("created_by", ownerId).eq("file_sha256", stageHash).eq("input_format", inputFormat);
      batchQuery = stageSourceId ? batchQuery.eq("source_id", stageSourceId) : batchQuery.is("source_id", null);
      batchQuery = stageVersion.trim() ? batchQuery.eq("source_version", stageVersion.trim()) : batchQuery.is("source_version", null);
      const { data: batchData, error: batchLookupError } = await batchQuery.order("created_at", { ascending: false }).limit(51);
      if (batchLookupError) throw new Error(`Не удалось проверить существующий пакет: ${batchLookupError.message}`);
      const matchingBatches = (batchData || []) as ExistingBatch[];
      if (matchingBatches.length > 50) throw new Error("Для этого SHA-256 найдено слишком много staging-пакетов; автоматическое продолжение остановлено.");
      const reusableBatch = matchingBatches.find((batch) => batch.status === "open") || null;
      if (reusableBatch) {
        createdBatchId = reusableBatch.id;
      } else {
        const { data: batch, error: batchError } = await supabase.from("ingestion_batches").insert({
          title: title.trim(), source_id: stageSourceId || null, input_format: inputFormat, status: "open", created_by: ownerId,
          original_filename: fileName, file_sha256: stageHash, source_version: stageVersion.trim() || null
        }).select("id").single();
        if (batchError || !batch?.id) throw new Error(batchError?.message || "Не удалось создать пакет.");
        createdBatchId = batch.id;
      }
      setBatchId(createdBatchId);
      if (sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) throw new Error(`Сессия изменилась. Пакет ${createdBatchId} создан, отправка остановлена.`);
      const { data: currentBatchItems, error: currentBatchItemsError } = await supabase.from("ingestion_items").select("id").eq("batch_id", createdBatchId).limit(101);
      if (currentBatchItemsError) throw new Error(`Не удалось проверить лимит пакета ${createdBatchId}: ${currentBatchItemsError.message}`);
      const newItems = preparedItems.filter((item) => !item.existing_item_id);
      if ((currentBatchItems || []).length + newItems.length > MAX_ITEMS) throw new Error(`Пакет ${createdBatchId} превысит лимит ${MAX_ITEMS} записей; продолжение остановлено без вставки.`);
      if (newItems.length) {
        const rows = newItems.map((item) => ({
          batch_id: createdBatchId, record_type: item.record_type, natural_key: item.natural_key, payload: item.payload,
          reference_resolution: item.reference_resolution, created_by: ownerId, status: "draft"
        }));
        const { error: itemsError } = await supabase.from("ingestion_items").insert(rows);
        if (itemsError) throw new Error(`Пакет ${createdBatchId} создан/найден, но новые элементы не записаны: ${itemsError.message}`);
      }
      const { data: currentAuth, error: currentAuthError } = await supabase.auth.getUser();
      if (currentAuthError || currentAuth.user?.id !== ownerId || sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) throw new Error(`Пакет ${createdBatchId} сохранён в staging, но сессия изменилась до отправки на модерацию.`);
      const { data: submitted, error: submitError } = await supabase.rpc("submit_ingestion_batch", { p_batch_id: createdBatchId });
      if (submitError) throw new Error(`Пакет ${createdBatchId} сохранён, но отправка на модерацию не завершена: ${submitError.message}`);
      if (sessionUserRef.current !== ownerId || sessionSequence.current !== ownerSequence) return;
      const result = submitted as unknown as SubmitResult;
      setMessage(`Пакет ${createdBatchId}: текущий слой отправлен на модерацию (${result.submitted ?? 0} принято, ${result.rejected ?? 0} отклонено). После модерации и импорта родителей снова запустите серверную проверку этого же файла — следующие зависимости будут разрешены автоматически.`);
      setPreview(null); setPreparedItems([]);
      setDependencySummary((current) => current ? {
        ...current,
        ready: 0,
        warnings: [...new Set([...current.warnings, "Текущий слой отправлен в очередь модерации; дождитесь статуса applied у родителей перед продолжением."])]
      } : current);
      await onComplete();
    } catch (e) {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence) {
        const rawMessage = e instanceof Error ? e.message : `Не удалось отправить пакет ${createdBatchId || ""}.`;
        setError(rawMessage.includes("jsonb_object_length")
          ? "Текущая схема Supabase содержит несовместимую версию reference-resolution guard. Проверьте применение миграции 20261102125352; запись с $ref не сохранена. Не повторяйте импорт до применения и проверки миграции."
          : rawMessage);
      }
    } finally {
      if (sessionUserRef.current === ownerId && sessionSequence.current === ownerSequence && fileHash === stageHash && sourceId === stageSourceId && sourceVersion === stageVersion) setBusy(false);
    }
  }

  if (!canEdit) return null;
  return <div className="admin-form" style={{ marginBottom: 16 }}>
    <div className="admin-form-title">Массовый JSON/CSV-импорт — staging only</div>
    <p className="admin-review-note">До 100 элементов и 2 МиБ. CSV использует ровно три столбца: <code>record_type,natural_key,payload_json</code>; JSON в последнем столбце должен быть заключён в CSV-кавычки по RFC 4180. Ссылки между новыми записями задаются через <code>{"{\"$ref\":{\"record_type\":\"engine\",\"natural_key\":\"EA888-G3\"}}"}</code>. Система отправляет только готовый слой; после модерации и импорта родителей повторная проверка того же файла возобновит открытый пакет. Если пакет закрыт, создаётся новый без повторной вставки уже обработанных строк. Публичный каталог этим действием не публикуется.</p>
    <div className="admin-form-grid">
      <label className="wide">JSON/CSV-пакет<input type="file" accept=".json,.csv,application/json,text/csv" disabled={busy} onChange={(event) => void readFile(event.target.files?.[0])} /></label>
      <label>Название пакета<input maxLength={180} disabled={busy} value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Название импорта" /></label>
      <label>Основной источник<select disabled={busy} value={sourceId} onChange={(event) => { setSourceId(event.target.value); setPreview(null); setPreparedItems([]); setDependencySummary(null); setBatchId(""); setMessage(""); }}><option value="">Не задан — источник в payload/родительском документе</option>{sources.map((source) => <option key={source.id} value={source.id}>{source.publisher} · {source.permission_status}</option>)}</select></label>
      <label>Версия набора<input maxLength={80} disabled={busy} value={sourceVersion} onChange={(event) => { setSourceVersion(event.target.value); setPreview(null); setPreparedItems([]); setDependencySummary(null); setBatchId(""); setMessage(""); }} placeholder="Ревизия / дата / DOI" /></label>
    </div>
    {fileName && <div className="admin-review-note">{fileName} · {inputFormat.toUpperCase()} · {items.length} элементов · SHA-256: <code>{fileHash}</code></div>}
    <div className="admin-form-foot"><span>Файл: ≤ 2 МиБ · элементы: 1–100 · $ref разрешается только к единственной записи со статусом applied.</span><div className="admin-review-actions"><button type="button" className="admin-secondary" disabled={busy || !items.length || !sessionUserId} onClick={() => void runPreview()}>Проверить следующий слой</button><button type="button" className="admin-primary" disabled={busy || !preview || !preparedItems.length || preview.invalid !== 0 || preview.valid !== preparedItems.length || !sessionUserId} onClick={() => void stageBatch()}>Отправить готовый слой</button></div></div>
    {dependencySummary && <div className={`admin-alert ${dependencySummary.issues.length ? "error" : dependencySummary.blocked.length ? "" : "success"}`}>
      <strong>План зависимостей:</strong> готово к preview — {dependencySummary.ready}; ожидают импорта родителей — {dependencySummary.blocked.length}; уже обработано — {dependencySummary.alreadyStaged.length}; ошибки — {dependencySummary.issues.length}.
      {dependencySummary.reusedBatchId && <p>Возобновлён staging-пакет <code>{dependencySummary.reusedBatchId}</code>.</p>}
      {dependencySummary.blocked.map((entry, index) => <p key={`blocked-${entry.index}-${entry.field}-${index}`}>Строка {entry.index + 1}, {entry.field} → {entry.record_type}/{entry.natural_key}: {entry.reason}.</p>)}
      {dependencySummary.issues.map((entry, index) => <p key={`issue-${entry.index}-${index}`}>Строка {entry.index + 1}: {entry.message}</p>)}
      {dependencySummary.warnings.map((warning, index) => <p key={`warning-${index}`}>{warning}</p>)}
      {(dependencySummary.blocked.length > 0 || dependencySummary.warnings.length > 0) && <p>Для продолжения одобрите и импортируйте родительские элементы. После этого нажмите «Проверить следующий слой». Импорт не означает техническую верификацию или публикацию.</p>}
    </div>}
    {preview && <div className={`admin-alert ${preview.invalid === 0 ? "success" : "error"}`}><strong>Серверный dry-run:</strong> {preview.valid}/{preview.total} корректно · ошибок: {preview.invalid}<p>{preview.validation_scope}</p><p>{preview.limitations}</p><p>Права источника на момент preview: {preview.source_permission || "не указаны"}. Они повторно проверяются сервером при модерации и импорте.</p>{preview.results.filter((row) => row.errors.length).map((row) => <p key={row.index}>Строка {row.index + 1} ({row.record_type || "тип не указан"}): {row.errors.join("; ")}</p>)}</div>}
    {batchId && <small>Пакет staging: <code>{batchId}</code></small>}
    {message && <div className="admin-notice">{message}</div>}{error && <div className="admin-error">{error}</div>}
  </div>;
}
