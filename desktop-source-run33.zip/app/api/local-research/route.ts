import * as localResearch from "../../../lib/local-research-db.cjs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const headers = {
  "Cache-Control": "private, no-store, max-age=0",
  "X-Content-Type-Options": "nosniff",
};

export async function GET(request: Request) {
  const url = new URL(request.url);
  const dataset = url.searchParams.get("dataset") || "summary";
  const query = url.searchParams.get("q") || "";
  const limitValue = url.searchParams.get("limit") || "25";
  const limit = Number.parseInt(limitValue, 10);

  try {
    if (dataset === "summary") {
      return Response.json(localResearch.getResearchSummary(), { headers });
    }
    if (!Number.isInteger(limit) || limit < 1 || limit > 50) {
      return Response.json({ error: "Лимит должен быть от 1 до 50." }, { status: 400, headers });
    }
    let rows: Array<Record<string, unknown>>;
    if (dataset === "vehicles") rows = localResearch.searchVehicleCandidates(query, limit);
    else if (dataset === "dtc") rows = localResearch.searchGenericDtcs(query, limit);
    else if (dataset === "pids") rows = localResearch.searchGenericPids(query, limit);
    else if (dataset === "uds") rows = localResearch.searchUdsSignals(query, limit);
    else if (dataset === "vehiclesdb") rows = localResearch.searchVehiclesDbCandidates(query, limit);
    else return Response.json({ error: "Неизвестный локальный справочник." }, { status: 404, headers });
    return Response.json({ dataset, query: query.trim(), count: rows.length, rows }, { headers });
  } catch (error) {
    if (error instanceof TypeError) {
      return Response.json({ error: error.message }, { status: 400, headers });
    }
    return Response.json({ error: "Локальный справочник недоступен или не прошёл проверку целостности." }, { status: 503, headers });
  }
}
