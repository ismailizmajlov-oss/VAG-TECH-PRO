import { createHmac } from 'node:crypto';
import { isIP } from 'node:net';
import { createClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server';
import { decodeVinLocal } from '@/lib/vin/decoder';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const MAX_VPIC_RESPONSE_BYTES = 1024 * 1024;

const responseHeaders = {
  'Cache-Control': 'private, no-store, max-age=0',
  'Referrer-Policy': 'no-referrer',
  'X-Content-Type-Options': 'nosniff'
};

type RateGate = { allowed: boolean; reason?: string };

async function checkVinRateLimit(req: NextRequest): Promise<RateGate> {
  const projectUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const rateLimitSecret = process.env.VIN_RATE_LIMIT_SECRET;
  const trustedProxyIp = req.headers.get('x-real-ip')?.trim();

  if (!projectUrl || !serviceRoleKey || !rateLimitSecret || Buffer.byteLength(rateLimitSecret) < 32 || !trustedProxyIp || isIP(trustedProxyIp) === 0) {
    return {
      allowed: false,
      reason: 'Внешний VIN-справочник не вызывался: серверный лимитер не настроен или доверенный proxy IP недоступен. Показан только локальный результат.'
    };
  }

  try {
    const keyHash = createHmac('sha256', rateLimitSecret).update(trustedProxyIp).digest('hex');
    const serviceClient = createClient(projectUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false }
    });
    const { data, error } = await serviceClient.rpc('consume_vin_rate_limit', {
      p_key_hash: keyHash,
      p_limit: 10,
      p_window_seconds: 600
    });
    if (error || typeof data !== 'boolean') {
      return { allowed: false, reason: 'Проверка лимита недоступна; внешний VIN-запрос отключён по безопасному режиму.' };
    }
    return data
      ? { allowed: true }
      : { allowed: false, reason: 'Достигнут лимит внешних VIN-запросов для этой сети. Попробуйте позже; локальная проверка доступна.' };
  } catch {
    return { allowed: false, reason: 'Серверная проверка лимита завершилась ошибкой; внешний VIN-запрос отключён по безопасному режиму.' };
  }
}

async function readJsonBody(req: NextRequest): Promise<unknown> {
  const contentType = req.headers.get('content-type') || '';
  if (!/^application\/json(?:\s*;|$)/i.test(contentType)) {
    throw new Error('UNSUPPORTED_MEDIA_TYPE');
  }
  const charset = contentType.match(/charset\s*=\s*([^;\s]+)/i)?.[1]?.replace(/["']/g, '').toLowerCase();
  if (charset && charset !== 'utf-8' && charset !== 'utf8') {
    throw new Error('UNSUPPORTED_CHARSET');
  }

  const declaredLength = req.headers.get('content-length');
  if (declaredLength && /^\d+$/.test(declaredLength) && Number(declaredLength) > 1024) {
    throw new Error('BODY_TOO_LARGE');
  }
  if (!req.body) throw new Error('INVALID_BODY');

  const reader = req.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > 1024) {
        await reader.cancel();
        throw new Error('BODY_TOO_LARGE');
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }

  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  const raw = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  return JSON.parse(raw) as unknown;
}

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await readJsonBody(req);
  } catch (error) {
    const code = error instanceof Error ? error.message : '';
    if (code === 'BODY_TOO_LARGE') {
      return NextResponse.json({ error: 'Request body is too large.' }, { status: 413, headers: responseHeaders });
    }
    if (code === 'UNSUPPORTED_MEDIA_TYPE' || code === 'UNSUPPORTED_CHARSET') {
      return NextResponse.json({ error: 'Content-Type must be application/json encoded as UTF-8.' }, { status: 415, headers: responseHeaders });
    }
    return NextResponse.json({ error: 'Invalid UTF-8 JSON body.' }, { status: 400, headers: responseHeaders });
  }

  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return NextResponse.json({ error: 'JSON body must be an object.' }, { status: 400, headers: responseHeaders });
  }
  const bodyRecord = body as Record<string, unknown>;
  if (Object.keys(bodyRecord).some((key) => key !== 'vin')) {
    return NextResponse.json({ error: 'Only the vin field is accepted.' }, { status: 400, headers: responseHeaders });
  }

  const candidate = typeof bodyRecord.vin === 'string' ? bodyRecord.vin.trim().toUpperCase() : '';
  if (!/^[A-HJ-NPR-Z0-9]{17}$/.test(candidate)) {
    return NextResponse.json({ error: 'VIN must contain 17 valid characters; I, O and Q are not allowed.' }, { status: 400, headers: responseHeaders });
  }

  const local = decodeVinLocal(candidate);
  if (!local.validFormat) {
    return NextResponse.json({
      ...local,
      source: 'Локальный VIN Decoder',
      sourceUrl: null,
      sourceRevision: 'Локальная проверка формата; заводская база не подключена',
      sourceRights: 'local-reference-only',
      externalAvailable: false,
      notes: [...local.notes, 'VIN не прошёл локальную проверку формата; внешний справочник не вызывался.']
    }, { headers: responseHeaders });
  }

  const rateGate = await checkVinRateLimit(req);
  if (!rateGate.allowed) {
    return NextResponse.json({
      ...local,
      source: 'Локальный VIN Decoder',
      sourceUrl: null,
      sourceRevision: 'Локальная проверка формата; заводская база не подключена',
      sourceRights: 'local-reference-only',
      externalAvailable: false,
      notes: [...local.notes, rateGate.reason || 'Внешний VIN-справочник не вызван.']
    }, { headers: responseHeaders });
  }

  try {
    const response = await fetch(`https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValues/${encodeURIComponent(candidate)}?format=json`, {
      headers: { Accept: 'application/json' },
      signal: AbortSignal.timeout(10_000),
      cache: 'no-store',
      redirect: 'error'
    });
    if (!response.ok) throw new Error(`vPIC returned ${response.status}`);
    const contentType = response.headers.get('content-type')?.toLowerCase() || '';
    if (!contentType.includes('application/json')) throw new Error('Unexpected vPIC content type');
    const reader = response.body?.getReader();
    if (!reader) throw new Error('Empty vPIC response');
    const chunks: Uint8Array[] = [];
    let total = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.byteLength;
        if (total > MAX_VPIC_RESPONSE_BYTES) {
          await reader.cancel();
          throw new Error('vPIC response exceeds size limit');
        }
        chunks.push(value);
      }
    } finally {
      reader.releaseLock();
    }
    const bytes = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
    const json = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
    const row = json && typeof json === 'object' && Array.isArray(json.Results) ? json.Results[0] : null;
    if (!row || typeof row !== 'object' || Array.isArray(row)) throw new Error('Unexpected vPIC response shape');
    const upstreamVin = (row as Record<string, unknown>).VIN;
    // Never merge upstream attributes into a different or unidentified VIN.
    // A missing VIN field is treated as an invalid upstream response, not as a soft success.
    if (typeof upstreamVin !== 'string' || upstreamVin.trim().toUpperCase() !== candidate) {
      throw new Error('vPIC VIN missing or mismatch');
    }
    const fields = Object.entries(row as Record<string, unknown>)
      .filter(([key]) => key.startsWith('Vehicle') || ['Make', 'Model', 'ModelYear', 'EngineModel', 'DisplacementL', 'FuelTypePrimary', 'TransmissionStyle', 'DriveType'].includes(key))
      .filter(([, value]) => typeof value === 'string' && value.trim() !== '' && value !== 'Not Applicable')
      .slice(0, 30)
      .map(([name, value]) => ({ name, value: String(value).replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 200), source: 'NHTSA vPIC', confidence: 'reference' }));

    return NextResponse.json({
      ...local,
      externalAvailable: true,
      source: 'Локальный VIN Decoder + NHTSA vPIC',
      fields: [...local.fields, ...fields],
      sourceUrl: 'https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValues',
      sourceTermsUrl: 'https://vpic.nhtsa.dot.gov/api/Home/Index/FAQ',
      sourceRevision: 'vPIC API 4.10; last code change 2026-10-17',
      sourceRights: 'live-public-reference-only; no repair-catalog reuse',
      notes: [...local.notes, 'Данные NHTSA vPIC являются вспомогательными и не заменяют заводскую комплектацию VAG, PR-коды или проверку по OEM-источнику. Ответ получен напрямую; кэширование отключено.']
    }, { headers: responseHeaders });
  } catch {
    return NextResponse.json({
      ...local,
      source: 'Локальный VIN Decoder',
      sourceUrl: null,
      sourceRevision: 'Локальная проверка формата; заводская база не подключена',
      sourceRights: 'local-reference-only',
      externalAvailable: false,
      notes: [...local.notes, 'NHTSA vPIC временно недоступен. Локальная проверка не подтверждает комплектацию автомобиля.']
    }, { headers: responseHeaders });
  }
}
