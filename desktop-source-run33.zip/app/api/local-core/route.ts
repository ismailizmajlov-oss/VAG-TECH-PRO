import * as localCore from "../../../lib/local-core-db.cjs";
import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const headers = {
  "Cache-Control": "private, no-store, max-age=0",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
};

function localDatabasePath() {
  const value = process.env.VAG_TECH_PRO_DB_PATH;
  return typeof value === "string" && value.trim() ? value : null;
}

function isLocalRequest(request: Request) {
  const url = new URL(request.url);
  const host = request.headers.get("host") || url.host;
  const origin = request.headers.get("origin");
  const fetchSite = request.headers.get("sec-fetch-site");
  if (origin) { try { if (new URL(origin).origin !== url.origin) return false; } catch { return false; } }
  if (fetchSite && fetchSite !== "same-origin" && fetchSite !== "none") return false;
  return ["127.0.0.1", "localhost", "[::1]"].some((name) => host === name || host.startsWith(`${name}:`));
}

function isSameOriginMutation(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return false;
  try { return new URL(origin).origin === new URL(request.url).origin; }
  catch { return false; }
}


async function readLimitedBytes(request: Request, maxBytes: number) {
  const declared = Number(request.headers.get("content-length") || "0");
  if (Number.isFinite(declared) && declared > maxBytes) throw new Error(`Request body exceeds ${maxBytes} bytes`);
  if (!request.body) return new Uint8Array();
  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) {
        await reader.cancel();
        throw new Error(`Request body exceeds ${maxBytes} bytes`);
      }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  return Buffer.concat(chunks.map((chunk) => Buffer.from(chunk)));
}
async function readLimitedBody(request: Request, maxBytes: number) {
  return (await readLimitedBytes(request, maxBytes)).toString("utf8");
}
function localBackupName() {
  return `vag-tech-pro-backup-${new Date().toISOString().replace(/[:.]/g, "-")}.sqlite`;
}

function errorResponse(error: unknown) {
  const message = error instanceof Error ? error.message : "Local database operation failed";
  const safe = /required|valid|unknown|unsupported|too long|rights|SHA-256|configuration|bookmark|vehicle|query|market|revision|collision|self-approve|exact|backup|SQLite|database/i.test(message);
  return Response.json({ error: safe ? message : "Локальная база недоступна или операция не прошла проверку." }, { status: safe ? 400 : 503, headers });
}

export async function GET(request: Request) {
  const dbPath = localDatabasePath();
  if (!dbPath || !isLocalRequest(request)) return Response.json({ error: "Local desktop database is unavailable" }, { status: 404, headers });
  const url = new URL(request.url);
  const action = url.searchParams.get("action") || "summary";
  try {
    if (action === "summary") {
      return Response.json({
        mode: "offline_local_sqlite",
        schemaVersion: localCore.SCHEMA_VERSION,
        moduleCoverage: localCore.getModuleCoverage(dbPath),
        verifiedConfigurations: localCore.listVerifiedConfigurations(dbPath),
        vehicles: localCore.listUserVehicles(dbPath),
        bookmarks: localCore.listBookmarks(dbPath),
        history: localCore.listHistory(dbPath, 30),
      }, { headers });
    }
    if (action === "records") {
      const recordType = url.searchParams.get("record_type") || "";
      const configurationId = url.searchParams.get("configuration_id");
      const query = url.searchParams.get("q") || "";
      const limit = Number(url.searchParams.get("limit") || "25");
      if (!Number.isInteger(limit) || limit < 1 || limit > 50) return Response.json({ error: "Лимит должен быть от 1 до 50." }, { status: 400, headers });
      const rows = localCore.searchVerifiedTechnicalRecords(dbPath, {
        record_type: recordType,
        configuration_id: configurationId ? Number(configurationId) : undefined,
        query,
        limit,
      });
      return Response.json({ recordType, count: rows.length, rows }, { headers });
    }
    if (action === "vehicles") return Response.json({ rows: localCore.listUserVehicles(dbPath) }, { headers });
    if (action === "bookmarks") return Response.json({ rows: localCore.listBookmarks(dbPath) }, { headers });
    if (action === "history") return Response.json({ rows: localCore.listHistory(dbPath, Number(url.searchParams.get("limit") || "30")) }, { headers });
    if (action === "admin-summary") return Response.json({
      mode: "offline_local_sqlite_admin",
      schemaVersion: localCore.SCHEMA_VERSION,
      sources: localCore.listSources(dbPath),
      importBatches: localCore.listImportBatches(dbPath, 50),
      moduleCoverage: localCore.getModuleCoverage(dbPath),
    }, { headers });
    return Response.json({ error: "Unknown local database action" }, { status: 404, headers });
  } catch (error) { return errorResponse(error); }
}

export async function POST(request: Request) {
  const dbPath = localDatabasePath();
  if (!dbPath || !isLocalRequest(request)) return Response.json({ error: "Local desktop database is unavailable" }, { status: 404, headers });
  if (!isSameOriginMutation(request)) return Response.json({ error: "Cross-origin local database mutation is blocked" }, { status: 403, headers });
  const contentType = request.headers.get("content-type") || "";
  if (contentType.toLowerCase().includes("multipart/form-data")) {
    const declared = Number(request.headers.get("content-length") || "0");
    const maxMultipartBytes = 256 * 1024 * 1024;
    if (Number.isFinite(declared) && declared > maxMultipartBytes) return Response.json({ error: "Файл превышает допустимый размер 256 MiB." }, { status: 413, headers });
    let form: FormData;
    try {
      const bytes = await readLimitedBytes(request, maxMultipartBytes);
      form = await new Request(request.url, { method: "POST", headers: { "Content-Type": contentType }, body: bytes }).formData();
    } catch { return Response.json({ error: "Не удалось безопасно прочитать загруженный файл или превышен лимит 256 MiB." }, { status: 413, headers }); }
    const action = String(form.get("action") || "");
    const file = form.get("file");
    if (!(file instanceof File)) return Response.json({ error: "Выберите файл для операции." }, { status: 400, headers });
    try {
      if (action === "package.import") {
        if (file.size < 2 || file.size > 32 * 1024 * 1024) return Response.json({ error: "JSON-пакет должен быть размером от 2 байт до 32 MiB." }, { status: 413, headers });
        let inputPackage: unknown;
        try { inputPackage = JSON.parse(await file.text()); }
        catch { return Response.json({ error: "Файл пакета не является корректным JSON." }, { status: 400, headers }); }
        const result = localCore.importPackage(dbPath, inputPackage);
        return Response.json({ import: result }, { status: 201, headers });
      }
      if (action === "backup.restore") {
        if (file.size < 100 || file.size > 256 * 1024 * 1024) return Response.json({ error: "Файл резервной копии должен быть размером от 100 байт до 256 MiB." }, { status: 413, headers });
        const temporary = path.join(path.dirname(dbPath), `.restore-upload-${randomUUID()}.sqlite`);
        try {
          await fs.writeFile(temporary, Buffer.from(await file.arrayBuffer()), { flag: "wx", mode: 0o600 });
          const result = localCore.restoreDatabase(dbPath, temporary);
          return Response.json({ restore: result }, { headers });
        } finally { await fs.rm(temporary, { force: true }).catch(() => undefined); }
      }
      return Response.json({ error: "Unknown local database upload action" }, { status: 404, headers });
    } catch (error) { return errorResponse(error); }
  }
  if (!contentType.toLowerCase().includes("application/json")) return Response.json({ error: "Content-Type must be application/json or multipart/form-data" }, { status: 415, headers });
  let raw: string;
  try { raw = await readLimitedBody(request, 256 * 1024); }
  catch { return Response.json({ error: "Request body exceeds 256 KiB" }, { status: 413, headers }); }
  let body: Record<string, any>;
  try { body = JSON.parse(raw); }
  catch { return Response.json({ error: "Invalid JSON body" }, { status: 400, headers }); }
  try {
    if (body.action === "source.register-candidate") return Response.json({ source: localCore.registerSourceCandidate(dbPath, body.source) }, { status: 201, headers });
    if (body.action === "backup.create") {
      const backupDir = path.join(path.dirname(dbPath), "exports");
      await fs.mkdir(backupDir, { recursive: true, mode: 0o700 });
      const backupPath = path.join(backupDir, `${randomUUID()}.sqlite`);
      try {
        const result = localCore.backupDatabase(dbPath, backupPath);
        const bytes = await fs.readFile(backupPath);
        return new Response(bytes, { status: 200, headers: { ...headers, "Content-Type": "application/vnd.sqlite3", "Content-Length": String(bytes.length), "Content-Disposition": `attachment; filename="${localBackupName()}"`, "X-Backup-SHA256": result.sha256 } });
      } finally { await fs.rm(backupPath, { force: true }).catch(() => undefined); }
    }
    if (body.action === "vehicle.save") return Response.json({ vehicle: localCore.saveUserVehicle(dbPath, body.vehicle) }, { status: 201, headers });
    if (body.action === "vehicle.link-config") return Response.json({ vehicle: localCore.linkUserVehicleConfiguration(dbPath, Number(body.vehicle_id), Number(body.configuration_id)) }, { headers });
    if (body.action === "vehicle.rename") return Response.json({ renamed: localCore.renameUserVehicle(dbPath, Number(body.id), String(body.nickname || "")) }, { headers });
    if (body.action === "vehicle.default") return Response.json({ updated: localCore.setDefaultUserVehicle(dbPath, Number(body.id)) }, { headers });
    if (body.action === "vehicle.delete") return Response.json({ deleted: localCore.deleteUserVehicle(dbPath, Number(body.id)) }, { headers });
    if (body.action === "bookmark.save") return Response.json({ bookmark: localCore.saveBookmark(dbPath, body.bookmark) }, { status: 201, headers });
    if (body.action === "bookmark.delete") return Response.json({ deleted: localCore.deleteBookmark(dbPath, Number(body.id)) }, { headers });
    if (body.action === "history.add") return Response.json({ history: localCore.addHistory(dbPath, body.entry) }, { status: 201, headers });
    return Response.json({ error: "Unknown local database action" }, { status: 404, headers });
  } catch (error) { return errorResponse(error); }
}
