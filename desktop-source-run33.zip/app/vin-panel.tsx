"use client";

import { useEffect, useRef, useState } from "react";

type Result = {
  vin: string;
  source: string;
  sourceUrl?: string | null;
  sourceTermsUrl?: string | null;
  sourceRevision?: string;
  sourceRights?: string;
  validFormat: boolean;
  checksum: string;
  manufacturer: string;
  region: string;
  modelYear: string;
  fields: { name: string; value: string; source: string; confidence: string }[];
  notes: string[];
  externalAvailable?: boolean;
};

export default function VinPanel({ vin, onClear }: { vin: string; onClear?: () => void }) {
  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const requestSequence = useRef(0);
  const activeController = useRef<AbortController | null>(null);

  useEffect(() => {
    requestSequence.current += 1;
    activeController.current?.abort();
    activeController.current = null;
    setResult(null);
    setError("");
    setLoading(false);

    return () => {
      requestSequence.current += 1;
      activeController.current?.abort();
      activeController.current = null;
    };
  }, [vin]);

  async function run() {
    const candidate = vin.trim().toUpperCase();
    if (!/^[A-HJ-NPR-Z0-9]{17}$/.test(candidate)) {
      setResult(null);
      setError("Введите VIN из 17 символов. Буквы I, O и Q не допускаются.");
      return;
    }

    activeController.current?.abort();
    const controller = new AbortController();
    activeController.current = controller;
    const sequence = ++requestSequence.current;
    const isCurrent = () => requestSequence.current === sequence && !controller.signal.aborted;

    setError("");
    setResult(null);
    setLoading(true);

    try {
      const response = await fetch("/api/vin-decode", {
        method: "POST",
        headers: { "content-type": "application/json", accept: "application/json" },
        body: JSON.stringify({ vin: candidate }),
        signal: controller.signal,
        cache: "no-store",
      });
      const contentType = response.headers.get("content-type")?.toLowerCase() || "";
      if (!contentType.includes("application/json")) {
        throw new Error("Сервер вернул ответ неожиданного формата.");
      }
      const data: unknown = await response.json();
      if (!isCurrent()) return;
      if (!response.ok) {
        const message = data && typeof data === "object" && "error" in data && typeof data.error === "string"
          ? data.error
          : "Ошибка декодирования VIN.";
        throw new Error(message);
      }
      if (!data || typeof data !== "object") {
        throw new Error("Сервер вернул неполный результат декодирования.");
      }
      const resultCandidate = data as Partial<Result>;
      if (resultCandidate.vin !== candidate || typeof resultCandidate.validFormat !== "boolean" || !Array.isArray(resultCandidate.fields) || !Array.isArray(resultCandidate.notes)) {
        throw new Error("Сервер вернул неполный результат или данные для другого VIN.");
      }
      const safeFields = resultCandidate.fields.filter((field): field is Result["fields"][number] =>
        !!field && typeof field === "object" &&
        typeof field.name === "string" && typeof field.value === "string" &&
        typeof field.source === "string" && typeof field.confidence === "string"
      ).slice(0, 40).map((field) => ({
        name: field.name.replace(/[\u0000-\u001f\u007f]/g, "").slice(0, 100),
        value: field.value.replace(/[\u0000-\u001f\u007f]/g, "").slice(0, 200),
        source: field.source.replace(/[\u0000-\u001f\u007f]/g, "").slice(0, 100),
        confidence: field.confidence.slice(0, 40)
      }));
      const safeNotes = resultCandidate.notes.filter((note): note is string => typeof note === "string")
        .slice(0, 20).map((note) => note.replace(/[\u0000-\u001f\u007f]/g, "").slice(0, 500));
      setResult({ ...resultCandidate, fields: safeFields, notes: safeNotes } as Result);
    } catch (caught) {
      if (!isCurrent()) return;
      if (caught instanceof Error && caught.name === "AbortError") return;
      setError(caught instanceof Error ? caught.message : "Не удалось выполнить запрос.");
    } finally {
      if (isCurrent()) {
        setLoading(false);
        activeController.current = null;
      }
    }
  }

  return (
    <section className="vin-panel">
      <div className="vin-head">
        <div>
          <b>VIN ENGINE · Предварительная идентификация</b>
          <small>Локальная проверка + NHTSA vPIC только при включённом серверном лимитере</small>
        </div>
        <div className="vin-actions">
          <button className="small vin-run" onClick={run} disabled={loading}>
            {loading ? "Проверяем…" : "Расшифровать VIN"}
          </button>
          {vin && <button className="small" type="button" onClick={onClear} disabled={loading}>Очистить VIN</button>}
        </div>
      </div>
      {error && <p className="vin-error" role="alert">{error}</p>}
      {result && (
        <>
          <div className="vin-status">
            <span>Источник: {result.source}</span>
            <span>Формат: {result.validFormat ? "17 символов — OK" : "ошибка"}</span>
            <span>Контрольная цифра: {result.checksum}</span>
            <span>vPIC: {result.externalAvailable ? "ответ получен" : "недоступен"}</span>
          </div>
          {result.sourceRevision && (
            <div className="vin-notes">
              <p>Ревизия источника: {result.sourceRevision}</p>
              <p>Статус использования: {result.sourceRights || "reference-only"}</p>
              {result.sourceUrl && (
                <p>
                  <a href={result.sourceUrl} target="_blank" rel="noopener noreferrer">Открыть источник данных</a>
                  {result.sourceTermsUrl && <> · <a href={result.sourceTermsUrl} target="_blank" rel="noopener noreferrer">Условия использования</a></>}
                </p>
              )}
            </div>
          )}
          <div className="vin-fields">
            {result.fields.map((field, index) => (
              <div className="vin-field" key={`${field.name}-${index}`}>
                <small>{field.name}</small>
                <b>{field.value || "Нет данных"}</b>
                <em>{field.source} · {field.confidence}</em>
              </div>
            ))}
          </div>
          <div className="vin-notes">
            {result.notes.map((note, index) => <p key={index}>• {note}</p>)}
          </div>
        </>
      )}
    </section>
  );
}
