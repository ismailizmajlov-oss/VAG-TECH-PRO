"use client";

import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import VinPanel from "./vin-panel";
import SystemDiagram from "@/components/system-diagram";
import DiagnosticWorksheet from "@/components/diagnostic-worksheet";
import LocalResearchCatalog from "@/components/local-research-catalog";
import LocalOfflineWorkspace from "@/components/local-offline-workspace";
import LocalDataAdmin from "@/components/local-data-admin";
import { createClient } from "@/lib/supabase/client";

type Module = "MECHANIC" | "ELECTRICIAN" | "DIAGNOSTIC";
const garageSelect = "id,nickname,is_default,created_at,configuration:vehicle_configurations(id,generation_id,market,model_year,production_date,pr_codes,body_code,drive_type,engine:engines(engine_code),transmission:transmissions(transmission_code),ecu:ecu_units(ecu_family,hardware_number,software_number),generation:vehicle_generations(id,name,model_id,model:vehicle_models(id,name,brand_id,brand:brands(name))))";
type DbRow = Record<string, any>;
const moduleInfo: Record<Module, { icon: string; desc: string; title: string }> = {
  MECHANIC: { icon: "⚒", desc: "— Ремонт и обслуживание", title: "Механика и ремонт" },
  ELECTRICIAN: { icon: "ϟ", desc: "— Электросхемы, распиновки, проверки", title: "Автоэлектрика" },
  DIAGNOSTIC: { icon: "⌁", desc: "— Коды ошибок, диагностика, адаптации", title: "Диагностика" }
};
const groups: Record<Module, string[][]> = {
  MECHANIC: [["Двигатель","Общие сведения","Ремонтные данные","Привод ГРМ","ГБЦ","Поршневая группа","Система смазки","Система охлаждения","Турбонаддув","Впуск и выпуск","Топливная система"],["Трансмиссия","Сцепление","Коробка передач"],["Ходовая часть","Передняя подвеска","Задняя подвеска"],["Тормозная система","Передние тормоза","Задние тормоза"],["Кузов","Сервис и обслуживание"]],
  ELECTRICIAN: [["Электросхемы","Распределение питания","Массы и соединения","CAN / LIN"],["Блоки управления","ECU двигателя","ABS / ESP","Комфорт и кузов"],["Компоненты","Датчики двигателя","Исполнительные механизмы","Освещение"],["Проверки","Проверка цепи","Падение напряжения","Осциллограммы"]],
  DIAGNOSTIC: [["Диагностика двигателя","Считывание DTC","Параметры в реальном времени","Тесты исполнительных механизмов"],["Трансмиссия","Ошибки КПП","Адаптации"],["Системы автомобиля","ABS / ESP","SRS / Airbag","Комфорт"],["Сервисные функции","Сброс интервалов","Базовые установки","Кодирование"]]
};

export default function Home() {
  const supabase = useMemo(() => createClient(), []);
  const [active, setActive] = useState<Module>("MECHANIC");
  const [carId, setCarId] = useState("");
  const [brand, setBrand] = useState("");
  const [vin, setVin] = useState("");
  const [query, setQuery] = useState("");
  const [globalQuery, setGlobalQuery] = useState("");
  const [theme, setTheme] = useState<"dark"|"light">("dark");
  const [selected, setSelected] = useState("Привод ГРМ");
  const [message, setMessage] = useState(supabase ? "Подключение к каталогу…" : "Локальный офлайн-режим: доступны только лицензированные справочники-кандидаты.");
  const [catalogOnline, setCatalogOnline] = useState(false);
  const [cloudLoading, setCloudLoading] = useState(Boolean(supabase));
  const [brands, setBrands] = useState<DbRow[]>([]);
  const [models, setModels] = useState<DbRow[]>([]);
  const [generations, setGenerations] = useState<DbRow[]>([]);
  const [generationId, setGenerationId] = useState("");
  const [configurations, setConfigurations] = useState<DbRow[]>([]);
  const [configurationId, setConfigurationId] = useState("");
  const [loadingConfigurations, setLoadingConfigurations] = useState(false);
  const [results, setResults] = useState<DbRow[]>([]);
  const [searching, setSearching] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [bookmarks, setBookmarks] = useState<DbRow[]>([]);
  const [history, setHistory] = useState<DbRow[]>([]);
  const [userVehicles, setUserVehicles] = useState<DbRow[]>([]);
  const [vehicleNickname, setVehicleNickname] = useState("");
  const pendingConfigurationId = useRef<string | null>(null);
  const searchSequence = useRef(0);
  const privateDataSequence = useRef(0);
  const userIdRef = useRef<string | null>(null);
  const [view, setView] = useState<"workspace"|"bookmarks"|"history"|"garage"|"local-research"|"local-admin">("workspace");
  const globalSearchRef = useRef<HTMLInputElement>(null);
  const sectionSearchRef = useRef<HTMLInputElement>(null);

  // Keyboard-first workflow: Ctrl/Cmd+K focuses global search; / focuses section filter; Alt+1..3 switches modules; Escape clears the focused search.
  useEffect(() => {
    function handleWorkspaceKeys(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      const typing = !!target && (target.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName));
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        globalSearchRef.current?.focus();
        globalSearchRef.current?.select();
      } else if (!typing && !event.ctrlKey && !event.metaKey && !event.altKey && event.key === "/") {
        event.preventDefault();
        sectionSearchRef.current?.focus();
        sectionSearchRef.current?.select();
      } else if (event.altKey && !event.ctrlKey && !event.metaKey && ["1", "2", "3"].includes(event.key)) {
        event.preventDefault();
        const moduleByKey: Record<string, Module> = { "1": "MECHANIC", "2": "ELECTRICIAN", "3": "DIAGNOSTIC" };
        setActive(moduleByKey[event.key]);
        setView("workspace");
        setResults([]);
        setSearching(false);
        searchSequence.current += 1;
      } else if (event.key === "Escape") {
        // Escape clears the search field currently in use; it should work even while the input has focus.
        if (target === globalSearchRef.current && globalQuery) {
          event.preventDefault();
          setGlobalQuery("");
        } else if (target === sectionSearchRef.current && query) {
          event.preventDefault();
          setQuery("");
        } else if (!typing && globalQuery) {
          setGlobalQuery("");
        }
      }
    }
    window.addEventListener("keydown", handleWorkspaceKeys);
    return () => window.removeEventListener("keydown", handleWorkspaceKeys);
  }, [globalQuery, catalogOnline]);

  useEffect(() => {
    if (!supabase) { setCloudLoading(false); setCatalogOnline(false); setView("workspace"); setMessage("Локальный офлайн-режим: работает локальная SQLite. Ручной гараж и модули доступны; точные технические записи показываются только после проверки применимости."); return; }
    setCloudLoading(true);
    setCatalogOnline(false);
    let alive = true;
    let authEventSeen = false;
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      authEventSeen = true;
      const nextUser = session?.user || null;
      const nextOwnerId = nextUser?.id || null;
      const privateLoadToken = ++privateDataSequence.current;
      userIdRef.current = nextOwnerId;
      setUserEmail(nextUser?.email || null);
      setUserId(nextOwnerId);
      searchSequence.current += 1;
      setResults([]); setSearching(false);
      if (!nextUser) { setBookmarks([]); setHistory([]); setUserVehicles([]); return; }
      // Defer Supabase reads until the auth callback has completed to avoid locking auth state.
      window.setTimeout(async () => {
        const [{ data: bm }, { data: h }, { data: uv }] = await Promise.all([
          supabase.from("user_bookmarks").select("id,label,created_at,document_id,procedure_id,dtc_id,specification_id,wiring_diagram_id,diagnostic_test_id").eq("user_id", nextOwnerId).order("created_at", {ascending:false}).limit(30),
          supabase.from("query_history").select("id,query_text,response_summary,created_at").eq("user_id", nextOwnerId).order("created_at", {ascending:false}).limit(30),
          supabase.from("user_vehicles").select(garageSelect).eq("user_id", nextOwnerId).order("is_default", {ascending:false}).order("created_at", {ascending:false})
        ]);
        if (alive && privateLoadToken === privateDataSequence.current && userIdRef.current === nextOwnerId) { setBookmarks(bm || []); setHistory(h || []); setUserVehicles(uv || []); }
      }, 0);
    });
    (async () => {
      const [{ data: b, error: brandError }, { data: m, error: modelError }, { data: g, error: generationError }, { data: auth, error: authError }] = await Promise.all([
        supabase.from("brands").select("id,name,slug").eq("is_active", true).order("name"),
        supabase.from("vehicle_models").select("id,name,brand_id,market").eq("is_active", true).order("name"),
        supabase.from("vehicle_generations").select("id,name,model_id,platform_code,model_year_start,model_year_end").eq("source_status","verified").order("name"),
        supabase.auth.getUser()
      ]);
      if (!alive) return;
      const catalogError = brandError || modelError || generationError || authError;
      if (catalogError) {
        setCloudLoading(false); setCatalogOnline(false); setBrands([]); setModels([]); setGenerations([]); setView("workspace");
        setMessage(`Облачный каталог недоступен. Переключено на локальную SQLite; точная применимость будет показана только по проверенным локальным данным. ${catalogError.message}`);
        return;
      }
      setCatalogOnline(true);
      setCloudLoading(false);
      setBrands(b || []); setModels(m || []); setGenerations(g || []);
      setBrand((current) => current && (b || []).some((row) => row.name === current) ? current : (b || [])[0]?.name || "");
      setMessage(`Supabase подключён · ${b?.length || 0} марок · ${m?.length || 0} моделей. Технические документы появятся после легального наполнения и проверки.`);
      // If an auth event arrived while getUser/catalog reads were in flight, its newer session wins.
      if (authEventSeen) return;
      const initialOwnerId = auth.user?.id || null;
      userIdRef.current = initialOwnerId;
      setUserEmail(auth.user?.email || null); setUserId(initialOwnerId);
      const privateLoadToken = ++privateDataSequence.current;
      if (!initialOwnerId) return;
      const [{ data: bm }, { data: h }, { data: uv }] = await Promise.all([
        supabase.from("user_bookmarks").select("id,label,created_at,document_id,procedure_id,dtc_id,specification_id,wiring_diagram_id,diagnostic_test_id").eq("user_id", initialOwnerId).order("created_at", {ascending:false}).limit(30),
        supabase.from("query_history").select("id,query_text,response_summary,created_at").eq("user_id", initialOwnerId).order("created_at", {ascending:false}).limit(30),
        supabase.from("user_vehicles").select(garageSelect).eq("user_id", initialOwnerId).order("is_default", {ascending:false}).order("created_at", {ascending:false})
      ]);
      if (alive && privateLoadToken === privateDataSequence.current && userIdRef.current === initialOwnerId) { setBookmarks(bm || []); setHistory(h || []); setUserVehicles(uv || []); }
    })();
    return () => { alive = false; privateDataSequence.current += 1; listener.subscription.unsubscribe(); };
  }, [supabase]);

  const visibleGroups = useMemo(() => groups[active].map(g => [g[0], ...g.slice(1).filter(x => x.toLowerCase().includes(query.toLowerCase()))]).filter(g => g.length > 1), [active, query]);
  const currentModels = brand ? models.filter(m => brands.find(b => b.id === m.brand_id)?.name === brand) : [];
  const selectedModel = currentModels.find(m => m.id === carId) || null;
  const selectedGenerations = generations.filter(g => selectedModel?.id === g.model_id);

  useEffect(() => {
    const desiredConfigurationId = pendingConfigurationId.current;
    setConfigurationId(""); setConfigurations([]);
    if (!supabase || !generationId) { pendingConfigurationId.current = null; return; }
    let alive = true; setLoadingConfigurations(true);
    supabase.from("vehicle_configurations").select("id,generation_id,market,model_year,production_date,pr_codes,body_code,drive_type,engine:engines(engine_code),transmission:transmissions(transmission_code),ecu:ecu_units(manufacturer,ecu_family,hardware_number,software_number)")
      .eq("generation_id", generationId).eq("source_status", "verified").order("model_year", { ascending: false })
      .then(({ data, error }) => {
        if (!alive) return;
        const rows = error ? [] : data || [];
        setConfigurations(rows); setLoadingConfigurations(false);
        if (desiredConfigurationId && rows.some((row) => row.id === desiredConfigurationId)) setConfigurationId(desiredConfigurationId);
        if (pendingConfigurationId.current === desiredConfigurationId) pendingConfigurationId.current = null;
        if (error) { setCloudLoading(false); setCatalogOnline(false); setView("workspace"); setMessage(`Сервер конфигураций недоступен. Используется локальная SQLite; неподтверждённые конфигурации не подставляются. ${error.message}`); }
      });
    return () => { alive = false; };
  }, [supabase, generationId]);
  async function search(e?: FormEvent, override?: string) {
    e?.preventDefault();
    const requestSequence = ++searchSequence.current;
    const q = (override ?? globalQuery).trim().replace(/[^\p{L}\p{N}\s-]/gu, " ").replace(/\s+/g, " ").slice(0, 100);
    if (!q) return;
    if (!supabase || (!catalogOnline && !cloudLoading)) { setView("workspace"); setMessage("Офлайн-поиск выполняется внутри выбранного технического модуля по локальной SQLite."); return; }
    if (!catalogOnline && cloudLoading) { setMessage("Подождите завершения загрузки каталога автомобиля."); return; }
    if (!configurationId) { setResults([]); setMessage("Поиск заблокирован: выберите точную подтверждённую конфигурацию автомобиля. Модели и поколения недостаточно для проверки применимости."); return; }
    const searchConfigurationId = configurationId;
    const searchOwnerId = userId;
    setSearching(true); setView("workspace");
    const [{ data: df, error: de }, { data: pf, error: pe }] = await Promise.all([
      supabase.from("document_vehicle_fitment").select("document_id").eq("configuration_id", searchConfigurationId).eq("status", "verified"),
      supabase.from("procedure_fitment").select("procedure_id").eq("configuration_id", searchConfigurationId).eq("status", "verified")
    ]);
    if (requestSequence !== searchSequence.current) return;
    if (de || pe) { setCloudLoading(false); setCatalogOnline(false); setResults([]); setSearching(false); setView("workspace"); setMessage(`Облачная проверка применимости недоступна. Используется локальная SQLite; данные других конфигураций не подставляются. ${(de || pe)?.message}`); return; }
    const documentIds = [...new Set((df || []).map(x => x.document_id))];
    const procedureIds = [...new Set((pf || []).map(x => x.procedure_id))];
    if (!documentIds.length && !procedureIds.length) { setResults([]); setSearching(false); setMessage("Для этой конфигурации нет подтверждённых привязок. Общие данные других версий не показываются."); return; }
    const [docs, dtcs, specs, procs, wiring, tests] = await Promise.all([
      documentIds.length ? supabase.from("technical_documents").select("id,title,kind,language,revision,summary,status,source_id,source:sources(publisher,title,source_url,revision,permission_status)").eq("status","verified").in("id",documentIds).ilike("title",`%${q}%`).limit(12) : Promise.resolve({data:[],error:null}),
      documentIds.length ? supabase.from("dtc_codes").select("id,document_id,code,system_name,ecu_family,description,diagnostic_notes,status,document:technical_documents(title,revision,source:sources(publisher,title,revision,source_url,permission_status))").eq("status","verified").in("document_id",documentIds).or(`code.ilike.%${q}%,description.ilike.%${q}%,system_name.ilike.%${q}%,ecu_family.ilike.%${q}%`).limit(12) : Promise.resolve({data:[],error:null}),
      supabase.from("specifications").select("id,document_id,configuration_id,system_name,component_name,parameter_name,value_text,unit,conditions,status,document:technical_documents(title,revision,source:sources(publisher,title,revision,source_url,permission_status))").eq("status","verified").eq("configuration_id",searchConfigurationId).or(`system_name.ilike.%${q}%,component_name.ilike.%${q}%,parameter_name.ilike.%${q}%`).limit(12),
      procedureIds.length ? supabase.from("procedures").select("id,title,objective,status,document:technical_documents(title,revision,source:sources(publisher,title,revision,source_url,permission_status))").eq("status","verified").in("id",procedureIds).or(`title.ilike.%${q}%,objective.ilike.%${q}%`).limit(12) : Promise.resolve({data:[],error:null}),
      supabase.from("wiring_diagrams").select("id,document_id,configuration_id,system_name,component_name,connector_id,pin_number,wire_color,wire_function,status,document:technical_documents(title,revision,source:sources(publisher,title,revision,source_url,permission_status))").eq("status","verified").eq("configuration_id",searchConfigurationId).or(`system_name.ilike.%${q}%,component_name.ilike.%${q}%,connector_id.ilike.%${q}%,pin_number.ilike.%${q}%,wire_function.ilike.%${q}%`).limit(12),
      supabase.from("diagnostic_tests").select("id,document_id,configuration_id,title,test_purpose,status,document:technical_documents(title,revision,source:sources(publisher,title,revision,source_url,permission_status))").eq("status","verified").eq("configuration_id",searchConfigurationId).or(`title.ilike.%${q}%,test_purpose.ilike.%${q}%`).limit(12)
    ]);
    if (requestSequence !== searchSequence.current) return;
    const failure = docs.error || dtcs.error || specs.error || procs.error || wiring.error || tests.error;
    if (failure) { setCloudLoading(false); setCatalogOnline(false); setResults([]); setSearching(false); setView("workspace"); setMessage(`Облачная техническая база недоступна. Используется локальная SQLite; неподтверждённые данные не используются. ${failure.message}`); return; }
    const rows = [...(docs.data||[]).map(x=>({...x,_type:"Документ"})),...(dtcs.data||[]).map(x=>({...x,_type:"DTC"})),...(specs.data||[]).map(x=>({...x,_type:"Спецификация"})),...(procs.data||[]).map(x=>({...x,_type:"Процедура"})),...(wiring.data||[]).map(x=>({...x,_type:"Электросхема"})),...(tests.data||[]).map(x=>({...x,_type:"Тест-план"}))];
    setResults(rows.slice(0, 72)); setSearching(false);
    if (searchOwnerId && requestSequence === searchSequence.current && userIdRef.current === searchOwnerId) await supabase.from("query_history").insert({user_id:searchOwnerId,query_text:q,response_summary:`Найдено записей с подтверждённой применимостью: ${rows.length}`});
    if (requestSequence !== searchSequence.current) return;
    setMessage(rows.length ? `По запросу «${q}» найдено записей для выбранной конфигурации: ${rows.length}.` : `Для выбранной конфигурации совпадений «${q}» нет.`);
  }
  async function addBookmark(row: DbRow) {
    const ownerId = userIdRef.current;
    if (!supabase || !ownerId) { setMessage("Для закладок войдите в аккаунт."); return; }
    const payload = { user_id:ownerId, label: row.title || row.code || row.parameter_name || selected, document_id: row._type === "Документ" ? row.id : null, procedure_id: row._type === "Процедура" ? row.id : null, dtc_id: row._type === "DTC" ? row.id : null, specification_id: row._type === "Спецификация" ? row.id : null, wiring_diagram_id: row._type === "Электросхема" ? row.id : null, diagnostic_test_id: row._type === "Тест-план" ? row.id : null };
    const target = payload.document_id ? {document_id: payload.document_id} : payload.procedure_id ? {procedure_id: payload.procedure_id} : payload.dtc_id ? {dtc_id: payload.dtc_id} : payload.specification_id ? {specification_id: payload.specification_id} : payload.wiring_diagram_id ? {wiring_diagram_id: payload.wiring_diagram_id} : {diagnostic_test_id: payload.diagnostic_test_id};
    const { data: existing, error: lookupError } = await supabase.from("user_bookmarks").select("id").eq("user_id", ownerId).match(target).maybeSingle();
    if (userIdRef.current !== ownerId) return;
    if (lookupError) { setMessage(`Не удалось проверить закладку: ${lookupError.message}`); return; }
    if (existing) { setMessage("Эта запись уже есть в закладках."); return; }
    const { error } = await supabase.from("user_bookmarks").insert(payload);
    if (userIdRef.current !== ownerId) return;
    setMessage(error ? `Не удалось сохранить: ${error.message}` : "Добавлено в закладки.");
    if (!error) { const {data}=await supabase.from("user_bookmarks").select("id,label,created_at,document_id,procedure_id,dtc_id,specification_id,wiring_diagram_id,diagnostic_test_id").eq("user_id",ownerId).order("created_at",{ascending:false}).limit(30); if (userIdRef.current === ownerId) setBookmarks(data||[]); }
  }
  async function removeBookmark(id: string) {
    const ownerId = userIdRef.current;
    if (!supabase || !ownerId) return;
    const { error } = await supabase.from("user_bookmarks").delete().eq("id", id).eq("user_id", ownerId);
    if (userIdRef.current !== ownerId) return;
    if (error) { setMessage(`Не удалось удалить закладку: ${error.message}`); return; }
    setBookmarks(items => items.filter(item => item.id !== id));
    setMessage("Закладка удалена.");
  }
  async function refreshGarage() {
    const ownerId = userIdRef.current;
    if (!supabase || !ownerId) return;
    const { data, error } = await supabase.from("user_vehicles").select(garageSelect).eq("user_id", ownerId).order("is_default", {ascending:false}).order("created_at", {ascending:false});
    if (userIdRef.current !== ownerId) return;
    if (error) { setMessage(`Не удалось загрузить гараж: ${error.message}`); return; }
    setUserVehicles(data || []);
  }
  async function saveCurrentVehicle() {
    const ownerId = userIdRef.current;
    if (!supabase || !ownerId) { setMessage("Войдите в аккаунт, чтобы сохранять автомобили."); return; }
    if (!configurationId) { setMessage("Сначала выберите точную подтверждённую конфигурацию."); return; }
    const config = configurations.find((item) => item.id === configurationId);
    const defaultNickname = [brand, selectedModel?.name, config?.model_year ? `MY ${config.model_year}` : null].filter(Boolean).join(" ");
    const nickname = vehicleNickname.trim() || defaultNickname || "Мой автомобиль";
    const { data: existingVehicles, error: garageReadError } = await supabase.from("user_vehicles").select("id,is_default").eq("user_id", ownerId).limit(100);
    if (userIdRef.current !== ownerId) return;
    if (garageReadError) { setMessage(`Не удалось проверить личный гараж: ${garageReadError.message}`); return; }
    const makeDefault = !(existingVehicles || []).some((item) => item.is_default);
    const { error } = await supabase.from("user_vehicles").insert({user_id:ownerId,configuration_id:configurationId,nickname,is_default:makeDefault});
    if (error) { setMessage(error.code === "23505" ? "Эта конфигурация уже сохранена в гараже." : `Не удалось сохранить автомобиль: ${error.message}`); return; }
    setVehicleNickname(""); await refreshGarage(); setMessage("Автомобиль сохранён в личном гараже. VIN не сохраняется.");
  }
  function selectSavedVehicle(item: DbRow) {
    const config = item.configuration; const generation = config?.generation; const model = generation?.model; const make = model?.brand;
    if (!config || !generation || !model || !make?.name) { setMessage("Сохранённая конфигурация больше недоступна или не прошла проверку."); return; }
    searchSequence.current += 1; setSearching(false); setResults([]);
    setBrand(make.name); setCarId(model.id); setView("workspace");
    if (generationId === generation.id) setConfigurationId(config.id);
    else { pendingConfigurationId.current = config.id; setGenerationId(generation.id); }
    setMessage(`Выбран автомобиль из гаража: ${item.nickname}.`);
  }
  async function setDefaultVehicle(id: string) {
    const ownerId = userIdRef.current;
    if (!supabase || !ownerId) return;
    const { error } = await supabase.rpc("set_default_user_vehicle", {p_vehicle_id:id});
    if (userIdRef.current !== ownerId) return;
    if (error) { setMessage(`Не удалось изменить основной автомобиль: ${error.message}`); return; }
    await refreshGarage();
    if (userIdRef.current === ownerId) setMessage("Основной автомобиль обновлён.");
  }
  async function renameSavedVehicle(id: string, nickname: string) {
    const ownerId = userIdRef.current;
    if (!supabase || !ownerId) return;
    const value = nickname.trim();
    if (!value || value.length > 80) { setMessage("Название должно содержать от 1 до 80 символов."); return; }
    const { error } = await supabase.from("user_vehicles").update({nickname:value}).eq("id",id).eq("user_id",ownerId);
    if (userIdRef.current !== ownerId) return;
    if (error) { setMessage(`Не удалось изменить название: ${error.message}`); return; }
    await refreshGarage();
    if (userIdRef.current === ownerId) setMessage("Название автомобиля обновлено.");
  }
  async function deleteSavedVehicle(id: string) {
    const ownerId = userIdRef.current;
    if (!supabase || !ownerId) return;
    const { error } = await supabase.from("user_vehicles").delete().eq("id",id).eq("user_id",ownerId);
    if (userIdRef.current !== ownerId) return;
    if (error) { setMessage(`Не удалось удалить автомобиль: ${error.message}`); return; }
    setUserVehicles((items) => items.filter((item) => item.id !== id)); setMessage("Автомобиль удалён из гаража.");
  }
  async function signOut() { if (supabase) await supabase.auth.signOut(); userIdRef.current = null; privateDataSequence.current += 1; searchSequence.current += 1; setResults([]); setSearching(false); setUserEmail(null); setUserId(null); setBookmarks([]); setHistory([]); setUserVehicles([]); setMessage("Вы вышли из аккаунта."); }
  function switchModule(m: Module) {
    searchSequence.current += 1;
    setSearching(false);
    setResults([]);
    setActive(m);
    setSelected(groups[m][0][1]);
    setView("workspace");
  }
  function switchView(nextView: "workspace" | "bookmarks" | "history" | "garage" | "local-research" | "local-admin") {
    searchSequence.current += 1;
    setSearching(false);
    if (nextView !== "workspace") setResults([]);
    setView(nextView);
  }

  return <div data-theme={theme} className="app">
    <header className="top"><div className="brand">◢ VAG TECH <em>PRO</em></div><form className="search" role="search" onSubmit={search}>⌕　<input ref={globalSearchRef} aria-label="Глобальный поиск" value={globalQuery} onChange={e=>setGlobalQuery(e.target.value)} disabled={!catalogOnline} placeholder={catalogOnline ? "Поиск по документам, DTC, параметрам, узлам…" : "Офлайн: используйте поиск в локальных справочниках…"} /><span className="search-hint" aria-hidden="true">Ctrl K</span>{globalQuery && <button type="button" className="search-clear" aria-label="Очистить поиск" onClick={()=>setGlobalQuery("")}>×</button>}<button type="submit" disabled={searching || !catalogOnline}>{searching?"…":"Найти"}</button></form><button className="small theme-toggle" aria-label={theme === "dark" ? "Включить светлую тему" : "Включить тёмную тему"} onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>☼ / ☾</button>{userEmail && catalogOnline ? <button className="small" onClick={signOut}>{userEmail} · Выйти</button> : catalogOnline ? <a className="small link-button" href="/login">Войти</a> : cloudLoading ? <span className="small">Подключение…</span> : <span className="small">Офлайн-режим</span>}</header>
    <aside className="sidebar"><button className={`nav ${view==="workspace"?"active":""}`} onClick={()=>switchView("workspace")}>⌂　Рабочее место</button><button className="nav" onClick={()=>{switchView("workspace");setMessage("Выберите марку и модель в селекторе автомобиля.")}}>▣　Подбор автомобиля</button><button className={`nav ${view==="garage"?"active":""}`} onClick={()=>switchView("garage")}>▣　Мои автомобили <small>{userVehicles.length||""}</small></button><button className={`nav ${view==="bookmarks"?"active":""}`} onClick={()=>switchView("bookmarks")}>♧　Мои закладки <small>{bookmarks.length||""}</small></button><button className={`nav ${view==="history"?"active":""}`} onClick={()=>switchView("history")}>◷　История запросов</button><div className="label">Модули</div>
      {(["MECHANIC","ELECTRICIAN","DIAGNOSTIC"] as Module[]).map(m => <button key={m} data-module aria-label={`Открыть модуль: ${moduleInfo[m].title}`} title={`${moduleInfo[m].title} · Alt+${m === "MECHANIC" ? "1" : m === "ELECTRICIAN" ? "2" : "3"}`} aria-pressed={active===m&&view==="workspace"} className={`nav ${active===m&&view==="workspace"?"active":""}`} onClick={() => switchModule(m)}><span>{moduleInfo[m].icon}</span><span><b>{m === "MECHANIC" ? "Механика" : m === "ELECTRICIAN" ? "Электрика" : "Диагностика"}</b><small>{moduleInfo[m].desc.replace("— ","")}</small></span></button>)}
      <div className="label">Система</div><button className={`nav ${view==="local-research"?"active":""}`} onClick={()=>switchView("local-research")}>▤　Локальные справочники</button>{(!supabase || (!catalogOnline && !cloudLoading)) && <button className={`nav ${view==="local-admin"?"active":""}`} onClick={()=>switchView("local-admin")}>⚙　Локальная база и источники</button>}<button className="nav" onClick={()=>{setGlobalQuery(" ");setMessage("База знаний содержит только опубликованные и проверенные записи.")}}>▤　База знаний</button><button className="nav" onClick={()=>setMessage("Обновления появятся после подключения источников и импорта документов.")}>⟳　Обновления</button>{userEmail&&<a className="nav" href="/admin">⚙　Управление базой</a>}<a className="nav" href="mailto:support@vagtechpro.app">ⓘ　Поддержка</a><div className="toast">●　{userEmail && catalogOnline?"Аккаунт активен":catalogOnline?"Гостевой доступ":cloudLoading?"Подключение к каталогу":"Офлайн · локальная SQLite"}</div>
    </aside>
    <main className="main">
      {view !== "local-research" && catalogOnline && <details className="vehicle-panel" open>
        <summary className="vehicle-summary"><span><b>Автомобиль</b><small>{[brand, selectedModel?.name, selectedGenerations.find(g => g.id === generationId)?.name, configurations.find(c => c.id === configurationId)?.engine?.engine_code].filter(Boolean).join(" · ") || "Выберите марку, модель и точную конфигурацию"}</small></span><span className="vehicle-summary-action"><span className="vehicle-summary-label">Параметры автомобиля</span><span aria-hidden="true">⌄</span></span></summary>
      <section className="vehicle">
        <div className="vcell"><label>Марка</label><select value={brand} onChange={e=>{searchSequence.current+=1;setSearching(false);setResults([]);setBrand(e.target.value);setCarId("");setGenerationId("");setConfigurationId("")}}><option value="">Выберите марку</option>{brands.map(x=><option key={x.id} value={x.name}>{x.name}</option>)}</select><div className="muted">VAG Group</div></div>
        <div className="vcell"><label>Модель</label><select value={carId} onChange={e=>{searchSequence.current+=1;setSearching(false);setResults([]);setCarId(e.target.value);setGenerationId("");setConfigurationId("")}}><option value="">Выберите модель</option>{currentModels.map(x=><option key={x.id} value={x.id}>{x.name}{x.market?` · ${x.market}`:""}</option>)}</select><div className="muted">{currentModels.length?`${currentModels.length} названий · навигационные метки; точная применимость отдельно проверяется`:"Нет моделей для выбранной марки"}</div></div>
        <div className="vcell"><label>Поколение / платформа</label><select value={generationId} onChange={e=>{searchSequence.current+=1;setSearching(false);setResults([]);setGenerationId(e.target.value);setConfigurationId("")}}><option value="">{!selectedModel ? "Сначала выберите модель" : selectedGenerations.length ? "Выберите поколение" : "Нет проверенных поколений для модели"}</option>{selectedGenerations.map(g=><option key={g.id} value={g.id}>{g.name}{g.platform_code?` · ${g.platform_code}`:""}</option>)}</select><div className="muted">{selectedGenerations.length ? `${selectedGenerations.length} проверенных поколений` : "Ожидает проверенного наполнения"}</div></div>
        <div className="vcell"><label>Точная конфигурация</label><select value={configurationId} onChange={e=>{searchSequence.current+=1;setSearching(false);setResults([]);setConfigurationId(e.target.value)}} disabled={!generationId || loadingConfigurations}><option value="">{!generationId ? "Сначала поколение" : loadingConfigurations ? "Загрузка…" : configurations.length ? "Выберите конфигурацию" : "Нет подтверждённых конфигураций"}</option>{configurations.map(c=><option key={c.id} value={c.id}>{[c.model_year ? `MY ${c.model_year}` : c.production_date ? `Дата ${c.production_date}` : null,c.market,c.body_code,c.drive_type,c.engine?.engine_code,c.transmission?.transmission_code,c.ecu?.ecu_family,c.ecu?.hardware_number,Array.isArray(c.pr_codes)&&c.pr_codes.length?`PR ${c.pr_codes.join("/")}`:null].filter(Boolean).join(" · ") || "Конфигурация без описания"}</option>)}</select><div className="muted">{configurationId ? [configurations.find(c => c.id === configurationId)?.ecu?.ecu_family,configurations.find(c => c.id === configurationId)?.ecu?.hardware_number,configurations.find(c => c.id === configurationId)?.ecu?.software_number].filter(Boolean).join(" · ") || "ЭБУ не указан в подтверждённой конфигурации" : "Обязательна для технического поиска"}</div></div>
        <div className="vcell"><label>Двигатель / код</label><input readOnly value={configurations.find(c=>c.id===configurationId)?.engine?.engine_code||""} placeholder="Из подтверждённой конфигурации"/><div className="muted">Код двигателя нельзя подменить вручную</div></div>
        <div className="vcell"><label>КПП / код</label><input readOnly value={configurations.find(c=>c.id===configurationId)?.transmission?.transmission_code||""} placeholder="Из подтверждённой конфигурации"/><div className="muted">Код КПП нельзя подменить вручную</div></div>
        <div className="vcell"><label>VIN</label><input value={vin} maxLength={17} onChange={e=>setVin(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,""))} placeholder="17 символов"/><div className="muted">{vin.length}/17 символов</div></div>
      </section>
      </details>}
      {view==="workspace" && catalogOnline && <div className="garage-controls"><input aria-label="Название автомобиля в гараже" value={vehicleNickname} onChange={e=>setVehicleNickname(e.target.value)} placeholder="Название для личного гаража (необязательно)" /><button className="small" disabled={!userId || !configurationId} onClick={()=>void saveCurrentVehicle()}>Сохранить конфигурацию в гараж</button><button className="small" onClick={()=>setView("garage")}>Мои автомобили · {userVehicles.length}</button><span>Сохраняется только проверенная конфигурация; VIN не хранится.</span></div>}
      {view==="local-research" ? <LocalResearchCatalog /> : view==="local-admin" && (!supabase || (!catalogOnline && !cloudLoading)) ? <LocalDataAdmin onMessage={setMessage} /> : (!supabase || (!catalogOnline && !cloudLoading)) ? <LocalOfflineWorkspace view={view === "garage" ? "garage" : view === "bookmarks" ? "bookmarks" : view === "history" ? "history" : "workspace"} active={active} selected={selected} sections={groups[active].flatMap(group => group.slice(1))} onSelect={setSelected} onMessage={setMessage} onViewResearch={() => setView("local-research")} /> : view==="workspace" ? <>
        <VinPanel vin={vin} onClear={() => setVin("")} />
        <div className="strip"><strong>{moduleInfo[active].icon}　{active}</strong><span>{moduleInfo[active].desc}</span></div>
        <section className="work">
          <aside className="tree" aria-label="Разделы технической базы"><div className="tree-heading"><label className="tree-search-label" htmlFor="section-filter">Разделы и узлы</label>{query && <button type="button" className="tree-clear" onClick={()=>setQuery("")}>Сбросить</button>}</div><input ref={sectionSearchRef} id="section-filter" aria-label="Поиск по разделам технической базы" placeholder="⌕　Поиск в разделе… ( / )" value={query} onChange={e=>setQuery(e.target.value)} />{visibleGroups.length ? visibleGroups.map(g=><details className="group" key={g[0]} open><summary><span aria-hidden="true">▱</span>　{g[0]}<small>{g.length-1}</small></summary>{g.slice(1).map(x=><button key={x} className={`leaf ${selected===x?"selected":""}`} aria-current={selected===x?"page":undefined} onClick={()=>{setSelected(x);void search(undefined,x)}}>{x}</button>)}</details>) : <p className="tree-empty">Ничего не найдено. Измените запрос или сбросьте фильтр.</p>}</aside>
          <section className="content" aria-live="polite"><div className="crumb">Главная　›　VAG　›　{brand}　›　{selectedModel?.name||"Модель не выбрана"}　›　{selected}</div>
            {results.length>0 ? <><div className="head"><h1>Результаты поиска</h1><span>{results.length} записей</span></div><div className="results">{results.map((r,i)=>{const source=r.source||r.document?.source||null;const documentTitle=r.document?.title||r.title||"Документ не указан";const revision=r.revision||r.document?.revision||"Ревизия не указана";const sourceUrl=typeof source?.source_url==="string"&&/^https?:\/\//i.test(source.source_url)?source.source_url:null;const detail=[r.system_name,r.component_name,r.parameter_name,r.value_text,r.unit,r.connector_id,r.pin_number,r.wire_color].filter(Boolean).join(" · ");return <article className="result" key={`${r._type}-${r.id||i}`}><div><small>{r._type}</small><h3>{r.title||r.code||r.parameter_name||r.component_name}</h3><p>{r.description||r.summary||r.objective||r.test_purpose||r.wire_function||detail||r.diagnostic_notes||"Проверенная запись каталога"}</p><small className="result-source">{[source?.publisher,documentTitle,revision].filter(Boolean).join(" · ")||"Источник связан с записью"}</small><details className="result-provenance"><summary>Применимость и происхождение</summary><dl><dt>Точная конфигурация</dt><dd>{configurationId}</dd><dt>Документ</dt><dd>{documentTitle}</dd><dt>Ревизия</dt><dd>{revision}</dd><dt>Издатель</dt><dd>{source?.publisher||"Не указан в карточке"}</dd><dt>Правовой статус источника</dt><dd>{source?.permission_status||"Проверяется политикой публикации базы"}</dd></dl>{sourceUrl&&<a href={sourceUrl} target="_blank" rel="noopener noreferrer">Открыть источник ↗</a>}</details></div><button className="small" onClick={()=>addBookmark(r)}>♧ В закладки</button></article>})}</div></> : <><div className="head"><h1>{active==="MECHANIC"?moduleInfo[active].title:active==="ELECTRICIAN"?moduleInfo[active].title:moduleInfo[active].title} · {selected}</h1><div className="actions"><button className="small" onClick={()=>setMessage("Для сохранения закладок войдите в аккаунт и выберите найденный документ.")}>♧ В закладки</button></div></div>
              <div className="grid"><div className="card diagram-card"><h3>{active==="MECHANIC"?"Иллюстрация технического узла":active==="ELECTRICIAN"?"Электрическая архитектура":"Диагностическая логика"}</h3><SystemDiagram mode={active} title={selected} /></div><div className="card"><h3>Рабочий процесс</h3><div className="steps">{(active==="MECHANIC"?["Выбрать точную конфигурацию автомобиля","Проверить применимость документа","Выполнить процедуру по источнику","Зафиксировать контрольный результат"]:active==="ELECTRICIAN"?["Определить блок и компонент","Сверить схему и ревизию","Проверить питание, массу и сигнал","Сопоставить измерения с нормой источника"]:["Считать DTC и freeze frame","Проверить применимость тест-плана","Выполнить проверки по шагам","Подтвердить первопричину"] ).map((x,i)=><div className="step" key={x}><span className="num">{i+1}</span><div><b>{x}</b><small>Показывается как рабочий чек-лист, не как ремонтная инструкция.</small></div></div>)}</div></div><div className="card"><h3>Качество и источник данных</h3><div className="empty">Точные значения, распиновки и моменты затяжки не выводятся без источника, ревизии и подтверждённой применимости к конфигурации автомобиля.</div></div></div>{(active==="DIAGNOSTIC"||active==="ELECTRICIAN")&&<DiagnosticWorksheet mode={active}/>}</>}
          </section>
        </section>
      </> : view==="garage" ? <section className="content list-view"><div className="head"><h1>Мои автомобили</h1><span>{userVehicles.length} сохранено</span></div>{!userEmail ? <div className="empty">Войдите в аккаунт, чтобы вести личный гараж.</div> : userVehicles.length===0 ? <div className="empty">Гараж пуст. Выберите точную подтверждённую конфигурацию и сохраните её с рабочего места.</div> : userVehicles.map(item=>{const c=item.configuration;const g=c?.generation;const m=g?.model;const ecu=c?.ecu;const summary=[m?.brand?.name,m?.name,g?.name,c?.model_year?`MY ${c.model_year}`:c?.production_date?`Дата ${c.production_date}`:null,c?.market,c?.engine?.engine_code,c?.transmission?.transmission_code,ecu?.ecu_family,ecu?.hardware_number,Array.isArray(c?.pr_codes)&&c.pr_codes.length?`PR ${c.pr_codes.join("/")}`:null].filter(Boolean).join(" · ");return <article className="result garage-item" key={item.id}><div><h3>{item.nickname} {item.is_default&&<span className="garage-default">Основной</span>}</h3><p>{summary||"Конфигурация недоступна"}</p><small>{c?.market||""} · {new Date(item.created_at).toLocaleDateString()}</small></div><div className="garage-actions"><input aria-label={`Название автомобиля ${item.nickname}`} value={item.nickname} onChange={e=>setUserVehicles(items=>items.map(x=>x.id===item.id?{...x,nickname:e.target.value}:x))}/><button className="small" onClick={()=>void renameSavedVehicle(item.id,item.nickname)}>Сохранить название</button><button className="small" onClick={()=>selectSavedVehicle(item)}>Открыть</button>{!item.is_default&&<button className="small" onClick={()=>void setDefaultVehicle(item.id)}>Сделать основным</button>}<button className="small danger" onClick={()=>void deleteSavedVehicle(item.id)}>Удалить</button></div></article>})}</section> : <section className="content list-view"><div className="head"><h1>{view==="bookmarks"?"Мои закладки":"История запросов"}</h1></div>{(view==="bookmarks"?bookmarks:history).length===0?<div className="empty">{userEmail?"Пока нет записей.":"Войдите в аккаунт, чтобы сохранять личные данные."}</div>:(view==="bookmarks"?bookmarks:history).map(x=><article className="result" key={x.id}><div><h3>{x.label||x.query_text}</h3><p>{x.response_summary||new Date(x.created_at).toLocaleString()}</p></div>{view==="bookmarks"&&<button className="small" onClick={()=>removeBookmark(x.id)}>Удалить</button>}</article>)}</section>}
      <p className="toast" role="status" aria-live="polite">{message}</p>
      <footer className="footer-note">VAG TECH PRO · Техническая информация публикуется только с источником, ревизией и точной применимостью. Не заменяет заводскую документацию.</footer>
    </main>
  </div>;
}
